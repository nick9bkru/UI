/**
   \file tdcmcli.h
   \brief Описание класса TDcmCli.
   \author Лихобабин Е.А.
   \version 2012-04-19
*/
#ifndef TDCMCLI_H
#define TDCMCLI_H

#include <string>

#include "lib_dcm.h"
#include "lib_std.h"


using namespace std;

namespace dcm
{
   /**
   * \class TDcmCli
   * @brief Класс для работы с модулем сухихи контактов из командной строки
   **/
   class TDcmCli : public _dcm::TDryContactModule
   {
      public:
         /**
          * @brief Конструктор
          * @param usedStates - используемое состояние
          * @param _ipAddr - IP-адрес
          * @param _port - номер порта Defaults to 50000.
          **/
         TDcmCli( string _ipAddr, unsigned short int _port = 50000 );
         /**
          * @brief Деструктор
          **/
         virtual ~TDcmCli();
         /**
          * @brief  Функция инициализации используемых состояний сухих контактов
          **/
         virtual void initUsedStates();
      private:
         /**
          * @brief  Функция окончания обработки состояния сухих контактов
          **/
         virtual void endProcessDcmState ();    
         /**
          * @brief  Функция обработки состояния сухих контактов
          * @param statePos - номер контакта
          * @param state - состояние контакта
          **/
         virtual void processState( int statePos, bool state);
   };
};
#endif // TDCMCLI_H
