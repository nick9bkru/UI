#include <iostream>
#include <signal.h>
#include <stdlib.h>

#include "revision.h"

#include "tdcmcli.h"


using namespace std;

namespace dcm
{
   void PRINTSTARTLOGO()
   {
      cout << "#========================================#" << endl;
      cout << "#                 dcm_cli                #" << endl;
      cout << "#             revision:  "<< DCM_CLI_MAJOR_VERSION << "." << DCM_CLI_MINOR_VERSION << "."<< DCM_CLI_PATH_VERSION  << "           #" << endl;
      cout << "#========================================#" << endl;
      cout << "#========================================#" << endl;
   };

   void PRINTSTOPLOGO()
   {
      cout << "#========================================#" << endl;
      cout << "#     NORMAL FINISH of dcm_cli           #" << endl;
      cout << "#========================================#" << endl;
   };

   void stop()                            //Функция корректного завершения - сюда помещется все, что надо уничтожить при выходе 
   {
      PRINTSTOPLOGO();
   };

   void handler (int signo)               //Обработчик сигнала 
   {
      if (signo == 0)
         exit(1);
      stop();
      exit(1);
   };

};

using namespace dcm;

int main (int argc, char *argv[])
{
//   if ( argc != 4 )
   if (( argc != 4 )&&( argc != 5 ))
   {
      cout << "Usage:" << endl;
      cout << argv[0] << " " << " ip port cmd [SetData]" << endl;
      exit(0);
   };
   struct sigaction signalAction;                        //Структура параметроа обработки сигнала
   signalAction.sa_handler = dcm::handler;           //Устанавливаем обработчиком сигнала функцию handler   
   sigaction(SIGINT, &signalAction, NULL);               //Обрабатываем сигнал SIGINT - нажатие Ctrl+C, с
                                                         //параметрами, описанными в структуре signalAction
   
   string ip = argv[1];
   int port  = _std::stringToNum<short unsigned int>(argv[2]);
   string cmd = argv[3];
   
   PRINTSTARTLOGO();
   cout << endl;
   cout << "Ip:      " <<  ip << endl;
   cout << "Port:    " << argv[2] << endl;
   cout << endl;
   
   TDcmCli *dcm = new TDcmCli(ip, port);
   
   dcm->init();
//   while(1)
   {
   if (cmd == "get")
   {
      dcm->getAndProcessState();
      cout<<"State=== "<<dcm->dcmState<< endl;
   }
   else if (cmd == "set")
   {
//      unsigned char state = 8;
      unsigned char state =  _std::stringToNum<short unsigned int>(argv[4]);
      dcm->setState(state);
   }
   else if (cmd == "gtc")
   {
//      unsigned char state = 8;
      unsigned char state =  _std::stringToNum<short unsigned int>(argv[4]);
      dcm->gtcState(state);
   }
   else if (cmd == "gts")
   {
//      unsigned char state = 8;
      dcm->gtsState();
   }
   else
      cout << "Wrong cmd!!!" << endl;
      usleep(100000);
   }

   
   PRINTSTOPLOGO();
   return 0;
};

