/**
\file tdcmcli.cpp
\brief Реализация класса TDcmCli.
\author Лихобабин Е.А.
\version 2012-04-19
*/

#include "lib_dcm.h"

#include "tdcmcli.h"

using namespace std;

namespace dcm
{
   
   TDcmCli::TDcmCli( string _ipAddr, unsigned short int _port ):TDryContactModule(_ipAddr, _port)
   {
   };
   TDcmCli::~TDcmCli()
   {
   };
   
   void TDcmCli::initUsedStates()
   {
      usedStates = 9;
      
      cout << "TDcmCli usedStates === " << usedStates << endl;
   };
   void TDcmCli::endProcessDcmState()
   {
//       dcmState = state;
   };
   
   void TDcmCli::processState( int statePos, bool state )
   {
      cout << "Позиция №" << _std::toStdString( statePos ) << "         изменилась на " <<  _std::toStdString( state )  << endl;
   };
};
