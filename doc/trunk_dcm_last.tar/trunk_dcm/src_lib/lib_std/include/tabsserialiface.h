/**
   \file tabsusbiface.h
   \brief Описание класса TAbsUsbIface.
   \author Лихобабин
   \version 
   \date 2011-12-16
*/
#ifndef TABSTRACT_SERIAL_IFACE_H
#define TABSTRACT_SERIAL_IFACE_H 1

#include "tabstractiface.h"
#include "tabsserialifacestates.h"

#include <string>
#include <fcntl.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <map>
#include "lib_std.h"

namespace _std
{
   /**
      \class TAbsSerialIface
      \brief Абстрактный интерфейс управления по последовательному порту  
   */
   class TAbsSerialIface: public TAbstractIface
   {
      public:
         /**
         \brief Конструктор
         \param ip - ip адрес
         \param pingTimingUsec - интервал времени для проверки наличия в сети
         */
         TAbsSerialIface (TSerialIfaceTunes tunes);
         /**
         \brief Деструктор
         */
         virtual ~TAbsSerialIface();
         /**
         \brief Функция запуска тестирования
         */
         virtual void test();
         /**
         \brief Функция запроса указателя на класс состояния "в работе"
         \return указатель на абстрактный класс состояния интерфейса
         */
         TIfaceState* getAbsWork();
      protected:
         TSerialIfaceStateTunes stateTunes;    ///< указатель на настройки интерфейса последовательного порта
      private:
         TIfaceState            *stateWork;    ///< указатель на абстрактный класс проверки состояния сетевых интерфейсов
   };
};
  
#endif
