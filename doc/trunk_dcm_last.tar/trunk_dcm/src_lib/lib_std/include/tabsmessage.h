/**
   \file tabsmessage.h
   \brief Описание класса TAbsMessage.
   \author Зайцев А.А., Лихобабин Е.А.
   \version 2012-01-10
*/

#ifndef T_ABS_MESSAGE_H
#define T_ABS_MESSAGE_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <iostream>
#include <list>
#include <errno.h>
#include <map>

#include "ticonvcodec.h"

#define lmt_NOT_TICKED 4            ///< Не квитируемое сообщение
#define lmt_INVALID_HEADER 5        ///< Сообщение с неправильным заголовком
#define lmt_TICKET 3                ///< Квитанция
#define lmt_MESSAGE 2               ///< Сообщение
#define lmt_COMMAND 1               ///< Команда

#define CXX_UNIT_TESTING

#ifdef CXX_UNIT_TESTING
#define ASSIST_UNIT_TEST( class__ ) friend class test_ ## class__
#else
#define ASSIST_UNIT_TEST( class__ )
#endif

using namespace std;                // Пространство имен std

namespace _std
{
   enum enEndian
   {
      little_endian,
      big_endian,
      unknown_endian
   };
   const unsigned int pt_ABSTRACT_PROT = 1000;    ///< базовый абстрактный протокол
   /**
      \class TAbsMessage
      \brief Родительский класс сообщений передаваемых между составляющими системы.
   */
   class TAbsMessage
   {
      ASSIST_UNIT_TEST(T418Message);
      protected:

         int subQueueNumber;  ///<Номер подочереди
      public:
         /**
         * \brief Конструктор
         * @param res_count - число перепосылок
         * @param res_period - период опроса
         * @param subQN - Номер подочереди
         */
         TAbsMessage (int res_count = 2, int res_period = 1000000, int subQN = 0);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsMessage();
         /**
         * \brief Установка сообщения в генераторный вид
         */
         virtual void setGeneric();
         /**
         * \brief Функция определяет, нужно ли отправлять хартбит
         * @param hbTimerPointer - указатель на счетчик
         * @return NULL  или  сообщение хартбита
         */
         virtual TAbsMessage * heartBeatMessage (int * hbTimerPointer) = 0;
         /**
         * \brief Функция переписыват данные пришедшие с внешнего устройства в буфер, принадлежащий данному классу
         * @param data - указатель на данные
         * @param N - размер буфера
         * @return результат переписывания
         */
         virtual bool assign (char* data, unsigned int N) = 0;
         /**
         * \brief Функция вставляет данные в пакет следующего уровня
         * @param data - указатель на данные
         * @param N - размер буфера
         * @return результат выполнения функции
         */
         virtual bool incapsulate (char* data, int N);
         /**
         * \brief Функция вынимает данные из пакета следующего уровня
         * @param data - указатель на данные
         * @return размер данных
         */
         virtual int decapsulate (char * data);
         /**
         * \brief Функция выдает на печать данные
         * @return указатель на данные
         */
         virtual string display() = 0;
         /**
         * \brief Функция устанавливает номер кодограммы
         * @param N - номер кодограммы
         */
         virtual void setCodogramNumber (int * N);
         /**
         * \brief Функция сравнения сообщений
         * @param pattern - указатель на сообщение
         * @return результат сравнения
         */
         virtual bool compare (TAbsMessage * pattern) = 0;
         /**
         * \brief Функция проверкиc корректности кодограммы
         * @return признак корректности кодограммы
         *\retval true - кодограмма корректная
         *\retval false - кодограмма некорректная
         */
         virtual bool isValid() = 0;
         /**
         * \brief Функция возвращает тип сообщения
         * @return тип сообщения
         */
         virtual int  getMessageType() = 0;
         /**
         * \brief Функция возвращает код сообщения
         * @return код сообщения
         */
         virtual int  getMessageCode() = 0;
         /**
         * \brief Функция создает квитанцию на сообщение
         * @return квитанцию на сообщение
         */
         virtual TAbsMessage *createTicket();
         /**
         \brief Функция признак ожидания квитанции при передаче сообщений
         \return Результат
         \retval true, если необходимо ждать квитанцию
         \retval false, если квитанцию не нужно ждать
         */
         virtual bool isOneByOne() = 0;
         /**
         * \brief Функция устанавливает время отправки кодограммы
         */
         virtual void setSendingTime();
         /**
         * \brief Функция возвращает время отправки кодограммы
         * @param t - структура времени
         */
         virtual void getSendingTime (tm* t);
         /**
         * \brief Функция возвращает размер сообщения для отправки в сокет
         * @return возвращает размер сообщения в байтах
         */
         unsigned int getSize();
         /**
         * \brief Функция возвращает признак необходимости отправки сообщения
         * @param waitFlagPointer - указатель на флаг ожидания
         * @return Признак необходимости отправки сообщения
         */
         bool shouldBeSent (bool * waitFlagPointer);
         /**
         * \brief Функция устанавливает признак необходимости отправки сообщения
         * @param send - признак необходимости отправки сообщения
         */
         void setShouldBeSent (bool send);
         /**
         * \brief Функция возвращает признак необходимости чтения сообщения
         * @return Признак необходимости чтения сообщения
         */
         bool shouldBeRead();
         /**
         * \brief Функция устанавливает признак необходимости чтения сообщения
         * @param read - признак необходимости чтения сообщения
         */
         void setShouldBeRead (bool read);
         /**
         * \brief Функция получает данные для отправки
         * @param data - указатель на возвращаемые данные
         * @param maxLen - размер буфера, выделенный под данные
         * @return размер данных
         */
         virtual int getData2Send (char * data, unsigned int maxLen) = 0;
         /**
         * \brief Функция устанавливает шаг времени ожидания
         * @param usec - количество милисекунд
         */
         void timeStep (int usec);
         /**
         * \brief Функция проверки окончания времени ожидания
         * @return признак окончания времени ожидания
         */
         bool timeIsUp();
         /**
         * \brief Функция возвращает тип протокола передачи сообщения
         * @return Тип протокола передачи сообщения
         */
         unsigned int getProtocolType();
         /**
         * \brief Функция проверки того, является ли это сообщение повторным
         * @return Признак повторяемости сообщения
         */
         bool isRepeat();
         /**
         * \brief Функция установки признака того, что это сообщение является повторным
         * @param rpt - признак того, что это сообщение является повторным
         */
         void setRepeat (bool rpt);
         /**
         * \brief Функция проверки возможности повтора данного сообщения
         * @return Признак возможности повтора данного сообщения
         */
         bool isRepeatable();
         /**
         * \brief Функция установки возможности повтора данного сообщения
         * @param rptb - признак возможности повтора данного сообщения
         */
         void setRepeatable (bool rptb);

         /* GENERIC SECTION */
         /**
         * \brief Функция проверки признака того, что нужно вормировать heartbeat
         */
         virtual bool isHeartBeat();
         /**
         * \brief Функция предварительной обработки принятых данных
         * \brief разбивка их на сообщения в соответствии с маркерами протокола
         * @param readBuff - указатель на буфер прочитанных из порта данных
         * @param rLen - размер прочитанных из буфера данных
         * @return результат выполнения предварительной обработки
         */
         virtual map<char*, int> dataSplitter(char *readBuff, ssize_t rLen);
         static TIconvCodec *toProt;        ///< указатель на объект перекодирования из кодировки хоста в кодироку протокола. 
         static TIconvCodec *toHost;        ///< указатель на объект перекодирования из кодировки протокола в кодироку хоста. 
         static bool convertEncodings;      ///< признак необходимости выполнения преобразования кодировок между протоколом и хостом
      protected:
         bool            isHB;              ///< признак необходимости обмена хартбитами
         bool            heartBeating;      ///< признак проверки наличия обмена хартбитами между узлами
         bool            should_be_sent;    ///< признак необходимости отсылки сообщения
         bool            should_be_read;    ///< признак необходимости чтения сообщения
         bool            time_is_up;        ///< признак окончания времени ожидания
         bool            repeat;            ///< признак того, что это сообщение является повторным
         bool            repeatable;        ///< признак возможности повтора данного сообщения
         int             resendCounter;     ///< счетчик повторов
         int             counter;           ///< счетчик
         long int        period;            ///< период
         long int        resendPeriod;      ///< период повторной отсыки сообщения
         unsigned int    size;              ///< размер данных
         unsigned int    protocolType;      ///< тип протокола
         bool            isGeneric;         ///< признак генераторного сообщения
         bool            *wfPointer;        ///< указатель на признак
         static enEndian protocol;          ///< порядок следования байт, предусмотренный протоколом
         static enEndian host;              ///< порядок следования байт, предусмотренный рабочей станцией
         /**
         * \brief Функция установки порядка следования байт, предусмотренного протоколом
         * @param endian - порядок байт
         */
         void setProtocolEndian(enEndian endian); 
      public:
         /**
         * \brief Функция инициализации кодировок протокола и хоста, а также их кодеков
         * @param encoding - кодировка в строковом виде, за доп информацией обращайтесь к TIconvCodec
         */
         void initEncodings(string protEncoding, string hostEncoding);
         /**
         * \brief Функция преобразования порядка следования байт чисел от принятого протоколом к хосту и обратно
         * @param num - число требующее преобразования
         * @return число того же типа, но с порядком следования байт, принятым  в протоколе
         */
         template<class T>
         T convertEndian(T num)
         {
            if ( host != protocol )
            {
               T inverseNum;
               size_t sizeT      = sizeof(inverseNum);    
               char *numP        = reinterpret_cast<char*>( &num );
               char *inverseNumP = reinterpret_cast<char*>( &inverseNum );
               
               for( size_t i = 0; i < sizeT; i++)
               {
                  inverseNumP[i] = numP[sizeT - i - 1];
               };
               return inverseNum;
            };
            return num;
         };
         /**
         * \brief Функция заполнения произвольной переменной нестрокового типа из буфера принятого сообщения
         * @param var - переменная для заполнения
         * @param pData - указатель на данные
         * @return переменная указанного типа с порядком следования байт, принятым в ОС
         */
         template <class T>
         void fillVar(T &var, char *&pData)
         {
            size_t size = sizeof( var );
            memmove( reinterpret_cast<void*>( &var ), pData, size );
            var = convertEndian( var );
            pData += size;

            return;
         };
         /**
         * \brief Функция заполнения буфера переменной произвольного нестрокового типа в порядке следования байт протокола
         * \brief с проверкой размера буфера
         * @param var - переменная для записи в буфер
         * @param pData - указатель на место в буфере для записи
         * @param pEnd - указатель на конец буфера для записи
         * @return переменная указанного типа с порядком следования байт, принятым в ОС
         */
         template <class T>
         bool fillBuff( char *&pData, char *pEnd, T var )
         {
            size_t varSize = sizeof ( var );
            if ( ( pData + varSize ) >  pEnd )
            {
//                throw to_small_buff;
               return false;
            };
            
            memmove( pData, reinterpret_cast<void*>( convertEndian( &var ) ), varSize );
            pData += varSize;
            return true;
         };
         /**
         * \brief Функция заполнения буфера переменной произвольного нестрокового типа в порядке следования байт протокола
         * \brief контроль размера буфера возлагается на вызывающего
         * @param var - переменная для записи в буфер
         * @param pData - указатель на место в буфере для записи
         * @return переменная указанного типа с порядком следования байт, принятым в ОС
         */
         template <class T>
         void fillBuffNoCheck( char *&pData, T var )
         {
            size_t varSize = sizeof ( var );
            memmove( pData, reinterpret_cast<void*>( convertEndian( &var ) ), varSize );
            pData += varSize;
         };
         /**
         * \brief Функция заполнения строки из данных принятого сообщения
         * @param var - строка для заполнения
         * @param pData - указатель на данные
         * @param size - длина данных для помещения в строку
         */
         void fillStrToHost(string & var, char *&pData, size_t size);
         /**
         * \brief Функция заполнения буфера из строки с данными
         * @param pData - указатель на буфер
         * @param var - строка с текстом для записи в буфер
         */
         void getStrToProt(char *&pData, string var);
   };
};

#endif
