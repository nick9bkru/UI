/**
   \file lib_std.h
   \brief Файл с включением заголовочных файлов для библиотеки
   \author Зайцев А.А., Лихобабин Е.А., Воронков Д.В.
   \version 1.0.1
   \date 2011-06-03
*/
#ifndef LIB_STD_H
#define LIB_STD_H

#include "log.h"
#include "parse_cf.h"
#include "parse_cl.h"
#include "tpathfinder.h"
#include "ttrace.h"
#include "watchdog.h"
#include "tstring.hpp"
#include "trpm.h"
#include "tpam.h"
#include "ticonvcodec.h"
#include "tsettings.h"
#include "tabstractiface.h"
#include "tabsipiface.h"
#include "tabsserialiface.h"
#include "tabsserialifacestates.h"
#include "tabsusbiface.h"
// #include "tabsusbifacestates.h"
#include "ttypesniia.h"
#include "tstatetrigger.h"
#include "tabsmessage.h"
#include "tabstractmessproc.h"
#include "tabsqueue.h"


#define CXX_UNIT_TESTING

#ifdef CXX_UNIT_TESTING
#define ASSIST_UNIT_TEST( class__ ) friend class test_ ## class__
#else
#define ASSIST_UNIT_TEST( class__ )
#endif


namespace _std
{
   /**
    * \brief Функция преобразования в строку
    * @param value - что преобразовываем.
    * @return строку из входного параметра.
    */
   template<class T>
   string toStdString (T value);
   /**
    * \brief Функция преобразования из строки в число
    * @param strNum - строка.
    * @return число.
    */
   template<class T>
   T stringToNum (string strNum);
};

#endif
