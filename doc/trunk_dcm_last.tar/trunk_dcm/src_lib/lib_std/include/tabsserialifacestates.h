/**
   \file tabsserislifacestates.h
   \brief Описание классов TAbsUsbNA и TAbsUsbOpen.
   \author Евгений Лихобабин
   \version 0.1
   \date 2011-12-16
*/
#ifndef TABS_SERIAL_IFACE_STATES_H
#define TABS_SERIAL_IFACE_STATES_H 1

#include <stdlib.h>
#include <termios.h>
#include <fcntl.h>
#include <iostream>
#include <fstream>

#include "tabstractiface.h"
#include "tabsqueue.h"
#include "tabstractmessproc.h"
#include "ttypesniia.h"
// #include </include/libusb-1.0/libusb.h>

using namespace std;

namespace _std
{

   typedef struct tSerialIfaceTunes
   {
      int       checkNAStateUsec;
      int       checkOpenStateUsec;
      int       checkWorkStateUsec;
      string    device;
      int       flags;
      bool      usePortOptions;
      termios   portOptions;
      TAbstractMessProc *messproc;
   } TSerialIfaceTunes;
   
   typedef struct tSerialIfaceStateTunes
   {
      TSerialIfaceTunes    *ifaceTunes;
      int                  *portDescr;
      TAbsQueue            *queue;
//       libusb_device_handle **handle;
   } TSerialIfaceStateTunes;

   /**
   * @class TAbsSerialNA
   * @brief Класс определяющий поведение интерфейса в состоянии "недоступен"
   **/
   class TAbsSerialNA: public TIfaceState
   {
      public:
         /**
         * \brief Конструктор
         * @param checkTimingUsec - период проверки состояния
         */
         TAbsSerialNA(int checkTimingUsec);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsSerialNA();
         /**
         * \brief Функция проверки состояния интерфейсов
         * @return результат проверки
         */
         virtual bool step();
   };

   /**
   * @class TAbsSerialOpen
   * @brief Класс определяющий поведение интерфейса в состоянии "открытие порта"
   **/
   class TAbsSerialOpen: public TIfaceState
   {
      public:
         /**
         * \brief Конструктор
         * @param device - блочное устройство, например /dev/ttyUSB0
         * @param checkTimingUsec - период проверки состояния
         */
         TAbsSerialOpen(TSerialIfaceStateTunes tunes);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsSerialOpen();
         /**
         * \brief Функция проверки наличия в сети интерфейсов
         * @return результат проверки
         */
         virtual bool step();
      private:
//          libusb_device_handle **handle;
         int                  portFlags;           ///< флаги последовательного порта
         int                  *portDescr;          ///< дескриптор порта
         bool                 usePortOptions;      ///< применять ли настройки последовательного порта
         struct termios       portOptions;         ///< настройки последовательного порта
         string               device;              ///< адрес блочного устройства
         TAbstractMessProc    *messproc;           ///< указатель на абстрактный обработчик сообщений 
   };

   
   const unsigned int MAX_SERIAL_BUFF_SIZE = 4096;
   /**
   * @class TAbsSerialWork
   * @brief Класс определяющий поведение интерфейса в состоянии "в работе"
   **/
   class TAbsSerialWork: public TIfaceState
   {
      public:
         /**
         * \brief Конструктор
         * @param checkTimingUsec - период проверки состояния
         */
         TAbsSerialWork(TSerialIfaceStateTunes tunes);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsSerialWork ();
         /**
         * \brief Функция проверки наличия в сети интерфейсов
         * @return результат проверки
         */
         virtual bool step ();
      protected:
         /**
         * \brief Функция записи сообщения в порт
         * @return результат выполнения записи сообщения в порт
         */
         virtual bool send ();
         /**
         * \brief Функция чтения данных из порта 
         * @return результат чтения данных из порта
         */
         virtual bool read ();
      private:
         TAbsQueue            *queue;           ///< очередь сообщений для дальнейшей обработки
         TAbstractMessProc    *messproc;        ///< указатель на абстрактный обработчик сообщений 
         int                  *portDescr;       ///< дескриптор порта
//          libusb_device_handle **handle;
   };
};
#endif


