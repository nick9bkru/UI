/**
   \file tabstractifacewque.h
   \brief Описание класса TAbstractIfaceWQue.
   \author Зайцев А.А., Лихобабин Е.А.
   \version 2011-10-02
*/
#ifndef TABSTRACT_IFACE_WQUE_H
#define TABSTRACT_IFACE_WQUE_H

#include <pthread.h>

#include "tabstractiface.h"
#include "tabsqueue.h"
// #include "tmessage.h"

// #include "tlibnetdefines.h"
/**
 * \namespace _std
 * \brief Пространство имен библиотеки lib_std
 **/
namespace _std
{
   /**
      \enum TIfaceWQueState
      \brief Перечисление режимов работы сокета
   */
//    enum TIfaceWQueState
//    {
//       sst_aswq_OPEN,        ///<сокет открыт
//       sst_aswq_CLOSE,       ///<сокет закрыт
//       sst_aswq_STOPED,      ///<сокет приостановлен
//       sst_aswq_READ_WRITE,  ///<сокет открыт для чтения и записи
//       sst_aswq_END,         ///<обработка прекращается - поток останавливается
//       sst_aswq_DEBUG        ///<режим отладки
//    };
      
   /**
      \struct TIfaceWQueTunes
      \brief Структура, хранящая параметры интерфейса
   */
   typedef struct tIfaceWQueTunes
   {
      bool verbose;
      long period;       ///<период опроса интерфейса
   } TIfaceWQueTunes;
   
   
   /**
      \brief Потоковая функция сокета по умолчанию
      \param p - параметры сокета
   */
   void *defaultRun (void * p);
   
   /**
      \class TAbstractIfaceWQue
      \brief Класс описания сокета с очередью
   */
   class TAbstractIfaceWQue
   {
      public:
         /**
          \brief Конструктор
          \param tunes - указатель на структуру с параметрами
         */
         TAbstractIfaceWQue (TIfaceWQueTunes tunes);
         /**
          \brief Деструктор
         */
         virtual ~TAbstractIfaceWQue();   
         /**
          \brief Функция устанавливает период опроса сокета
          \param period - период опроса сокета
         */
         void setPeriod (int period);
         /**
          \brief Функция установки указателя на потоковую функцию
          \param void* (*funcName) (void*) указатель на потоковую функцию
         */
         void setRunFunc (void* (*funcName) (void*));
         /**
          \brief Функция отправляет данные в сокет
         */
         virtual void send () = 0;
         /**
          \brief Функция читает данные из сокета
         */
         virtual void read () = 0;
         /**
          \brief Функция приостановки работы с сокетами
         */
         virtual void stop ();
         /**
          \brief Функция начала работы с сокетами
         */
         virtual void open ();
         /**
          \brief Функция начала работы
          \return Результат
          \retval true, если все выполнено успешно
          \retval false, если произошла ошибка
         */
         bool start();
         /**
          \brief Функция начала работы
          \return Результат
          \retval true, если все выполнено успешно
          \retval false, если произошла ошибка
         */
         virtual bool specificStart() = 0;
         
         /**
         * \brief функция запуска основного цикла обработки
         */
         virtual void run();
         /**
          \brief Функция возобновления обработки после приостановки
         */
         void restart();   
         TAbsQueue      *queue;        ///<указатель на абстрактную очередь сообщений
      protected:
         TAbstractIface *iface;        ///<Указатель на родительский класс сокета         
//          TIfaceWQueState state;        ///<Состояние сокета
         bool verbose;
      private:

         bool runFlag;                 ///< флаг запуска
   
         void* (*runFuncName) (void*); ///<Указатель на потоковую функцию
         pthread_t  thread_id;         ///<Идентификатор потока
         TIfaceWQueTunes ifaceTunes;   ///<Структура для хранения параметров интерфейса

//          TIfaceWQueState prevState;    ///<Состояние сокета перед приостановкой обработки
   #ifdef SOCK_DEBUG_ABILITY
         TDebugType debugType;         ///<Тип отладки
         /**
         * \brief функция отправки отладочного сообщения
         */
         void sendDebugMess();
   #endif
   };
   
};
#endif
