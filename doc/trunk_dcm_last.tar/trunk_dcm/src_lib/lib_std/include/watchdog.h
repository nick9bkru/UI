/**
   \file watchdog.h
   \brief Описание классов TSheep, TWatchDog
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

#ifndef WATCHDOG_H
#define WATCHDOG_H 1 ///<инициализации для компиляции


#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

#define WATCH_DOG_TIMER_DEEP   10       ///<количество холостых опросов сторожевого таймера до перезапуска
#define WATCH_DOG_PERIOD      1000      ///<период опроса сторожевого таймера в милисекундах

namespace _std
{
   /**
   \struct doginfo
   \brief Структура содержит информацию для запуска и перезапуска сторожевого таймера, а также запуска и перезапуска контролируемого приложения
   */
   /**
   \typedef TDogInfo
   \brief Структура содержит информацию для запуска и перезапуска сторожевого таймера, а также запуска и перезапуска контролируемого приложения
   */

   typedef struct doginfo
   {
   int timersDeep;///<количество интервалов времени, отсчитываемых до перезапуска сторожевого таймера или приложения
   int timersAlarmDeep;///<количество интервалов времени, отсчитываемых до перезапуска сторожевого таймера или приложения
   int msTiming;///<интервал времени в мс
   pid_t dogPid;///<ID процесса сторожевого таймера
   pid_t sheepPid;///<ID процесса контролируемого приложения
   char dogName[255];///<полный путь к программе сторожевого таймера
   char sheepName[255];///<полный путь к контролируемому приложению
   bool showLog;///<флаг выдачи служебных сообщений на эран
   bool waiting4First;///<флаг ожидания первого сигнала от сторожевого таймера
   } TDogInfo;


   /**
   \class TSheep
   \brief Класс необходимый член контролируемого приложения
   */
   class TSheep
   {
   private:
      int timersDeep;///<количество интервалов времени, отсчитываемых до перезапуска приложения
      int msTiming;///<интервал времени в мс
      pid_t dogsPid;///<ID процесса сторожевого таймера
      /**
      \brief Функция запуска сторожевого таймера
      */
      void runDog();
      void sig_alarm_handler(int signo, siginfo_t *info, void *f);

   public:
      bool isStarted;///<признак запуска сторожевого таймера
      /**
      \brief Конструктор.
      \param dogName - полный путь к программе сторожевого таймера
      \param sheepName - полный путь к контролируемому приложению
      \param watchTime = 1000 - интервал времени в мс
      */
      TSheep (char * dogName, char * sheepName, int watchTime = 1000);
      /**
        \brief Функция установки количества интервалов времени, отсчитываемых до перезапуска приложения
        \param td - количество интервалов времени, отсчитываемых до перезапуска приложения
       */
      void setTimersDeep (int td);
      /**
        \brief Функция установки времени таймера
        \param msT - время в мс
       */
      void setTiming (int msT);
      /**
        \brief Функция установки признака выдачи служебных сообщений на экран
        \param sl - значение признака
       */
      void setShowLog (bool sl);
      /**
        \brief Функция запуска наблюдения за сигналами сторожевого таймера
        */
      void startWatching();
      /**
        \brief Функция остановки наблюдения за сигналами сторожевого таймера
        */
      void stopWatching();
      /**
        \brief Функция обработки события прихода сигнала от сторожевого таймера
        \param signo - номер стандартного сигнала
       \param info - информация о процессе передаваемого сигнала
       \param f - указатель на список дополнительных параметров
        */
      static void sig_handler (int signo, siginfo_t *info, void *f);
      /**
        \brief Функция периодической посылки сигналов сторожевому таймеру
        */
      void timerslot();

   };
   /**
   \class TWatchDog
   \brief Класс необъходимый член приложения сторгожевого таймера
   */
   class TWatchDog
   {
   private:
      int timersDeep;///<количество интервалов времени, отсчитываемых до перезапуска сторожевого таймера или приложения
      bool waiting4First;///<флаг ожидания первого сигнала от сторожевого таймера
      bool isStarted;///<признак запуска сторожевого таймера

      void sendAlarm();
   public:
      /**
       \brief Конструктор
       \param dogName - поный путь к программе сторожевого таймера
       \param sheepName - полный путь к контролируемому приложению
       \param watchTime = 1000 - интервал времени в мс
       */
      TWatchDog (char * dogName, char * sheepName, int watchTime = 1000);
      /**
        \brief Функция обработчик события прихода сигнала от сторожевого таймера
        \param signo - номер стандартного сигнала
       \param info - информация о процессе передаваемого сигнала
       \param f - указатель на список дополнительных параметров
        */
      static void sig_handler (int signo, siginfo_t *info, void *f);
      /**
        \brief Функция запуска наблюдения за сигналами сторожевого таймера
        */
      void startWatching();
      /**
        \brief Функция остановки наблюдения за сигналами сторожевого таймера
        */
      void stopWatching();
      /**
        \brief  Функция перезапуска наблюдения за сигналами сторожевого таймера
        */
      void restartWatching();
      /**
      \brief Функция периодической посылки сигналов
      */
      void timerslot();
   };
};




#endif



