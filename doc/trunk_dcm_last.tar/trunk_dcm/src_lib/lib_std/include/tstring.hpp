/**
   *\file tstring.hpp
   *\brief Файл с описанием класса функций работы с std::string строками
   *\author Зайцев А.А. Гусинская Е.И. Воронков Д.В. Устинова Е.А. Воронкова Т.В. Якунин С.А. Лихобабин Е.А.
   *\version 2011-02-28
*/
#ifndef TSTRING_H
#define TSTRING_H 1  ///<инициализации для компиляции

#include <sstream>
#include <iomanip>

using namespace std; ///<пространство имен std


namespace _std
{
   /**
   * \brief Преобразует что угодно (почти) в std::string
   * @param value - что преобразуем
   */
   template<class T>
   string toStdString (T value)
   {
      stringstream strS;
      string str;
      strS << value;

      strS >> str;
      ////cout << "value " << value << "str " << str << endl;
      return str;
   };

   /**
   * \brief Преобразует целое в std::string в 16ричном виде, double лучше не передавать 
   * @param value - что преобразуем
   */
   template<class T>
   string toStdHexStr(T value)
   {
      stringstream strS;
      string tmpHex;
      strS << hex << setfill('0') << setw(sizeof(T)) << uppercase << value;

      strS >> tmpHex;
      return tmpHex;
   };
   
   /**
   * \brief Преобразует из std::string почти во что угодно 
   * @param strNum - что преобразуем
   */
   template<class T>
   T stringToNum (string strNum)
   {
      T num;
      std::stringstream strS(strNum);

      strS >> num;         
      return num;
   };

   /**
   \brief Функция удаления ведущих нулей в IP-адресе для его дальнейшего использования ОС
   \param _currentIp - строка, содержащая исходный адрес с возможными нулями
   \return возвращает строку, не содержащую ведущие нули
   */
   string eraseLeadingNulls(string _currentIp);

};

#endif
