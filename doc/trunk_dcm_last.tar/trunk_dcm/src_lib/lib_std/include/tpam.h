/**
   \file tpam.h
   \brief Описание класса TPam
   \author Зайцев А.А. Гусинская Е.И. Воронков Д.В. Устинова Е.А. Воронкова Т.В. Якунин С.А. Лихобабин Е.А.
   \version
   \date 19.05.2011
*/
/*---------------------------------------------------- tpam.h ------+
|     TOR              -=*  TPam Class  *=-                         |
+-------------------------------------------------------------------+
|     Started  18 May 2011                                          |
|     Last revision:                                                |
|              18 May 2011                                          |
+-------------------------------------------------------------------+
|     Purpose:   class for users identification                     |
|                                                                   |
|     Company:   NIIA Rayzan                                        |
|     Athours:   Zaytsev A.A, Likhobabin E.A.                       |
|     Usage:     by calling appropriate functions                   |
|                                                                   |
+------------------------------------------------------------------*/
#ifndef TPAM_H
#define TPAM_H

#include <grp.h>
#include <pwd.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include <iostream>
#include <security/pam_appl.h>

#define COPY_STRING(s) (s[0]!=0) ? strdup(s) : NULL      ///< определено условие

using namespace std; ///<пространство имен std


namespace _std
{
   /**
      \class TPam
      \brief Класс реализующий парольный вход пользователей в систему
   */
   class TPam
   {
      public:
         /**
         \brief Конструктор
         \param serviceName - имя файла конфигурации защиты приложения
         \param group - имя группы к которой принадлежат аутентифицируемые пользователи
         */
         TPam(string serviceName, string group);
         /**
         \brief Деструктор
         */
         ~TPam();
   
         /**
         \brief Проверка пароля, введенного пользователем
         \param userInserted - введенное имя пользователя
         \param passInserted - введенный пароль
         \return результат проверки пароля
         */
         bool checkPassword(string userInserted, string passInserted);
         /**
         \brief Добавление в систему пользователя без домашнего каталога
         \param name - пользователь для добавления
         \param passwd - пароль
         \return результат добавления
         */
         bool addUser(string name, string passwd);
         /**
         \brief Удаление из системы указанного пользователя
         \param name - пользователь для удаления
         \return результат удаления
         */
         bool delUser(string name);
         /**
         \brief Проверка модуля на принадлежность соответствующим сервису и группе
         \param serv - наименование сервиса
         \param grp - наименование группы
         \return true - если принадлежит и false если нет
         */
         bool isYoursServiceAndGroup(string serv, string grp);
         /**
         \brief Функция возвращает имя Группы
         \return имя группы
         */         
         string getGroupName();
         /**
         \brief Функция возвращает имя сервиса
         \return имя сервиса
         */         
         string getServiceName();
         /**
         \brief Функция возвращает список пользователей для данной группы
         \return елси все нормально, то список имен пользователей, разделенных запятыми, иначе "empty"
         */         
         string getUserListString();
      private:
         string serviceName;  ///имя файла конфигурации защиты приложения (располагается в pam.d)
         string group;        ///имя группы пользователей приложения  
   };
};


#endif
