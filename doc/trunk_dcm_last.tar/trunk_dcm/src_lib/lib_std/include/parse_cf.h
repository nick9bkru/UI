/**
   \file parse_cf.h
   \brief Описание класса TConfFileParser
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

#ifndef TPARSE_CF_H
#define TPARSE_CF_H 1 ///<инициализации для компиляции

#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

#define MAX_CHAR_INDEX 30 ///<максимальный индекс переменной типа char
#define MAX_INT_INDEX 10 ///<максимальный индекс переменной типа int

using namespace std;

namespace _std
{
   /**
   \struct myset
   \brief Структура с параметрами установок приложения
   */
   /**
   \typedef TSet
   \brief Определение типа с параметрами установок приложения
   */
   typedef struct myset
   {
   const char * name;            ///< имя
   char * value;           ///< значение
   const char * defvalue;        ///< значение по умолчанию
   const char * type;            ///< тип параметра
   } TSet;

   /**
   \typedef TConstSet
   \brief Определение типа с параметрами установок приложения
   */
   /**
   \struct constset
   \brief Определение типа с параметрами установок приложения
   */

   typedef struct constset
   {
   const char * name;            ///< имя
   const char * value;           ///< значение
   const char * defvalue;        ///< значение по умолчанию
   const char * type;            ///< тип параметра
   } TConstSet;



   /**
   \class TConfFileParser
   \brief Класс разбора конфигурационного файла
   */
   class TConfFileParser
   {
   public:

      /**
       * \brief Конструктор
       */
      TConfFileParser();
      /**
       * \brief Конструктор
       * @param set - указатель на параметры
       */
      TConfFileParser (TSet * set);
      /**
       * \brief Деструктор
       */
      ~TConfFileParser();
      /**
       * \brief Установка набора параиетров
       * @param aset - указатель на параметры
       */      
      void setSettingsList(TSet * aset);
      /**
       * \brief Функция добавления позволенных имен
       * @param name - имя
       * @param defValue - параметры по умолчанию
       * @param defType - типы по умолчанию
       */
      void addAllowedName (char *name, char * defValue = NULL, char * defType = NULL);
      /**
       * \brief Функция разбора файла
       * @param filename - имя файла
       * @param onlyAld - признак разбора только разрешенных параметров
       * @return признак успешного выполнения функции
       */
      int parse (const char * filename, bool onlyAld = false);
      /**
       * \brief Функция устанавливает параметры по умолчанию для всего набора параметров
       */
      void setDefault();

      /**
       * \brief Функция устанавливает параметры по умолчанию для указанного параметра
       * @param name  - имя
       */
      void setDefault (const char * name);

      /**
       * \brief Функция возвращает значения строковых параметров
       * @param name  - имя
       * @return значения строковых параметров
       */
      char * getCharValue (const char *name);
      /**
       * \brief Функция возвращает значения целочисленных параметров
       * @param name  - имя
       * @return значения целочисленных параметров
       */
      int * getIntValue (const char *name);
      /**
       * \brief Функция возвращает значения булевых параметров
       * @param name - имя
       * @return значения булевы параметров
       */
      bool getBoolValue (const char *name);
      /**
       * \brief Функция возвращает тип параметров
       * @param name - имя
       * @return тип параметра
       */
      const char * getType (const char * name);
      /**
       * \brief Функция устанавливает признак вывода процесса работы класса
       * @param verb - true - вывод, false - работать молча
       */      
      void setVerbosed(bool verb);
      
      
      static int INTVINDEX;      ///< индекс целочисленных параметров
      static int CHARVINDEX;     ///< индекс строковых параметров


   private:
      bool onlyAllowed;          ///< признак загрузки только предопределенных параметров
      bool verbosed;             ///< признак вербализации процесса парсинга
      TSet * listOfCouple;       ///< список пар параметров
      int IndexOfNewCouple;      ///< индекс новой пары
      /**
       * \brief Функция подготовки значений
       * @param name - имя
       * @param value - значение
       * @return признак успешного выполнения функции
       */
      bool prepareValue (const char *name, char * value);
      /**
       * \brief Функция возвращает индекс строковых параметров
       * @return индекс
       */
      int getCharIndex();
      /**
       * \brief Функция возвращает индекс целочисленных параметров
       * @return индекс
       */
      int getIntIndex();
      /**
       * \brief Функция находит пары для параметров
       * @param name - имя
       * @return пару для параметров
       */
      TSet * findCouple (const char * name);
      /**
       * \brief Функция разбирает строку файла
       * @param input - входная строка
       * @param argv - список с возвращаемыми элементами строки
       * @param delimiters - разделитли параметром
       * @param max_tokens - максимальное количество элементов в строке
       * @param quote - символ пробела
       * @return
       */
      int util_parse (char *input, char **argv, char *delimiters, int  max_tokens, char quote);
      /**
       * \brief Функция возвращает строку файла
       * @param fp - дескриптор файла
       * @param buffer - буфер данных
       * @param buflen - длина буфера
       * @param comment - символ коментария
       * @param lineno - параметр
       * @return
       */
      int util_getline (FILE *fp, char *buffer, int buflen, char comment, int *lineno);
      /**
       * \brief Функция очищает буфер
       * @param str - строка
       * @return указатель на ту же строку
       */
      char * cleanBlanck (char * str);

   };
};
#endif

