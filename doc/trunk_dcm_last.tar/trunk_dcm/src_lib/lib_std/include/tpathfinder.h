/**
   \file tpathfinder.h
   \brief Описание класса TPathFinder
   \author ЛихобабаниЕ.А., Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

//todo - на std::string
//todo - 86 строка - переделать /uims
#ifndef TPATHFINDER_H
#define TPATHFINDER_H 1 ///<инициализации для компиляции
/*--------------------------------------------- tpathfinder.h ------+
|     TOR        -=*  PathFinder Class  *=-                         |
+-------------------------------------------------------------------+
|     Started  9 Jun 2009                                           |
|     Last revision:                                                |
|              11 Jun 2009                                           |
+-------------------------------------------------------------------+
|     Purpose:   class for finding paths                           |
|                                                                   |
|     Company:   NIIA Rayzan                                        |
|     Athours:   Likhobabin E.A.                           |
|     Usage:     by calling appropriate functions                   |
|                                                                   |
+------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include <string.h>
#include <errno.h>



#define MAX_PATH_LENGTH     8192 ///< максимальная длина пути


// #define gsp_BIN         100
// #define gsp_LOG         101
// #define gsp_JOURNAL     102
// #define gsp_BUILD       103
namespace _std
{
   /**
   \enum TSpecificPathType
   \brief Перечисление целей
   */
   enum TSpecificPathType
   {
   gsp_BIN,       ///< путь до бинарного файла
   gsp_LOG,       ///< путь до файла логгирования
   gsp_JOURNAL,   ///< путь до файла с журналами
   gsp_BUILD,      ///< путь до файлас билдами
   gsp_BIN_EXE_WITHOUT_EXT  ///< имя исполняемого файла
   };

   using namespace std;

   /**
   \class TPathFinder
   \brief Класс получения путей проекта
   */
   class TPathFinder
   {
   private:
      static char target_path[MAX_PATH_LENGTH];    ///< путь до цели
      //string target_path;
      string newPath;         ///< путь до новой цели
   public:
      /**
       * \brief Конструктор
       */
      TPathFinder();
      /**
       * \brief Деструктор
       */
      virtual ~TPathFinder();
      /**
       * \brief Функция находит путь от корневой директории
       * @param numCutDir - число отбрасываемых элементов пути
       * @return путь
       */
      char* getAbsPath (int numCutDir = 2);
      /**
       * \brief Функция находит путь до заданной директории
       * @param specific - заданая директория
       * @return путь
       */
      virtual const char* getSpecificPath (TSpecificPathType specific);
      /**
       * \brief Функция проверяет существует ли файл, заданный путем
       * @param path - путь до файла
       * @return false - если нет файла по заданному пути, true - в остальных случаях
       */
      bool isFileExist(string path);

   };
};
#endif
