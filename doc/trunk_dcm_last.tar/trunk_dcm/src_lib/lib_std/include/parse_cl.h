/**
   \file parse_cl.h
   \brief Описание структур и функций для рабора файла параметров приложения
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

#ifndef TPARSE_CL_H
#define TPARSE_CL_H 1      ///<инициализации для компиляции

#include <ctype.h>
#include <stdio.h>

#define SUCCESS 1                   ///< признак успешности
#define ERROR 0                     ///< признак ошибки
#define ENV_PARAM_SET       0x0001  ///< признак набора параметров
#define ENV_PARAM_DFL       0x0002  ///< признак параметров по умолчанию
#define ENV_PARAM_VAL_REQ   0x0008  ///< признак значений параметров
#define ENV_FILE_SET        0x0010  ///< признак файла с параметрами
#define ENV_COMMND_SET      0x0100  ///< признак набора команд


namespace _std
{
   /**
   \struct env_item
   \brief Структура с параметрами установок приложения
   */
   /**
   \typedef ENV_ITEM
   \brief Определение типа с параметрами установок приложения
   */
   typedef struct env_item
   {
   char         key;  ///< ключ
   char   key_symbl;  ///< символ ключа
   int         flag;  ///< флаг
   const char *      name;  ///< имя
   const char *     value;  ///< значение
   const char *     usage;  ///< использование
   } ENV_ITEM;
   /**
   \struct env_time
   \brief Структура с таблицей событий
   */
   /**
   \typedef ENV_TABLE
   \brief Определение типа с таблицей событий
   */

   typedef struct env_time
   {
   char     *  programm; ///< программа
   int         table_sz; ///< таблица
   char     *     usage; ///< использование
   ENV_ITEM *     items; ///< указатель на таблицу событий
   } ENV_TABLE;




   /**
 * \brief Функция разобра окмандной строки
 * @param s - указатель на строку
 * @return признак успешного выполнения функции
 */
   int usage (const char * s);
   /**
 * \brief Функция устанавливает ключ
 * @param el - событие
 * @param argv - указатель на массив входных параметров
 * @return признак успешного выполнения функции
 */
   int ph_setkey (ENV_ITEM * el, char ** argv);
   /**
 * \brief Функция вызова парсера
 * @param _env_items - указатель на событие
 * @param argc - количество входных параметров
 * @param argv - указатель на массив входных параметров
 * @return признак успешного выполнения функции
 */
   int parseCall (ENV_ITEM * _env_items, int argc, char ** argv);
   /**
 * \brief Функция устанавливает парсер
 * @param el - указатель на событие
 * @param argv - указатель на массив входных параметров
 * @return признак успешного выполнения функции
 */
   int ph_setpar (ENV_ITEM * el, char ** argv);
   /**
 * \brief Функция возвращает адрес параметра
 * @param s - строка
 * @return признак успешного выполнения функции
 */
   char * _get_param_addr (char * s);
   /**
 * \brief Функция устанавливает ключ события
 * @param key - ключ
 * @return признак успешного выполнения функции
 */
   int ph_setenvkey (char key);
   /**
 * \brief Функция очищает ключ события
 * @param key - ключ
 * @return признак успешного выполнения функции
 */
   int ph_clrenvkey (char key);
   /**
 * \brief Функция проверки ключа события
 * @param key - ключ
 * @return признак успешного выполнения функции
 */
   int ph_tstenvkey (char key);
   /**
 * \brief Функция проверки ключа события по умолчанию
 * @param key  - ключ
 * @return признак успешного выполнения функции
 */
   int ph_tstenvkeydf (char key);
   /**
 * \brief Функция возвращает значение ключа
 * @param key - ключ
 * @return признак успешного выполнения функции
 */
   const void * ph_getkeyval (char key);
   /**
 * \brief Функция ищет указатель на событие по имени ключа
 * @param key - имя ключа
 * @return указатель на событие
 */
   ENV_ITEM  * _findenvkey (char key);
   /**
 * \brief Функция ищет указатель на событие по имени параметра
 * @param name - имя параметра
 * @return указатель на событие
 */
   ENV_ITEM  * _findenvname (char * name);
   extern ENV_TABLE *env_table; ///< таблица событий
   /*==========================================================================*/
};
#endif
