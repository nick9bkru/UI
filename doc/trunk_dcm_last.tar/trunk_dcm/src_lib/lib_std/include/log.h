/**
   \file log.h
   \brief Описание класса TLogSystem
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

#ifndef LOG_H
#define LOG_H 1  ///<инициализации для компиляции

/*------------------------------------------------- log.h ----------+
|     TOR    -=*  TOR Software Library  *=-   v. 1.01.A             |
+-------------------------------------------------------------------+
|     Started  19 Mar 2008 (v1.01)                                  |
|     Last revision:                                                |
|              19 Mar 2008                                           |
+-------------------------------------------------------------------+
|     Purpose: Loging of program events                             |                              |
|                                                                   |
|     Usage:  #include "../log.h"                                   |
+------------------------------------------------------------------*/



#include <stdio.h>

#define NOLOG    0    ///<уровень логирования 
#define USERLOG  1    ///<уровень логирования 
#define SV_LOG   2    ///<уровень логирования 
#define DEBUGLOG 3    ///<уровень логирования 
#define PARANOIC 4    ///<уровень логирования 



#define LOGLEVEL PARANOIC  ///<уровень логирования
namespace _std
{
   /**
   \class TLogSystem
   \brief Класс создания системы логирования
   */
   class TLogSystem
   {
   private:
      unsigned char loglevel;///<уровень логирования
      bool isReporting;                ///< признак отчета
      bool firstTime;                  ///< признак первоначального запуска
      /**
       * \brief Функция создает заголовок в файле
       */
      void makeHeader();
      /**
       * \brief Функция проверки заголовка
       * @return признак корректности заголовка
       */
      bool checkHeader();
      char N_day;                      ///<номер дня в году
      char strDate[12];                ///< строка, содержащая дату
      /**
                \brief Функция записи в файл
                \param str - указатель на строку с информацией
                \param un - указатель на строку с информацией
                */
      void log (char* str, char *un = NULL);
   public:
      /**
       * \brief Функция Проверки контрольной суммы
       * @return признак успешного выполнения функции
       */
      bool controlFileChecksum();
      bool ContinueLog;///<признак продолжения файла логирования
      char fileCheckSum[11];  ///< строка, содержащая контрольную сумму
      //TLogCounter * pCounter;///< указатель на штатный счетчик транзакций
      //TLogCounter beforeCounter;///< вспомогательный счетчик
      char filename[255];///<имя файла
      char* fn_template;///<образ имени файла
      /**
                \brief Функция создания имени файла
                \param fn - указатель на строку содержащую имя файла
               \param y - год
               \param m - месяц
               \param d - день
                */
      void CreateFileName (char* fn, int y = 0, int m = 0, int d = 0);


      /**
       * \brief Функция устанавливает уровень логгирования
       * @param ll - уровень логгирования
       */
      void setLogLevel (int ll);

      /**
      \brief Ссылка на внешнюю функцию
      \param str1 - строка содержащая информацию для логирования
      \param str2 - строка содержащая информацию для логирования
      */
      void (*ExtLogFunction) (char * str1, char * str2);
      /**
                \brief Функция  прикрепления внешней функции
                \param function - указатель на внешнюю функцию
                */
      void SetExtLogFunction (void (*function) (char * str1, char * str2));
      /**
                \brief Функция установки образца имени файла
                \param fn - образец имени файла
                */
      void SetFnTemplate (char * fn);


      FILE* fileid;///<указатель на файл логирования
      /**
                \brief функция открывает файл логирования
                \param y - год
               \param m - месяц
               \param d - день
               \param r - признак
                \return Результат.
                \retval true, если файл открыт
                \retval false, если файл открыть не удалось
           */
      bool OpenLog (int y = 0, int m = 0, int d = 0, bool r = false);
      /**
                \brief Функция записи в файл
                \param str - указатель на строку с информацией
                \param level - уровень логирования
                \param un = NULL - имя пользователя, работающего в системе
                */
      void log (char* str, unsigned char level, char * un = NULL); // ЩРНР КНЦ ХДЕР Б ТЮИК Х МЮ ЩЙПЮМ
      /**
               \brief Функция записи в файл
               \param str - указатель на строку с информацией
               \param a - численная информация
               \param level - уровень логирования
               \param un = NULL - имя пользователя, работающего в системе
               */
      void log (char* str, int a, unsigned char level, char * un = NULL);
      /**
                \brief Функция закрытия файла
                */
      void CloseLog();
      /**
      \brief Функция записи в файл
      \param str - указатель на строку с информацией
      \param a - вспомогательная информация
      \param level - уровень логирования
      \param un = NULL - имя пользователя, работающего в системе
      */
      void log (char* str, char* a, unsigned char level, char *un = NULL);
      /**
                \brief Функция вычисляет контрольную сумму по текущему времени и имени пользователя для исключения подмены имени пользователя в файле журнала событий
                \param name - имя пользователя
                \param time - текущее временя
               \param text - указатель на строку
                \return значение контрольной суммы
                */
      char * CS (char * name, char * time, char * text);

      /**
       * \brief Функция проверяет контрольную сумму
       * @param str  - указатель на строку
       * @return признак правильности контрольной суммы
       */
      bool checkCS (char * str);
      /**
      \brief Конструктор.
      */
      TLogSystem();

      /**
      \brief Конструктор.
      \param fn - образец имени файла
      */
      TLogSystem (char* fn);

      /**
      \brief Деструктор.
      */
      ~TLogSystem();

      /**
       * \brief Подготавливает отчет за сутки.
       * @param year - год
       * @param month - месяц
       * @param day -день
       * @return Признак успешного выполнения функции
       */
      bool prepareReports4Date (int year, int month, int day);
      /**
       * \brief Функция возвращает строку отчета
       * @param str - строка отчета
       * @return признак успешного выполнения функции
       */
      bool getReportString (char * str);
      /**
       * \brief закрывает отчет
       */
      void closeReport();

   };
};



#endif

