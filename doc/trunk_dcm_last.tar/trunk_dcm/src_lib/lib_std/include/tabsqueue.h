/**
   \file tabsqueue.h
   \brief Описание класса TAbsQueue.
   \author Зайцев А.А., Лихобабин Е.А.
   \version 2012-01-10
*/
#ifndef T_ABSTRACT_QUEUE_H
#define T_ABSTRACT_QUEUE_H

#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <iostream>
#include <list>
#include <errno.h>
#include <unistd.h>

#include "tabsmessage.h"

using namespace std;

// queue verbose level constants
#define qvl_VERBOSE_ALL  100             ///< Флаг для работы класса TAbsQueue
#define qvl_VERBOSE_EVENT  50            ///< Флаг для работы класса TAbsQueue   
#define qvl_VERBOSE_ERROR  10            ///< Флаг для работы класса TAbsQueue
#define qvl_VERBOSE_SILENT  0            ///< Флаг для работы класса TAbsQueue

namespace _std
{
   /**
      \class TAbsQueue
      \brief Класс описывающий очередь
   */
   class TAbsQueue
   {
      public:
         /**
         \brief Конструктор
         \param new_name - имя очереди
         \param count_number - число очередей
         \param verb - призак вывода отладочных сообщений на консоль
         */
         TAbsQueue (string new_name = "", int count_number = 1, int verb = qvl_VERBOSE_ERROR);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsQueue();
         int * heartBeatCounter;///< счетчик времени с последнего хартбита
         int * codogram_number;///<номер кодограммы
         TAbsMessage **hbLine;///< массив хартбитов по очередям

         TAbsMessage *genericMessage;///< Указатель на класс абстрактного сообщения

         TAbsMessage *(*messageFactory) ();///<Указатель на функцию
         /**
         * \brief Функция удаления сообщения из очереди
         * @param pattern - указатель на шаблон
         */
         virtual void delMessageFor (TAbsMessage * pattern);
         /**
         * \brief Функция поиски сообщения в очереди
         * @param pattern - указатель на шаблон
         */
         virtual void lookForMessage (TAbsMessage * pattern);
         /**
         * \brief Функция поиска сообщения в очереди отправляемых сообщений
         * @param ticket - указатель на шаблон
         * @return указатель на сообщение
         */	
         virtual TAbsMessage * getSentMessage(TAbsMessage * ticket);
         /**
         * \brief Функция запроса просроченных сообщений очереди
         * \return указатель на просроченное сообщение
         */
         virtual TAbsMessage * whosTimeIsUp();
         /**
         * \brief Функция устанавливает период опроса очереди
         * @param usec - время в микросекундах
         */
         virtual void timeStep (int usec);
         /**
         * \brief Функция чтения сообщения на отправку
         * @param data - указатель на сообщение
         * @param maxLen - размер выделенного под данные буфера
         * \return размер сообщения
         */
         virtual int read2Send (char *data, unsigned int maxLen);
         /**
         \brief Функция чтения принятого сообщения
         \param message - указатель на сообщение
         \return Результат
         \retval true, чтение прошло успешно
         \retval false, при чтении сообщения возникла ошибка
         */
         virtual bool readReceived (TAbsMessage ** message);
         /**
         \brief Функция установки сообщения в очередь на отправку
         \param message - указатель на сообщение
         \return Результат
         \retval true, установка сообщения прошла успешно
         \retval false, при установки сообщения возникла ошибка
         */
         virtual bool insert2Send (TAbsMessage * message);
         /**
         \brief Функция установки прочитанного сообщения в очередь
         \param message - указатель на сообщение
         \return Результат
         \retval true, установка сообщения прошла успешно
         \retval false, при установки сообщения возникла ошибка
         */
         virtual bool insertReceived (TAbsMessage * message);
         /**
         \brief Функция установки прочитанного сообщения в очередь
         \param data - указатель на буфер данных
         \param len - размер сообщения
         \param fromIp - адрес отправителя
         \return Результат
         \retval true, установка сообщения прошла успешно
         \retval false, при установки сообщения возникла ошибка
         */
         virtual bool insertReceived (char * data, int len);
         /**
         \brief Функция установки фабрики создания сообщений
         \param (*mf) - указатель на функцию фабрики сообщений
         */
         virtual void setFactory (TAbsMessage* (*mf) ());

         /**
         \brief Функция отображения очереди
         \param ln - вид списка: 's' - для очереди передачи, 'r' - для очереди приема
         */
         virtual void show (char ln);

         /**
         \brief Функция установки генераторного сообщения
         \param gm - указатель на генераторное сообщение
         */
         void setGenericMessage (TAbsMessage * gm);

         /**
         \brief Функция установки режима хартбита
         \param ishb - true - генерировать хартбит, иначе нет
         */
         void setHeartBeat (bool ishb);
         
         /**
         \brief Функция изменения имени очереди
         \param new_name - новое имя очереди
         */
         void setName( string new_name ) { name = new_name; };
         /**
         \brief Функция сброса таймера хартбитов заданной подочереди
         \param subQueueNumber - номер подочереди для которой выполняется сброс таймера
         */
         void resetHeartBeatTimer( int subQueueNumber = 0 );
      protected:
         pthread_mutex_t Mutex;                    ///< Мьютекс
         string          name;                     ///< имя очереди
         int             verbose;                  ///< призак вывода отладочных сообщений на консоль
         bool            *waitFlagPointer;         ///< признак ожидания квитанции на сообщение
         list<TAbsMessage*> sendingList;           ///< Список сообщений на отправку
         list<TAbsMessage*> receivingList;         ///< Список принятых сообщений
         /**
         * \brief Функция чтения сообщения на отправку
         * \return указатель на сообщение для отправки, или NULL если такого нет
         */
         TAbsMessage* readCdgrm2Send();
      private:
         int             subQueNumber;             ///< номер подочереди
         bool            isHeartBeat;              ///< признак наличия в сети
   };
};

#endif
