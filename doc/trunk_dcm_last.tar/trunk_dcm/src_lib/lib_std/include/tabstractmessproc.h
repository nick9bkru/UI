/**
   *\file tabstractmessproc.h
   *\brief Описание абстрактного класса TMessageProcessor - предка для всех обработчиков
   *\author Зайцев А.А. Лихобабин Е.А.
   *\version 
    \date 2011-01-01
*/

#ifndef TABSTRACTMESSPROC_H
#define TABSTRACTMESSPROC_H 1

#include <stdlib.h>
#include "time.h"

#include "tabsqueue.h"

#define DEFAULT_MESS_PROC_TIME_STEP 100000   ///< Шаг таймера обработки сообщений по умолчанию
#define LIB_NET_DEBUG 1                      ///< признак отладочной сборки библиотеки

namespace _std
{
   /**
      *\class  TAbstractMessProc
      *\brief Абстрактный класс обработки кодограмм.
   */
   class TAbstractMessProc
   {
      public:
         /**
         *\brief Конструктор
         */
         TAbstractMessProc();
         /**
         *\brief Деструктор
         */
         virtual ~TAbstractMessProc();
         /**
         * \brief функция запуска обработчика
         */
         void start();
         /**
         * \brief функция перезапуска обработчика после остановки по stop()
         */
         void restart();
         /**
         * \brief Функция необходимых команд инициализации после перезапуска обработчика
         */
         virtual void restartInit() {};
         /**
         * \brief однократный запуск обработчика
         * @param usec - время в микросекундах
         */
         virtual void step (int usec);
         /**
         * \brief обработка событий одной очереди
         * @param queue - указатель на очередь для обработки
         * @param usec - время в микросекундах
         */
         void oneQueueStep (TAbsQueue *queue, int usec);
         /**
         * \brief функция остановки обработчика
         */
         void stop();
         /**
         * \brief функция приостановки обработчика
         */
         void pause();
         /**
         * \brief функция очистки очередей
         */
         virtual void clearQueues ();
         /**
         * \brief функция запуска основного цикла обработки
         */
         virtual void run();
         /**
         *\brief Функция установки очередей
         * @param fstQue - указатель на первую очередь
         * @param secQue - указатель на вторую очередь
         */
         virtual bool setQueues (TAbsQueue *fstQue, TAbsQueue *secQue = NULL);
         /**
         *\brief Функция установки признака вербализации
         * @param v - true - для вывода....
         */
         void setVerbose(bool v);
         /**
         *\brief Функция установки периода опроса очередей
         * @param usec - период опроса в микросекундах
         */
         void setTimeStep (int usec);
         /**
         *\brief Функция возвращения периода опроса очередей
         * \return период опроса
         */
         int getTimeStep();
         /**
         *\brief Функция установки признака исполнения обработки сообщений в главном потоке
         *\brief то есть - если true, то уходим в бесконечный цикл,
         *\brief если false - создаем отдельный поток, в котором все обрабатывается никому не мешая.
         *\brief По умолчанию - false
         * @param mainLoopVal - признак исполнения в главном потоке
         */
         void setIsMainLoop (bool mainLoopVal);
         /**
         \brief Функция инициализации внешнего таймера, если он ести
         */
         virtual void initExtTimer();
         /**
         \brief Функция установки указателя на потоковую функцию
         \param void*(*funcName)(void*) указатель на потоковую функцию
         */
         void setRunFunc (void* (*funcName) (void*));
         /**
         *\brief Функция разбора команд первой очереди
         * @param message - указатель на сообщение
         */
         virtual void processFstMes (TAbsMessage *message);
         /**
         *\brief Функция разбора команд второй очереди
         * @param message - указатель на сообщение
         */
         virtual void processSecMes (TAbsMessage *message);
         /**
         * \brief Функция обработки не квитируемых кодограмм
         * @param message - указатель на сообщение
         */
         virtual void processNotCheckedMessage (TAbsMessage * message);
         /**
         * \brief Функция отправки сообщений в первую очередь
         * @param kdg - указатель на кодограмму
         *  @param size - размер кодограммы
         */
         TAbsMessage * sendMess2Fst (char *kdg, int size);
         /**
         * \brief Функция отправки сообщений во вторую очередь
         * @param kdg - указатель на кодограмму
         * @param size - размер кодограммы
         */
         TAbsMessage * sendMess2Sec (char *kdg, int size);
         /**
         * \brief Функция проверки наличия обмена харбитами между взаимодействующими узлами первой очереди
         * @return признак наличия обмена
         */
         bool isHeartBeatingFst();
         /**
         * \brief Функция проверки наличия обмена харбитами между взаимодействующими узлами второй очереди
         * @return признак наличия обмена
         */
         bool isHeartBeatingSec();
      protected:
         TAbsQueue    *fstQueue;             ///< указатель на первую очередь кодограмм
         TAbsQueue    *secQueue;             ///< указатель на вторую очередь кодограмм
         unsigned int fstProtocol;           ///< тип протокола первой очереди
         unsigned int secProtocol;           ///< тип протокола второй очереди
         int          timeStep;              ///< Период опроса очередей
         bool         runFlag;               ///< флаг запуска
         bool         stopFlag;              ///< флаг остановки процессора
         bool         isMainLoop;            ///< признак исполнения в главном потоке
         bool         isExtTimer;            ///< признак наличия внешнего таймера
         pthread_t    thread_id;             ///< Идентификатор потока
         bool         heartBeatingFst;       ///< Признак наличия обмена хартбитами по первой очереди
         bool         heartBeatingSec;       ///< Признак наличия обмена хартбитами по второй очереди
         bool         verbose;               ///< признак вербализации процесса обработки
                     

         /**
         * \brief Функция разбора сообщений первой очереди
         * @param message - указатель на кодограмму
         * @param toFst - указатель на указатель на кодограмму первой очереди
         * @param toSec - указатель на указатель на кодограмму второй очереди
         */
         virtual void decodeFst (TAbsMessage * message, TAbsMessage **toFst, TAbsMessage **toSec);
         /**
         * \brief Функция разбора сообщений второй очереди
         * @param message - указатель на кодограмму
         * @param toFst - указатель на указатель на кодограмму первой очереди
         * @param toSec - указатель на указатель на кодограмму второй очереди
         */
         virtual void decodeSec (TAbsMessage * message, TAbsMessage **toFst, TAbsMessage **toSec);
         void* (*runFuncName) (void * p);
   #ifdef LIB_STD_DEBUG
         /**
         * \brief Функция отсылки отладочных сообщений - функция вызывается каждый проход цикла
         * \brief Если нужно переодически отсылать какое-то сообщение - объявляй в потомках и описывай, что нужно
         */
         virtual void sendDebugMess();
   #endif

   };
};
#endif
