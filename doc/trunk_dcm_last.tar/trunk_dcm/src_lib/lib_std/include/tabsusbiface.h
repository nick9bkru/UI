/**
   \file tabsusbiface.h
   \brief Описание класса TAbsUsbIface.
   \author Лихобабин
   \version 
   \date 2012-02-22
*/
#ifndef TABSTRACT_USB_IFACE_H
#define TABSTRACT_USB_IFACE_H 1

#include <string>
#include <fcntl.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <map>

#include "ttypesniia.h"
#include "tabstractiface.h"
#include "tabsqueue.h"
#include "tabstractmessproc.h"

struct libusb_context;

namespace _std
{
   const a_u8char ENDPOINT_BULK_IN    = 0x82;
   const a_u8char ENDPOINT_BULK_OUT   = 0x01;
   
   struct TUsbIfaceTunes
   {
      int               checkNAStateUsec;
      int               checkOpenStateUsec;
      int               checkWorkStateUsec;
      a_u16int          vendorId;            ///< идентификатор производителя usb устройства
      a_u16int          productId;           ///< идентификатро usb устройства
      a_u8char          endPointIn;
      a_u8char          endPointOut;
      int               debugLevel;
      TAbstractMessProc *messproc;
      TAbsQueue         *queue;
   };
   struct TUsbIfaceStateTunes;
   /**
      \class TAbsUsbIface
      \brief Абстрактный интерфейс управления по последовательному порту  
   */
   class TAbsUsbIface: public TAbstractIface
   {
      public:
         /**
         \brief Конструктор
         \param ip - ip адрес
         \param pingTimingUsec - интервал времени для проверки наличия в сети
         */
         TAbsUsbIface (TUsbIfaceTunes *tunes);
         /**
         \brief Деструктор
         */
         virtual ~TAbsUsbIface();
         /**
         \brief Функция запуска тестирования
         */
         virtual void test();
         /**
         \brief Функция запроса указателя на класс состояния "в работе"
         \return указатель на абстрактный класс состояния интерфейса
         */
         TIfaceState* getAbsWork();
      protected:
//          void setQueue(TAbsQueue *queue);
         TAbsQueue           *queue;
         TAbstractMessProc   *messproc;
         TUsbIfaceStateTunes *stateTunes;    ///< указатель на настройки интерфейса последовательного порта
      private:
         libusb_context* context;
         
         TIfaceState *stateNA;
         TIfaceState *stateOpen;
         TIfaceState *stateWork;    ///< указатель на абстрактный класс проверки состояния сетевых интерфейсов
   };
};
  
#endif
