/**
   \file tsettings.h
   \brief Описание класса TSettings.
   \author Зайцев А.А.
   \version 2011-06-24
*/


#ifndef TSETTINGS_H
#define TSETTINGS_H 1


#include "lib_std.h"

namespace _std
{
   /**
 *\class  TSettings
 *\brief Класс чтения конфигурационного файла, 
 *\brief обработки командной строки и выдачи этих параметров по запросу приложения
 */

   class TSettings
   {
   public:
      /**
       * \brief Конструктор
       */
      TSettings();
      /**
       * \brief Конструктор
       * @param defSet - указатель на первый элемент массива структур TSet, где хранятся параметры конфигурационного файла
       * @param env_item - указатель на 1ый элемент массива структур ENV_ITEM, где хранятся ожидаемые параметры командной строки
       * @param argc - количество входных параметров командной строки из main()
       * @param argv - массив параметров командной строки из main()
       * @param fn - имя конфигурационного файла, если параметр опущен, то берется имя бинарника и прибавляется .conf, файл ищется в bin и в /etc
       * @param verb - делать подробнывй вывод или нет (true|false)               
       */
      TSettings(TSet * defSet, ENV_ITEM * env_item,int argc, char ** argv, string fn = "", bool verb = false);
      /**
       * \brief Конструктор
       * @param defSet - указатель на первый элемент массива структур TSet, где хранятся параметры конфигурационного файла
       * @param env_item - указатель на 1ый элемент массива структур ENV_ITEM, где хранятся ожидаемые параметры командной строки
       * @param argc - количество входных параметров командной строки из main()
       * @param argv - массив параметров командной строки из main()
       * @param fn - имя конфигурационного файла, если параметр опущен, то берется имя бинарника и прибавляется .conf, файл ищется в bin и в /etc
       * @param verb - делать подробнывй вывод или нет (true|false)
       */
      TSettings(TSet * defSet, ENV_ITEM * env_item, string fn = "", bool verb = false);
      /**
       * \brief Функция установки списка параметров файла конфигурации
       * @param defSet - указатель на первый элемент массива структур TSet, где хранятся параметры конфигурационного файла
       */
      void setSettingsList(TSet * defSet);
      /**
       * \brief Функция установки списка параметров командной строки
       * @param envItem - указатель на 1ый элемент массива структур ENV_ITEM, где хранятся ожидаемые параметры командной строки
       */
      void setArgumentsList(ENV_ITEM * envItem);
      /**
       * \brief Функция установки параметров приложения по умолчанию
       */
      void setDefaultSettings();
      /**
       * \brief Функция загрузки параметров
       * @param fn - имя файла
       * @return true - в случае успешной загрузки, иначе false
       */
      bool loadSettings (const char * fn = NULL);
      /**
       * \brief Функция чтения строкового параметра
       * @param settingName имя параметра
       * @return указатель на область памяти, где хранится значение данного параметра по крайней мере 10 вызовов этой функции
       */
      char * getChar (const char * settingName);
      /**
       * \brief Функция чтения целого параметра
       * @param settingName имя параметра
       * @return значение данного параметра 
       */
      int getInt (const char * settingName);
      /**
       * \brief Функция чтения булевого параметра
       * @param settingName имя параметра
       * @return значение данного параметра 
       */
      bool getBool (const char * settingName);
      /**
       * \brief Функция проверки на наличие флага с командной строки
       * @param keyname имя ключа без -
       * @return true если такой параметр имеется
       */
      bool testKey(char keyname);
      /**
       * \brief Функция чтения параметра командной строки
       * @param keyname имя ключа без -
       * @return содержимое командной строки для данного ключа в строковом виде
       */
      char * getKey(char keyname);
      /**
       * \brief Функция разбора командной строки при запуске приложения
       * @param argc - число входных параметров
       * @param argv[] - указатель на массив входных параметров
       */
      void parseComandString (int argc, char * argv[]);
      /**
       * \brief Функция установки имени файла параметров
       * @param fn - имя файла
       * @return true - в случае успеха и false - в противном случае
       */
      bool setCurSettingsFileName (const string fn);
      /**
       * \brief Функция установки имени файла по умолчанию для параметров
       * @return true - в случае успеха и false - в противном случае
       */
      bool setDefaultFileName();
      /**
       * \brief Функция установки флага вывода процесса разбора конфигурации
       * @param verb - true - полный вывод,false - молчание.
       */
      void setVerbosed (bool verb);
      /**
       * \brief Функция вывода сообщений времени выполнения
       * @param logstring - указатель на строку, которую нужно вывести
       */
      void logOut (const char * logstring);

   private:

      ENV_ITEM * env_default;       ///< указатель на массив с параметрами командной строки
      
      TPathFinder * path;           ///< указатель на объект поиска путей
      string curSettingsFileName;   ///< текущее имя файла с конфигурацией
      TSet * curSettings;           ///< указатель на массив ожидаемых параметров командной строки
      TConfFileParser * parser;     ///< указатель на объект декодирующий файл с установками проекта
      bool isSet;
      bool verbosed;                ///< флаг вербализации процесса разбора параметров

      /**
       * \brief Функция преобразования строкового значения в логическое
       * @param str - указатель на строку, которую нужно преобразовать
       * @return true - в случае если передано yes, false во всех других случаях
       */
      bool str2bool (char * str);  
      /**
       * \brief Функция проверки параметра на соответствие структуре ip адреса
       * @param ip - указатель на строку, которую нужно проверить
       * @return true - в случае если строка может быть правильным ip адресом
       */
      bool isIP (char * ip);
   };
};

#endif
