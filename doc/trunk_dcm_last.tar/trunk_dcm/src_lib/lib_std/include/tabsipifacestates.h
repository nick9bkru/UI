/**
   \file tabsipifacestates.h
   \brief Описание классов TAbsIpNA и TAbsIpPinging.
   \author Евгений Лихобабин
   \version 0.1
   \date 2011-06-11
*/
#ifndef TABS_IP_IFACE_STATES_H
#define TABS_IP_IFACE_STATES_H 1

#include "tabstractiface.h"
#include <stdlib.h>

namespace _std
{
   /**
 * @class TAbsIpNA
 * @brief Класс проверки состояний интерфейсов
 **/

   class TAbsIpNA: public TIfaceState
   {
   public:
      /**
      \brief Конструктор
      * @param checkTimingUsec - период проверки состояния
      */
      TAbsIpNA(int checkTimingUsec);
      /**
      \brief Деструктор
      */
      virtual ~TAbsIpNA();
      /**
      \brief Функция проверки состояния интерфейсов
      * @return результат проверки
      */
         virtual bool step();
   };

   /**
 * @class TAbsIpPinging
 * @brief Класс проверки наличия в сети
 **/
   class TAbsIpPinging: public TIfaceState
   {
   public:
      /**
      \brief Конструктор
      * @param ip - IP адрес
      * @param checkTimingUsec - период проверки состояния
      */
      TAbsIpPinging(string ip, int checkTimingUsec);
      /**
      \brief Деструктор
      */
      virtual ~TAbsIpPinging();
      /**
      \brief Функция проверки наличия в сети интерфейсов
      * @return результат проверки
      */
         virtual bool step();
   private:
      string ip; ///< IP адрес
   };
};
#endif
