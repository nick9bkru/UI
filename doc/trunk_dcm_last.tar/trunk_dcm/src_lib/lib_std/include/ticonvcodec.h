/**
   \file ticonvcodec.h
   \brief Описание класса TIconvCodec.
   \author Евгений Лихобабин
   \version 0.1
   \date 2011-05-23
*/
#ifndef TICONV_CODEC
#define TICONV_CODEC 1     ///<инициализации для компиляции

#include <iostream>
// #include <fstream>
// #include <list>
#include <cstring>
#include <string>
#include <cstdio>
#include <iconv.h>

using namespace std;  ///<пространство имен std


namespace _std
{
   /**
      \class TIconvCodec
      \brief Класс перекодировки символов
   */
   class TIconvCodec
   {
      public:
         /**
         \brief Конструктор
         */
         TIconvCodec (string toCode, string fromCode);
         /**
         \brief Деструктор
         */
         ~TIconvCodec();
         /**
          \brief Функция преобразования кодировок. Список кодировок можно посмотреть командой iconv -l.
          * @param input - входная строка в кодировке fromCode
          * @return Выходная строка в кодировке toCode.
          */
         string transcode(string input);
      private:
         iconv_t convDescr; ///< Дескриптор преобразования кодровок
   };
};
#endif
