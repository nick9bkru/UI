/**
   \file tabsipiface.h
   \brief Описание класса TAbsIpIface.
   \author Дмитрий Воронков
   \version 
   \date 2011-01-01
*/
#ifndef TABSTRACT_IP_IFACE_H
#define TABSTRACT_IP_IFACE_H 1

#include "tabstractiface.h"
#include "tabsipifacestates.h"

#include <string>
#include <fcntl.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <map>
#include "lib_std.h"

namespace _std
{
   /**
   \class TAbsIpIface
   \brief Интерфейс управления 
   */
   class TAbsIpIface: public TAbstractIface
   {
   public:
      /**
      \brief Конструктор
      \param ip - ip адрес
      \param pingTimingUsec - интервал времени для проверки наличия в сети
      */
      TAbsIpIface (string ip, int pingTimingUsec);
      /**
      \brief Деструктор
      */
      virtual ~TAbsIpIface();
      /**
      \brief Функция запуска тестирования
      */
      virtual void test();
      /**
      \brief Функция запроса указателя на класс проверки
      \return указатель на абстрактный класс проверки состояния сетевых интерфейсов
      */
      TIfaceState* getAbsIpPinging();
   private:
      TIfaceState* statePinging;///<указатель на абстрактный класс проверки состояния сетевых интерфейсов
   };
};
  
#endif
