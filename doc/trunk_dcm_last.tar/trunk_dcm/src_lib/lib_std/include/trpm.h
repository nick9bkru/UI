/**
   \file trpm.h
   \brief Описание класса TRpm
   \author ЛихобабаниЕ.А., Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 18.05.2011
*/

#ifndef TRPM_H
#define TRPM_H 1     ///< инициализация для компиляции
/*---------------------------------------------------- trpm.h ------+
|     TOR              -=*  TRpm Class  *=-                         |
+-------------------------------------------------------------------+
|     Started  18 May 2011                                          |
|     Last revision:                                                |
|              18 Jun 2011                                          |
+-------------------------------------------------------------------+
|     Purpose:   class for rpm verification                         |
|                                                                   |
|     Company:   NIIA Rayzan                                        |
|     Athours:   Likhobabin E.A.                                    |
|     Usage:     by calling appropriate functions                   |
|                                                                   |
+------------------------------------------------------------------*/

#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std; ///<пространство имен std

namespace _std
{
   /**
   \class TRpm
   \brief Класс работы с базой rpm пакетов
   */
   class TRpm
   {
      public:
         /**
         * \brief Конструктор
         */
         TRpm(string rpmName);
         /**
         * \brief Деструктор
         */
         ~TRpm();
         /**
         * \brief Функция выполняет проверку целостности заданного пакета
         * \brief при этом файлы с расширением .conf и именем nodetab игнорируются
         * @return результат верификации
         */
         bool verify();
         /**
         * \brief Функция выполняет проверку целостности всех файлов заданного пакета
         * @return результат верификации
         */
         bool verifyStrict();
      private:
         string rpmName;  ///имя верифицируемого пакета 
   };
};
#endif
