/**
   \file ttypesniia.h
   \brief Описание используемых типов данных.
   \author Лихобабин Е.
   \version 
   \date 2011-01-01
*/
#ifndef TTYPES_NIIA_H
#define TTYPES_NIIA_H 1

#ifndef a_u8char
   #define a_u8char   unsigned char   /* беззнаковый целый, 1 байт  */
#endif

#ifndef a_s16int
   #define a_s16int  short            /* знаковое целое,    2 байта */
#endif
#ifndef a_u16int
   #define a_u16int   unsigned short  /* беззнаковое целое, 2 байта */
#endif

#ifdef __64BIT_ARCH__
   #define a_s32int   int             /* знаковое целое,    4 байта */
   #define a_u32int   unsigned int    /* беззнаковое целое, 4 байта */
#else
   #define a_s32int   long            /* знаковое целое,    4 байта */
   #define a_u32int   unsigned long   /* беззнаковое целое, 4 байта */
#endif /* __64BIT_ARCH__ */





#define LINUX_32 1
#ifdef LINUX_32

#define U_INT_16 unsigned short
#define U_INT_32 unsigned int
#define U_INT_8 unsigned char

#define INT_16 short
#define INT_32 int
#define INT_8 char

#endif






#endif
