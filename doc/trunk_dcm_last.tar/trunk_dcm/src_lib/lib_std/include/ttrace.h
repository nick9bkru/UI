/**
   *\file ttrace.h
   *\brief Файл с описанием класса TTrace.
   *\author Зайцев А.А. Гусинская Е.И. Воронков Д.В. Устинова Е.А. Воронкова Т.В. Якунин С.А. Лихобабин Е.А.
   *\version 2010-06-18
*/
#ifndef TTRACE_H
#define TTRACE_H 1   ///<инициализации для компиляции

//#define NDEBUG_NIIA 1
/**
   \enum TDbgType
   \brief Перечисление пользователей
*/
enum TDbgType
{
   smc_RELEASE,      ///< релиз
   smc_TEST,         ///< тест
   smc_DEBUG,        ///< отладка
   smc_ALEX_DEBUG,   ///< Алексей
   smc_ELENA_DEBUG,  ///< Елена
   smc_DIMA_DEBUG,   ///< Дмитрий
   smc_JANE_DEBUG,   ///< Евгения
   smc_SERGEY_DEBUG, ///< Сергей
   smc_EUGEN_DEBUG,  ///< Евгений
   smc_TANYA_DEBUG,  ///< Татьяна
   smc_NOT_DEFINED,  ///< Не определен
};
#ifndef NDEBUG_NIIA
#define TRACE _std::TTrace()     ///< TRACE
#define ENDL(a) if (a == _std::TTrace::curDebugger) {cout << endl;} ///< ENDL
#define TRACE_FUNCTION_ENDL(a,b) if (a == _std::TTrace::curDebugger){cout << __FILE__ << " line:" << __LINE__ << " func: " << __PRETTY_FUNCTION__ << ":  " << b << endl;} ///< TRACE_FUNCTION_ENDL

#define TRACE_FUNCTION(a,b) if (a == _std::TTrace::curDebugger){cout << __FILE__ << " line:" << __LINE__ << " func: " << __PRETTY_FUNCTION__ << ":  " << b << " : ";}
///< TRACE_FUNCTION
//////////////Устаревшие//////////////////////////////
#define TRACE_ONE_MORE(a,b) if (a == _std::TTrace::curDebugger) {cout << b << " : ";} ///< TRACE_ONE_MORE
#define TRACE_ONE_MORE_ENDL(a,b) if (a == _std::TTrace::curDebugger) {cout << b << endl;} ///< TRACE_ONE_MORE_ENDL
//////////////Устаревшие//////////////////////////////
#else
#define TRACE_FUNCTION(a,b) void()     ///< TRACE_FUNCTION
#define TRACE_FUNCTION_ENDL(a,b) void()   ///< TRACE_FUNCTION_ENDL
#define TRACE void()       ///< TRACE
#define TRACE_ONE_MORE(a,b) void()     ///< TRACE_ONE_MORE
#define TRACE_ONE_MORE_ENDL(a,b) void()  ///< TRACE_ONE_MORE_ENDL
#define ENDL(a) void()        ///< ENDL
#endif

#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <stdarg.h>

using namespace std;

namespace _std
{
   /**
   \class TTrace
   \brief Класс вывода отладочных сообщений
   ```
   */
   // Используется вызовом макроса TRACE_FUNCTION(a,b)-где а - переменная типа TDebugType,
   //                                                      b - то что надо вывести на консоль, может быть любого типа, который поддерживает //cout <<
   // При этом формат вывода будет следующим: имя файла: строка с вызываемой функцией : имя функции : то, что выводили. Перевода на новую строку нет
   // Можно также использовать вызов макроса TRACE_ONE_MORE, при этом дополнительная информация о точке вызова выводится не будет, также не
   // будет перевода на новую строку.
   // Макрос TRACE_WITH_ENDL выводит то что нужно на консоль и выполняет перевод на новую строку.
   // При этом срабатывать будут толко те макросы, первый параметр которых совпадает со статическим членом curDebugger
   class TTrace
   {
   public:
      static TDbgType curDebugger;     ///< Текущий уровень отладки
      /**
       \brief Конструктор
       */
      TTrace();
      /**
       \brief Конструктор
      \param curDbgName - Текущий уровень отладки
       */
      TTrace (TDbgType curDbgName);
      /**
       \brief Переопределение оператора ()
       * @param whoDebug  - уровень отладки
       * @param arg - входной параметр для вывода
       */
      template <class T>
      void operator() (TDbgType whoDebug, T arg)
      {
         if (whoDebug == curDebugger)
            cout << arg << " : ";
         return;
      };
      /**
       \brief Переопределение оператора ()
       * @param whoDebug  - уровень отладки
       * @param arg1 - первый входной параметр для вывода
       * @param arg2 - второй входной параметр для вывода
       */
      template <class T1, class T2>
      void operator() (TDbgType whoDebug, T1 arg1, T2 arg2)
      {
         if (whoDebug == curDebugger)
            cout << arg1 << " : " << arg2 << " : ";
         return;
      };
      /**
       \brief Переопределение оператора ()
       * @param whoDebug  - уровень отладки
       * @param arg1 - первый входной параметр для вывода
       * @param arg2 - второй входной параметр для вывода
       * @param arg3 - третий входной параметр для вывода
       */
      template <class T1, class T2, class T3>
      void operator() (TDbgType whoDebug, T1 arg1, T2 arg2, T3 arg3)
      {
         if (whoDebug == curDebugger)
            cout << arg1 << " : " << arg2 << " : " << arg3 << " : ";
         return;
      };
   };
};

#endif
