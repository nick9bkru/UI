
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;

namespace _std
{
   enum enumTriggerState
   {
   ents_NOT_CHANGED = -1,
   ents_HOLDED = 0,
   ents_ON = 1,
   ents_OFF = 2
   };


   class TStateTrigger
   {
   public:
   TStateTrigger(string name);
   virtual ~TStateTrigger();
   virtual void setupTrigger(unsigned int onPeriod,unsigned int offPeriod);
   virtual void setOn();
   virtual void setOff();
   virtual void hold();
   virtual void change(bool newState);
   virtual int getState();
   virtual bool getSimpleState();
   virtual bool getChanged();
   virtual void setVerbose(bool verb);
   virtual void show();
   private:
   string triggerName; ///< имя триггера (в информационных целях)
   unsigned int counterOn;///< счетчик положительных подтверждений
   unsigned int counterOff;///< счетчик отрицательных подтверждений
   bool ON_OFF;  ///< состояние триггера
   unsigned int OFF_PERIOD;
   unsigned int ON_PERIOD;
   pthread_mutex_t Mutex;///<Мьютекс
   const char* count; 
   bool verbose; ///< признак вербализации выполнения операций   
   bool holded;
   protected:
   bool isChanged;///<флаг наличия изменений
   };
};


