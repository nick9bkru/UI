/**
   \file tabsusbifacestates.h
   \brief Описание классов TAbsUsbNA и TAbsUsbOpen.
   \author Евгений Лихобабин
   \version 0.1
   \date 2012-02-22
*/
#ifndef TABS_USB_IFACE_STATES_H
#define TABS_USB_IFACE_STATES_H 1

#include <stdlib.h>
#include <termios.h>
#include <fcntl.h>
#include <iostream>
#include <fstream>

#include "tabstractiface.h"
#include "tabsqueue.h"
#include "tabstractmessproc.h"
#include "ttypesniia.h"
#include "libusb.h"

using namespace std;

namespace _std
{  
   struct TUsbIfaceTunes;
   struct TUsbIfaceStateTunes
   {
      TUsbIfaceTunes       *ifaceTunes;
      TAbsQueue            *queue;
      libusb_device_handle **devHandle;
      libusb_context       *context;
   };

   
   /**
   * @class TAbsUsbNA
   * @brief Класс определяющий поведение интерфейса в состоянии "недоступен"
   **/
   class TAbsUsbNA: public TIfaceState
   {
      public:
         /**
         * \brief Конструктор
         * @param checkTimingUsec - период проверки состояния
         */
         TAbsUsbNA(int checkTimingUsec);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsUsbNA();
         /**
         * \brief Функция проверки состояния интерфейсов
         * @return результат проверки
         */
         virtual bool step();
   };

   /**
   * @class TAbsUsbOpen
   * @brief Класс определяющий поведение интерфейса в состоянии "открытие порта"
   **/
   class TAbsUsbOpen: public TIfaceState
   {
      public:
         /**
         * \brief Конструктор
         * @param device - блочное устройство, например /dev/ttyUSB0
         * @param checkTimingUsec - период проверки состояния
         */
         TAbsUsbOpen(TUsbIfaceStateTunes tunes);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsUsbOpen();
         /**
         * \brief Функция проверки наличия в сети интерфейсов
         * @return результат проверки
         */
         virtual bool step();
      private:
         libusb_device_handle **devHandle;         ///< укзатель на открытое Usb устройство
         libusb_context       *context;            ///< текущий контекст работы с usb интерфейсом
         TAbstractMessProc    *messproc;           ///< указатель на абстрактный обработчик сообщений 
         a_u16int             vendorId;            ///< идентификатор производителя usb устройства
         a_u16int             productId;           ///< идентификатро usb устройства
   };

   
   const unsigned int MAX_USB_BUFF_SIZE = 4096;
   /**
   * @class TAbsUsbWork
   * @brief Класс определяющий поведение интерфейса в состоянии "в работе"
   **/
   class TAbsUsbWork: public TIfaceState
   {
      public:
         /**
         * \brief Конструктор
         * @param checkTimingUsec - период проверки состояния
         */
         TAbsUsbWork(TUsbIfaceStateTunes tunes);
         /**
         * \brief Деструктор
         */
         virtual ~TAbsUsbWork ();
         /**
         * \brief Функция проверки наличия в сети интерфейсов
         * @return результат проверки
         */
         virtual bool step ();
      protected:
         /**
         * \brief Функция записи сообщения в порт
         * @return результат выполнения записи сообщения в порт
         */
         virtual bool send ();
         /**
         * \brief Функция чтения данных из порта 
         * @return результат чтения данных из порта
         */
         virtual bool read ();
      private:
         TAbsQueue            *queue;           ///< очередь сообщений для дальнейшей обработки
         TAbstractMessProc    *messproc;        ///< указатель на абстрактный обработчик сообщений 
         a_u8char             endPointIn;       ///< точка чтения из устройства
         a_u8char             endPointOut;      ///< точка записи в устройство
         libusb_device_handle **devHandle;      ///< указатель на usb устройство, с которым идет работа
         bool                 isRequestSended;  ///< флаг наличия отправленного запроса
         /**
         * \brief Функция корректного завершения работы с usb портом 
         */
         void closeUsb();
   };
};
#endif


