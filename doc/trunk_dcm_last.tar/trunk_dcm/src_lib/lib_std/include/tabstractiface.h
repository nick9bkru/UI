/**
   \file tabstractiface.h
   \brief Описание класса TIfaceState, TAbsIfaceObserver и TAbstractIface.
   \author Евгений Лихобабин
   \version 0.1
   \date 2011-06-07
*/
#ifndef TABSTRACT_IFACE_H
#define TABSTRACT_IFACE_H 1

#include <cstdio>
#include <iostream>
#include <list>

using namespace std;

namespace _std
{
   /**
 * @class TIfaceState
 * @brief Абстрактный класс проверки состояния сетевых интерфейсов
 **/
   class TIfaceState
   {
   public:
      /**
      \brief Конструктор
      */
      TIfaceState(int checkTimingUsec);
      /**
      \brief Деструктор
      */
      virtual ~TIfaceState();
       /**
      \brief Абстрактная функция запуска проверки состояния интерфейса
      * @return результат проверки
      */
      virtual bool step() = 0;
       /**
      \brief Абстрактная функция приостановки проверки состояния интерфейса
      */
      virtual void pause();
      /**
      * @brief Функция запроса следующего состояния интерфейса
       * @return указатель на состояние следующего интерфейса
       **/
      TIfaceState* getNextState();
      /**
      * @brief Функция запроса предыдущего состояния интерфейса
       * @return указатель на состояние предыдущего интерфейса
       **/
      TIfaceState* getPrevState();
      /**
      * @brief Функция установки следующего состояния интерфейса
       * @param state - указатель на состояние следующего интерфейса
       **/
      void setNextState(TIfaceState* state);
      /**
      * @brief Функция установки предыдущего состояния интерфейса
       * @param state - указатель на состояние предыдущего интерфейса
       **/
      void setPrevState(TIfaceState* state);
      /**
      * @brief Функция получения вспомогательной переменной описания состояния
      * @return описание состояние интерфейса
      **/
      string getSayStr();
      /**
      * @brief Функция установки вспомогательной переменной описания состояния
      * @param описание состояние интерфейса
      **/
      void setSayStr(string sayStr);
   private:                                             
      int  checkTimingUsec;         ///< Период опроса интерфейса
      string sayStr;                ///< Вспомогательная строковая переменная описания состояния инетрфейса
      TIfaceState* nextState;       ///< указатель на следующее состояние интерфейса
      TIfaceState* prevState;       ///< указатель на предыдущее состояние интерфейса
   };

   class TAbstractIface;  ///< Абстрактный класс интерфейсов
   /**
 * @class TAbsIfaceObserver
 * @brief Абстрактный класс обозревателя интерфейсов
 **/
   class TAbsIfaceObserver
   {
   public:
      /**
      \brief Конструктор
      * @param iface - указатель на интерфейс
      */
      TAbsIfaceObserver(TAbstractIface* iface);
      /**
      \brief Деструктор
      */
      virtual ~TAbsIfaceObserver();
      /**
      \brief Функция обновления
      */
      virtual void update() = 0;
      /**
      \brief Функция возвращает номер интерфейса
      * @return номер интерфейса
      */
      unsigned int getNum();
   private:
      TAbstractIface* iface;  ///< указатель на интерфейс
      static unsigned int num; ///< номер интерфейса
   };

   /**
   \class TAbstractIface
   \brief Абстрактный класс интерфейсов
   */
   class TAbstractIface
   {
   public:
      /**
      \brief Деструктор
      */
      virtual ~TAbstractIface();
       /**
      \brief Функция тестирования
      */
      void test();
       /**
      \brief Функция запуска интерфейса
      * @return признак успешного выполнения фукнции
      */
      bool start();            
       /**
         \brief Функция добавления состояния интерфейса
       * @param state - указатель на состояние интерфейса
      */
      void addState(TIfaceState* state);
       /**
         \brief Функция удаления состояния интерфейса
         * @param state - указатель на состояние интерфейса
         */
         void delState(TIfaceState* state);
         /**
      \brief Функция очистки списка
      */
      void clearList();
       /**
      \brief Функция запроса состояния интерфейса
      * @return указатель на состояние интерфейса
      */
      TIfaceState* getState();
       /**
      \brief Функция установки состояния интерфейса
       * @param state - указатель на состояние интерфейса
      */
      void setState(TIfaceState* state);
   //       void attach(TAbsIfaceObserver* observer);
   //       void detach(TAbsIfaceObserver* observer);
   //       void notify();
       /**
      \brief Функция запроса указателя на список состояний
      * @return указатель на список состояний
      */
      list<TIfaceState*>* getStateList();
   //       virtual void update() = 0;
      /**
      \brief Функция возвращает номер интерфейса
      * @return номер интерфейса
      */
      unsigned int getNum() {return num;};
   protected:
      /**
      \brief Конструктор
      */
      TAbstractIface ();
      pthread_t threadId;           ///< Идентификатор потока опроса устройства, соответсвующего интерфейсу
      bool runFlag;                 ///< Флаг запуска
      TIfaceState* currState;       ///< Текущие состояние
   private:
      pthread_mutex_t listMutex;    ///< Мьютекс
      list<TIfaceState*> stateList; ///< Список состояний
   //       list<TAbsIfaceObserver*> observers;
      /**
      * @brief Запуска процесса
      **/
      void run();
      /**
      * @brief Запуска процесса
      *  @param p - указатель на процесс
      **/
      static void * runFunc (void * p);
      static unsigned int num;         ///< номер интерфейса
   };
};
#endif

