/**
   \file log.cpp
   \brief Реализация класса TLogSystem
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/


/*------------------------------------------------- log.cpp --------+
|     TOR    -=*  TOR Software Library  *=-   v. 1.01.A             |
+-------------------------------------------------------------------+
|     Started  10 Sep 2007 (v2.01)                                  |
|     Last revision:                                                |
|              26 Jun 2009                                          |
+-------------------------------------------------------------------+
|     Purpose: Loging of program events                             |
|                                                                   |
|     Usage: For creating object TLogSystem must give template of   |
|            file name:                                             |
|                   if fn="ttt_%data___.log"                        |
|                   then file name: ttt_2008_02_07___.log           |
|             TLogSystem(char* fn);                                 |
|            For opening log file                                   |
|             bool OpenLog();                                       |
|            For writening in log file use following function       |
|             void log(char* str);                                  |
|             void log(char* str, unsigned char loglevel);          |
|             void log(char* str, int a, unsigned char loglevel);   |
|            For closing log file                                   |
|             void CloseLog();                                      |
|            For connection extension function                      |
|             void SetExtLogFunction(void(*function)                |
|                                    (char * str, char * str ))     |
|                                                                   |
+------------------------------------------------------------------*/

#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "log.h"
#include <sys/types.h>
#include <unistd.h>

namespace _std
{

   /*------------------------------------------------------------------*/
   TLogSystem::TLogSystem()
   {

   };

   /*------------------------------------------------------------------*/
   TLogSystem::TLogSystem (char* fn)
   {
   fn_template = fn;
   /*   beforeCounter.counter.counter = 0;
      beforeCounter.counter.zeros = 0;
      pCounter = &beforeCounter;   */
   };
   /*------------------------------------------------------------------*/
   TLogSystem::~TLogSystem()
   {
   CloseLog();
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::CreateFileName (char* fn, int y, int m, int d)
   {
   char *a;
   char ds[15];
   struct tm *t;
   time_t tt;


   time (&tt);
   t = localtime (&tt);

   a = strstr (fn_template, "%date");

   if (a == NULL)
   {
      strcpy (fn, fn_template);
      N_day = -1;
      return;
   }
   else
   {
      if ( (y == 0) || (m == 0) || (d == 0))
      {
         if (strftime (ds, 11, "%Y_%m_%d", t))
         {
            strncpy (fn, fn_template, (a - fn_template));
            fn[ (a-fn_template) ] = 0;
            strcat (fn, ds);
            strcat (fn, (char*) (a + 5));
            N_day = t->tm_mday;
         }
         else
         {
            strcpy (fn, fn_template);
         };
      }
      else
      {
         strncpy (fn, fn_template, (a - fn_template));
         fn[ (a-fn_template) ] = 0;
         sprintf (ds, "%4d_%02d_%02d", y, m, d);
         strcat (fn, ds);
         strcat (fn, (char*) (a + 5));
      };
   }
   };

   /*------------------------------------------------------------------*/
   bool TLogSystem::OpenLog (int y, int m, int d, bool r)
   {
   char FN[255];
   char om[5];

   if (fileid != NULL)
      CloseLog();

   if (r)
   {
      firstTime = false;
      isReporting = true;
      strcpy (om, "r+");
      CreateFileName (FN, y, m, d);
   }
   else
   {
      CreateFileName (FN);
      if (!ContinueLog)
      {
         strcpy (om, "w+");
         firstTime = true;
      }
      else
      {
         if ( (fileid = fopen (FN, "r")) == NULL)
         {
            firstTime = true;
            strcpy (om, "w+");
         }
         else
         {
            if (checkHeader())
            {
               firstTime = false;
               fclose (fileid);
               strcpy (om, "r+");
            }
            else
            {
               firstTime = true;
               strcpy (om, "w+");
            };
         }
      }
      isReporting = false;
   }

   if ( (fileid = fopen (FN, om)) == NULL)
   {
      return false;
   }

   if (firstTime)
      makeHeader();

   strcpy (filename, FN);

   return true;
   };

   void TLogSystem::setLogLevel (int ll)
   {
   loglevel = ll;
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::makeHeader()
   {
   struct tm *t;
   time_t tt;

   time (&tt);
   t = localtime (&tt);
   strftime (strDate, 12, "%d.%m.%Y", t);

   fseek (fileid, 0, SEEK_SET);
   fprintf (fileid, "################################################################################\n");
   fprintf (fileid, "# ����� � ������ ��-���-�������� �� ���� %s                            #\n", strDate);
   fprintf (fileid, "# REPORT ASKU VER.                                                         #\n");
   fprintf (fileid, "# FILE_CHECK_SUM = 000000000                                                   #\n");
   fprintf (fileid, "#                                                                              #\n");
   fprintf (fileid, "################################################################################\n");
   fprintf (fileid, "#  �����  |  ��������  |    ���   |                 �������                     \n");
   fprintf (fileid, "#---------|------------|----------|---------------------------------------------\n");
   strcpy (fileCheckSum, "0000000000");
   }

   /*------------------------------------------------------------------*/
   bool TLogSystem::checkHeader()
   {
   char s[255];
   fseek (fileid, 0, SEEK_SET);
   fgets (s, 100, fileid);
   fgets (s, 100, fileid);
   if (strncmp (s, "# �����", 7))
      return false;
   strncpy (strDate, &s[41], 11);
   fgets (s, 100, fileid);
   if (strncmp (s, "# REPORT", 7))
      return false;
   fgets (s, 100, fileid);
   if (strncmp (s, "# FILE_CHECK_SUM", 13))
      return false;
   for (int i = 19;i < 29; i++)
      if ( (s[i] < 0x30) || (s[i] > 0x6f))
         return false;

   strncpy (fileCheckSum, &s[19], 10);
   return (true);
   }

   /*------------------------------------------------------------------*/
   bool TLogSystem::controlFileChecksum()
   {
   char cs1[11];
   char cs2[11];
   char b[11];
   char str[255];

   strcpy (cs2, "0000000000");
   fseek (fileid, 243, SEEK_SET);
   if (fgets (str, 100, fileid) == NULL)
      return false;
   strncpy (cs1, &str[19], 10);
   cs1[10] = 0x0;
   //printf("a= %s| cs1= %s\n",a,cs1);

   if (fgets (str, 100, fileid) == NULL)
      return false;
   if (fgets (str, 100, fileid) == NULL)
      return false;
   if (fgets (str, 100, fileid) == NULL)
      return false;


   while (fgets (str, 100, fileid) != NULL)
   {
      if (str[0] == '#')
         continue;

      strncpy (b, &str[12], 10);
      b[10] = 0;

      for (int i = 0; i < 10;i++)
         cs2[i] = ( (cs2[i] + b[i] - 0x60) & 0x3f) + 0x30;
   }

   if (strncmp (cs1, cs2, 10) == 0)
   {
      return true;
   }
   else
   {
      return false;
   }
   }

   /*------------------------------------------------------------------*/
   void TLogSystem::SetExtLogFunction (void (*function) (char * str1, char * str2))
   {
   if (function != NULL)
      ExtLogFunction = function;
   }

   /*------------------------------------------------------------------*/
   void TLogSystem::log (char* str, char *un)
   {
   char message[255];
   char userName[11];
   struct tm *t;
   time_t tt;
   char str_time[12];
   char localCheckSum[11];
   int nameLength;

   if (firstTime)
   {
      makeHeader();
      firstTime = false;
   }

   time (&tt);
   t = localtime (&tt);
   strftime (str_time, 12, " %H:%M:%S ", t);

   if (t->tm_mday != N_day)
   {
      OpenLog();
   }

   if (str == NULL)
      strcpy (message, "Empty Message");
   else
      strcpy (message, str);

   strcpy (userName, "          ");
   if (un != NULL)
   {
      nameLength = strlen (un);
      for (int i = 0; (i < 8) && (i < nameLength); i++)
         userName[i+1] = un[i];
   }
   userName[10] = 0x0;

   if (strlen (message) < 11)
      strcat (message, "          \0");
   if (strlen (message) > 50)
      message[50] = 0x0;

   strcpy (localCheckSum, CS (userName, str_time, message));
   for (int i = 0; i < 10;i++)
      fileCheckSum[i] = ( (fileCheckSum[i] + localCheckSum[i] - 0x60) & 0x3f) + 0x30;

   if (!isReporting)
   {
      fseek (fileid, 0, SEEK_END);
      fprintf (fileid, "%s| %s |%s| %s\n", str_time, localCheckSum, userName, message);

      fseek (fileid, 245, SEEK_SET);
      fprintf (fileid, "FILE_CHECK_SUM = %s ", fileCheckSum);
   };

   if (loglevel <= USERLOG)
      if (ExtLogFunction != NULL)
         ExtLogFunction (message, NULL);
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::log (char* str, unsigned char level, char *un)
   {
   char message[255];

   if (level > loglevel)
      return;

   if (fileid == NULL)
      return;

   if (str == NULL)
      strcpy (message, "Empty Message");
   else
      strcpy (message, str);

   log (message, un);
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::log (char* str, int a, unsigned char level, char *un)
   {
   char message[255];

   if (level > loglevel)
      return;

   if (fileid == NULL)
      return;

   if (str == NULL)
      strcpy (message, "Empty Message");
   else
      sprintf (message, "%s %d ", str, a);

   log (message, un);
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::log (char* str, char* a, unsigned char level, char *un)
   {
   char message[255];

   if (level > loglevel)
      return;

   if (fileid == NULL)
      return;

   if (str == NULL)
      strcpy (message, "Empty Message");
   else
      sprintf (message, "%s %s", str, a);

   log (message, un);
   };


   /*------------------------------------------------------------------*/
   void TLogSystem::SetFnTemplate (char * fn)
   {
   fn_template = fn;
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::CloseLog()
   {
   if (fileid != NULL)
      fclose (fileid);
   };



   /*------------------------------------------------------------------*/
   char *TLogSystem::CS (char * name, char * time, char * text)
   {
   static char aaa[11];
   char bbb[] = "3.1415926535891932385";
   char txt[11];


   strncpy (txt, text, 10);
   txt[10] = 0x0;

   for (int i = 0; i < 10; i++)
      aaa[i] = (0x3f & (bbb[i] + name[i] - time[i] + txt[i] - strDate[i])) + 0x30;


   aaa[10] = 0x0;

   return &aaa[0];
   };

   /*------------------------------------------------------------------*/
   bool TLogSystem::checkCS (char * str)
   {
   char * ncs;
   char * cs;

   if (strlen (str) < 36)
      return false;

   if (strlen (str) < 47)
      strcat (str, "          ");

   ncs = CS (&str[24], &str[0], &str[36]);
   cs = &str[12];

   if (strncmp (ncs, cs, 10) == 0)
      return true;
   else
      return false;
   };

   /*------------------------------------------------------------------*/
   bool TLogSystem::prepareReports4Date (int year, int month, int day)
   {
   if (OpenLog (year, month, day, true))
   {
      if (!controlFileChecksum())
      {
         fseek (fileid, 326, SEEK_SET);
         fprintf (fileid, "# ��������!!! ����������� ����� �� ���������!!! ���� ��� ��������� �������!!!");
      }
      else
      {
         fseek (fileid, 326, SEEK_SET);
         fprintf (fileid, "# �������� ����������� ����� ������ ������� !!!                              ");
      };
      isReporting = false;
      fseek (fileid, 0, SEEK_SET);
      return true;
   }
   else
   {
      OpenLog();
      return false;
   }
   };

   /*------------------------------------------------------------------*/
   bool TLogSystem::getReportString (char * str)
   {
   if (fgets (str, 100, fileid) == NULL)
   {
      return false;
   }
   else
   {
      if (str[0] == '#')
         return true;
      if (!checkCS (str))
         strcpy (&str[37], " ### �������� !!! ������� ������ ������� !!! ###");
      return true;
   }
   };

   /*------------------------------------------------------------------*/
   void TLogSystem::closeReport()
   {
   isReporting = true;
   ContinueLog = true;
   OpenLog();
   };
};
/*==================================================================*/
