/**
   \file tabsusbiface.cpp
   \brief Описание класса TAbsUsbIface.
   \author Лихобабин
   \version 
   \date 2012-02-22
*/
#include "tabsusbiface.h"
#include "tabsusbifacestates.h"


namespace _std
{

   TAbsUsbIface::TAbsUsbIface (_std::TUsbIfaceTunes *tunes)
   {  
      stateTunes = new TUsbIfaceStateTunes;
      context = NULL;
      int ret = libusb_init(&context);
      if ( ret < 0 )
      {
         cout << "TAbsUsbIface::TAbsUsbIface: Error: can't init libusb with err code = " << ret << endl;
      };
      
      libusb_set_debug(NULL, tunes->debugLevel);
      
      
      
      stateTunes->ifaceTunes = tunes;
      
      
      stateTunes->queue     = tunes->queue;
      queue                 = stateTunes->queue;
//       stateTunes->queue      = new TAbsQueue( "abs_usb_queue", 1, qvl_VERBOSE_EVENT );     
      stateTunes->devHandle  = new libusb_device_handle*;
      stateTunes->context    = context;
            
      stateNA = new TAbsUsbNA(tunes->checkNAStateUsec);
   
      addState(stateNA);
      stateNA->setPrevState(stateNA);

      
      stateOpen = new TAbsUsbOpen(*stateTunes);

      addState(stateOpen);
      stateNA->setNextState(stateOpen);      
      stateOpen->setPrevState(stateNA);
      
      stateWork = new TAbsUsbWork(*stateTunes);

      addState(stateWork);   
      stateOpen->setNextState(stateWork);
      stateWork->setPrevState(stateNA);
      stateWork->setNextState(stateWork);
      
   //    start();
   };

   void TAbsUsbIface::test()
   {
      return;
   };

   TAbsUsbIface::~TAbsUsbIface()
   {
      runFlag = false;
      delete stateTunes->queue;
      pthread_cancel (threadId);
      clearList();
      delete stateTunes->devHandle;   //????????
      libusb_exit(context);
   };

   TIfaceState* TAbsUsbIface::getAbsWork()
   {
      return stateWork;
   };
   
//    void TAbsUsbIface::getQueue(TAbsQueue *queue)
//    {
//       *this->queue = queue;
//    };
   
};

