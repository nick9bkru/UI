/**
   \file tabsserialifacestates.cpp
   \brief Реализация классов TAbsUsbNA, TAbsUsbPinging.
   \author Лихобабин
   \version 0.1
   \date 2011-12-16
*/
#include "tabsserialifacestates.h"


namespace _std
{
   TAbsSerialNA::TAbsSerialNA(int checkTimingUsec):TIfaceState(checkTimingUsec)
   {
      setSayStr("TAbsSerialNA");

//       libusb_init(NULL);
//       libusb_set_debug(NULL,3);
//       if (r < 0)
//          return r;
   };

   TAbsSerialNA::~TAbsSerialNA()
   {
   };

   bool TAbsSerialNA::step()
   {
      return true;   
   };

   //-------------------------------------------------------------------------------------------------//
   TAbsSerialOpen::TAbsSerialOpen(TSerialIfaceStateTunes tunes):TIfaceState(tunes.ifaceTunes->checkOpenStateUsec)
   {
      this->device         = tunes.ifaceTunes->device;
      this->portDescr      = tunes.portDescr;
      this->messproc       = tunes.ifaceTunes->messproc;         
      this->usePortOptions = tunes.ifaceTunes->usePortOptions;
      this->portOptions    = tunes.ifaceTunes->portOptions;
      this->portFlags      = tunes.ifaceTunes->flags;
//       this->handle         = tunes.handle;
      setSayStr("TAbsSerialOpen");
   };

   TAbsSerialOpen::~TAbsSerialOpen()
   {
   };
   
   a_u16int CA418_VENDOR_ID  = 0x0101;
   a_u16int CA418_PRODUCT_ID = 0x090e;
   
   bool TAbsSerialOpen::step()
   {
      fstream port;
//       port.open(device.c_str(), ios::in | ios::out | ios::binary);
//       *handle = libusb_open_device_with_vid_pid(NULL, CA418_VENDOR_ID, CA418_PRODUCT_ID);
//       cout << "Is open = " << port.is_open() << endl;
//       if (!*handle)
//       {
//          cout << "can't open device " << endl;
//          return false;
//       };
   //    int flags = ;

//       *portDescr = open( device.c_str(), portFlags );
// 
//       if ( *portDescr == -1 )
//       {
//          perror("open");
//          return false;
//       };

      
      //Настройка порта
//       if ( usePortOptions )
//       {      
//          if ( tcgetattr( *portDescr, &portOptions ) == -1 )// получаем теущие настройки порта
//          {
//             perror("tcgetattr");
//             return false;
//          };

//          cfmakeraw( &portOptions );         // порт не обробатывает принятые данные
         
//          if (tcsetattr ( *portDescr, TCSANOW, &portOptions ) == -1)
//          {
//             perror("tcsetattr");
//             return false;
//          };
      
//          tcflush(*portDescr, TCIOFLUSH);   
//       };
      
      
      messproc->restart();
      return true;
   };

   //-------------------------------------------------------------------------------------------------//
   TAbsSerialWork::TAbsSerialWork(TSerialIfaceStateTunes tunes):TIfaceState(tunes.ifaceTunes->checkWorkStateUsec)
   {
      setSayStr("TAbsSerialWork");
      this->portDescr = tunes.portDescr;                    // Освобождаются в TAbsSerialIface
      this->queue     = tunes.queue;                        // Освобождаются в TAbsSerialIface
      this->messproc  = tunes.ifaceTunes->messproc;         // Освобождаются в TAbsSerialIface
//       this->handle    = tunes.handle;
   };

   TAbsSerialWork::~TAbsSerialWork()
   {
   };

   bool TAbsSerialWork::step()
   {
      if ( !send() )
      {
         messproc->pause();                  // Останавливаем обработку сообщений
         return false;
      }
      
      if ( !read() )
      {
         messproc->pause();
         return false;
      };
      
      if ( !messproc->isHeartBeatingFst() )
      {
         messproc->pause();
         return false;
      };
      
      cout << "bool TAbsSerialWork::step() true" << endl;
      return true;
   };

   bool TAbsSerialWork::send ()
   {
      static bool flag = false;
      size_t wLen;
      unsigned char writeBuff[MAX_SERIAL_BUFF_SIZE];
      cout << "bool TAbsSerialWork::send () " << endl;
      wLen = queue->read2Send ( reinterpret_cast<char*>( writeBuff ), MAX_SERIAL_BUFF_SIZE );                          //Читаем сообщение из очереди на отправку
      cout << "bool TAbsSerialWork::send () wLen = " << wLen << endl;
      cout << "bool TAbsSerialWork::send () portDescr = " << *portDescr << endl;

      if(!flag)
      {
         wLen = 4;
         writeBuff[0] = 0x09;
         writeBuff[1] = 0x00;
         writeBuff[2] = 0x00;
         writeBuff[3] = 0x00;
         flag = true;
      }

//       writeBuff[4] = 1;
//       writeBuff[5] = 0;
//       writeBuff[6] = 0;
//       writeBuff[7] = 0;

      if ( wLen > 0 )
      {  
         ssize_t writeLen = 0;

//          int actualLen;
//          unsigned int timeout = 10000;
//          int ENDPOINT_BULK_OUT=0x01;
//          libusb_device **devs;
//          libusb_get_device_list(NULL, &devs); 
//          *handle = libusb_open_device_with_vid_pid(NULL, CA418_VENDOR_ID, CA418_PRODUCT_ID);
//          if(libusb_kernel_driver_active(*handle, 0) == 1) { //find out if kernel driver is attached 
//                 cout<<"Kernel Driver Active"<<endl; 
//                 if(libusb_detach_kernel_driver(*handle, 0) == 0) //detach it 
//                     cout<<"Kernel Driver Detached!"<<endl; 
//          } 
//          libusb_claim_interface(*handle, 1);
//          int ret = libusb_bulk_transfer( *handle, ENDPOINT_BULK_OUT,writeBuff, wLen, &writeLen, timeout);
//          libusb_free_device_list(devs,1);
         
//          cout << "ret      = " << ret << endl;
         cout << "writeLen = " << writeLen << endl;
//          writeLen = write( *portDescr, writeBuff, wLen );
         
//          if ( ret < 0)
//          {
//             cout << "Error TAbsSerialWork::write " << strerror( errno ) << endl;
//             close( *portDescr );
//             return false;
//          };
         
         if ( static_cast<size_t>( writeLen ) == wLen)
         {
            cout << "TAbsSerialWork::send write ok..." << endl;
         }
         else if ( writeLen == 0)
         {
            ///????Может быть потребуется какая-то обработка. 0 - это конец файла
            cout << "TAbsSerialWork::send nothing to write..." << endl;
         };
         
      };
      return true;
   };
   
   bool TAbsSerialWork::read ()
   {
      ssize_t rLen = 0;
//       int actualLen;
//       unsigned int timeout = 10000;

      char readBuff[MAX_SERIAL_BUFF_SIZE];
      cout << "bool TAbsSerialWork::read () " << endl;
      cout << "bool TAbsSerialWork::read () portDescr = " << *portDescr << endl;
      char *currPtr = readBuff;
//       do
//       {
//          rLen = ::read ( *portDescr, currPtr, MAX_SERIAL_BUFF_SIZE );         //Читаем сообщение из порта
//          int ENDPOINT_BULK_IN=0x82;
//          int ret = libusb_bulk_transfer( *handle, ENDPOINT_BULK_IN, reinterpret_cast<unsigned char*>(readBuff), MAX_SERIAL_BUFF_SIZE, &rLen, timeout);
//          cout << "ret      = " << ret << endl;
         cout << "bool TAbsSerialWork::read () rLen = " << rLen << endl;
         cout << "Error TAbsSerialWork::read " << strerror( errno ) << endl;
         
         cout << "readBuff = ";
   
         for (int i=0; i<rLen; i++)
            cout << (int)currPtr[i];
         cout << dec << endl;
         currPtr += rLen;
//       }
//       while ( rLen > 0 );

      
      cout << "bool TAbsSerialWork::read () rLen = " << rLen << endl;

      if ( rLen > 0 )
      {
// cout << "insertReceived queue = " << queue << endl;
         return queue->insertReceived (readBuff, rLen);                       //Постановка принятого сообщения в очередь
// cout << "insertReceived queue 2 = " << queue << endl;
      }
      else if ( rLen == 0)
      {
         ///????Может быть потребуется какая-то обработка. 0 - это конец файла
         cout << "TAbsSerialWork::read nothing to read..." << endl;
      }
      else if ( rLen < 0)
      {
         if ( ( errno == EAGAIN ) || ( errno == EWOULDBLOCK) )
         {
            return true;
         }
         cout << "Error TAbsSerialWork::read " << strerror(errno) << endl;
         close( *portDescr );
         return false;
      };
      return true;
   };   
};
//-------------------------------------------------------------------------------------------------//

