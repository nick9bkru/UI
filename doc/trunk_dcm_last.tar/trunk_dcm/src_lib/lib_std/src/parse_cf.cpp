/**
   \file parse_cf.cpp
   \brief Реализация класса TConfFileParser
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

#include "parse_cf.h"

namespace _std
{
   int TConfFileParser::INTVINDEX = 0;
   int TConfFileParser::CHARVINDEX = 0;

   /*---------------------------------------------------------------------------*/

   TConfFileParser::TConfFileParser()
   {
   listOfCouple = (TSet*) calloc (255, sizeof (TSet*));
   IndexOfNewCouple = 0;
   onlyAllowed = false;
   verbosed = false;
   };

   /*---------------------------------------------------------------------------*/

   TConfFileParser::TConfFileParser (TSet * aset)
   {
   setSettingsList(aset);
   };

   /*---------------------------------------------------------------------------*/

   TConfFileParser::~TConfFileParser()
   {
   free (listOfCouple);
   };

   /*---------------------------------------------------------------------------*/

   void TConfFileParser::setVerbosed(bool verb)
   {
   verbosed = verb;
   };

   /*---------------------------------------------------------------------------*/

   void TConfFileParser::setSettingsList(TSet * aset)
   {
   TSet * ptr;
   IndexOfNewCouple = 0;

   listOfCouple = aset;

   for (ptr = listOfCouple; ptr->name != NULL; ptr++) //ищем конец предопределенного набора параметров
   {
      IndexOfNewCouple++;
   };
   onlyAllowed = true;   
   };

   /*---------------------------------------------------------------------------*/

   void TConfFileParser::addAllowedName (char *name, char * defValue, char * defType)
   {
   //    TSet * tmpC;
   defValue = NULL;
   defType = NULL;

   if ( (++IndexOfNewCouple) > 254)
      return;

   if (name == NULL)
      return;

   if (findCouple (name) != NULL)
      return;

   /*   tmpC = new TSet;
   tmpC->name = (char*) calloc (strlen (name) + 1, 1);
   strcpy (tmpC->name, name);

   if (defValue == NULL)
      tmpC->defvalue = NULL;
   else
   {
      tmpC->defvalue = (char*) calloc (strlen (defValue) + 1, 1);
      strcpy (tmpC->defvalue, defValue);
   }

   if (defType == NULL)
      tmpC->value = NULL;
   else
   {
      tmpC->type = (char*) calloc (strlen (defType) + 1, 1);
      strcpy (tmpC->type, defType);
   }
   listOfCouple[IndexOfNewCouple].name = tmpC->name;
   listOfCouple[IndexOfNewCouple].value = tmpC->value;
   listOfCouple[IndexOfNewCouple].defvalue = tmpC->defvalue;
   listOfCouple[IndexOfNewCouple].type = tmpC->type;
   if ( (++IndexOfNewCouple) > 254)
   {
      if (verb)
         printf ("Number of conf items too big - Error \n");
   }*/
   };

   /*---------------------------------------------------------------------------*/

   void TConfFileParser::setDefault()
   {
   TSet * ptr;

   for (ptr = listOfCouple; ptr->name != NULL; ptr++) //ищем конец предопределенного набора параметров
   {
      free (ptr->value);
      ptr->value = NULL;
   };
   };

   /*---------------------------------------------------------------------------*/

   void TConfFileParser::setDefault (const char *name)
   {
   TSet * tmpC;
   if ( (tmpC = findCouple (name)) != NULL)
   {
      free (tmpC->value);
      tmpC->value = NULL;
   };

   }

   /*---------------------------------------------------------------------------*/

   int TConfFileParser::parse (const char * filename, bool onlyAld)
   {
   TSet * tmpC;
   char str[256];
   int lineNO;
   char * argv[3];
   char argv0[256];
   char argv1[256];
   char delemit[2] = "=";
   FILE * fileid;

   if (!onlyAllowed)
      onlyAllowed = onlyAld;

   if ( (fileid = fopen (filename, "r")) == NULL)
   {
      if (verbosed)
         printf ("File %s can't be opened !!!", filename);
      return -1;
   }
   while (util_getline (fileid, str, 255, '#', &lineNO) != 1)
   {
      if (util_parse (str, argv, delemit, 2, 0) == 2)
      {
         strcpy (argv0, cleanBlanck (argv[0]));
         strcpy (argv1, cleanBlanck (argv[1]));
         if ( (tmpC = findCouple (argv0)) != NULL)
         {
            tmpC->value = (char*) realloc (tmpC->value, strlen (argv1) + 1);
            strcpy (tmpC->value, argv1);
            if (verbosed)
               printf ("New Name & Value have been reload [%s]=[%s]\n", tmpC->name, tmpC->value);
         }
         else if (!onlyAllowed)
         {
   /*            tmpC = new TSet;
            tmpC->name = (char*) calloc (strlen (argv0) + 1, 1);
            strcpy (tmpC->name, argv0);
            tmpC->value = (char *) calloc (strlen (argv1) + 1, 1);
            strcpy (tmpC->value, argv1);
            tmpC->defvalue = NULL;
            tmpC->type = (char *) calloc (5, 1);
            strcpy (tmpC->type, "char");
            if (verb)
               printf ("New Name & Value have been added [%s]=[%s]\n", tmpC->name, tmpC->value);
   */         }
      }
   }
   fclose (fileid);
   return 0;
   };

   /*---------------------------------------------------------------------------*/

   void copyTSet (TSet* a, TSet *b)
   {
   a->name = b->name;
   a->value = b->value;
   a->defvalue = b->defvalue;
   a->type = b->type;
   }

   /*---------------------------------------------------------------------------*/

   char * TConfFileParser::getCharValue (const char *name)
   {
   int index;
   static char CHARVALUE[MAX_CHAR_INDEX][255];

   index = TConfFileParser::getCharIndex();

   if (prepareValue (name, &CHARVALUE[index][0]))
      return &CHARVALUE[index][0];
   else
      return NULL;
   };

   /*---------------------------------------------------------------------------*/

   int * TConfFileParser::getIntValue (const char *name)
   {
   int index;
   static int INTVALUE[MAX_INT_INDEX];
   char str[255];

   index = TConfFileParser::getIntIndex();

   if (prepareValue (name, &str[0]))
      if (sscanf (str, "%d", &INTVALUE[index]) == 1)
         return &INTVALUE[index];

   return NULL;
   };

   /*---------------------------------------------------------------------------*/

   bool TConfFileParser::getBoolValue (const char *name)
   {
   char str[255];

   if (prepareValue (name, &str[0]))
      if (strcasecmp (str, "yes") == 0)
         return true;

   return false;
   };

   /*---------------------------------------------------------------------------*/

   const char * TConfFileParser::getType (const char * name)
   {
   static char badres[] = "noType";
   TSet * tmpC;
   if ( (tmpC = findCouple (name)) != NULL)
      return tmpC->type;
   else
      return badres;
   };

   /*---------------------------------------------------------------------------*/

   int TConfFileParser::getCharIndex()
   {
   CHARVINDEX++;
   if (CHARVINDEX == MAX_CHAR_INDEX)
      CHARVINDEX = 0;
   return CHARVINDEX;
   };

   /*---------------------------------------------------------------------------*/

   int TConfFileParser::getIntIndex()
   {
   INTVINDEX++;
   if (INTVINDEX == MAX_INT_INDEX)
      INTVINDEX = 0;
   return INTVINDEX;
   };

   /*---------------------------------------------------------------------------*/

   bool TConfFileParser::prepareValue (const char *name, char * value)
   {
   //   static char VAR_GET_VALUE[256];
   TSet * tmpC;

   if ( (tmpC = findCouple (name)) == NULL)
   {
      if (verbosed)
         printf ("Name [%s] can't be found\n", name);
      return false;
   }
   if (tmpC->value == NULL)
   {
      if (verbosed)
         printf ("Name [%s] doesn't have any value. Let's try to find default...\n", name);

      if (tmpC->defvalue == NULL)
      {
         printf ("Name [%s] doesn't have any default value. NULL will be returned\n", name);
         return false;
      }

      if (verbosed)
         printf ("Name [%s] was found and equal to default [%s]\n", tmpC->name, tmpC->defvalue);
      
      strcpy (value, tmpC->defvalue);
      return true;
   }
   
   if (verbosed)
      printf ("Name [%s] was found and equal to [%s]\n", tmpC->name, tmpC->value);
   strcpy (value, tmpC->value);
   return true;

   };

   /*---------------------------------------------------------------------------*/

   char * TConfFileParser::cleanBlanck (char * str)
   {
   static char STR[255];
   int ptr;

   for (ptr = 0; (str[ptr] == ' ') && (str[ptr] != 0); ptr++)
   {
   };
   strcpy (STR, &str[ptr]);

   if (strlen (STR) == 1) 
      return STR;
   
   for (ptr = (strlen (STR) - 1); (STR[ptr] == ' ') && (ptr != 0) ; ptr--)
   {
      STR[ptr] = 0;
   };
   if (ptr == 0)
      return NULL;

   return STR;

   };

   /*---------------------------------------------------------------------------*/

   TSet * TConfFileParser::findCouple (const char * name)
   {
   int ind = 0;
   //TSet * ptr;

   while (ind < IndexOfNewCouple)
   {
      if (strcmp (listOfCouple[ind].name, name) == 0)
         return &listOfCouple[ind];
      ind++;
   }
   return  NULL;
   };

   /*---------------------------------------------------------------------------*/

   int TConfFileParser::util_parse (
   char *input,      /* input string                */
   char **argv,      /* output array to hold tokens */
   char *delimiters, /* token delimiters            */
   int  max_tokens, /* max number of tokens (#elements in argv) */
   char quote        /* quote character for strings */
   )
   {
   char *ptr;
   int i = 0, nquote = 0;

   if (max_tokens < 1)
   {
      return -1;
   }

   /* Save embedded blanks inside quoted strings */

   if (quote != 0)
   {
      for (ptr = input; *ptr != (char) 0; ptr++)
      {
         if (*ptr == quote)
         {
            if (++nquote == 2) nquote = 0;
         }
         else
         {
            if (nquote == 1 && *ptr == ' ') *ptr = (char) - 1;
         }
      }
   }

   /* Parse the string, restoring blanks if required */

   if ( (argv[0] = strtok (input, delimiters)) == NULL) return 0;
   i = 1;
   do
   {
      if ( (argv[i] = strtok (NULL, delimiters)) != NULL && quote != 0)
      {
         for (ptr = argv[i]; *ptr != (char) 0; ptr++)
         {
            if (*ptr == (char) - 1) *ptr = ' ';
         }
      }

   }
   while (argv[i] != NULL && ++i < max_tokens);

   /* Return the number of tokens */
   return i;
   };

   /*---------------------------------------------------------------------------*/

   int TConfFileParser::util_getline (
   FILE *fp,     /* input stream              */
   char *buffer, /* buffer to hold line       */
   int buflen,  /* length of buffer          */
   char comment, /* comment character         */
   int *lineno  /* current line number in fp */
   )
   {
   int i;

   if (fp == (FILE *) NULL || buffer == (char *) NULL || buflen < 2)
   {
      return -1;
   }

   clearerr (fp);

   buffer[0] = 0;
   do
   {

      /*  Read the next line in the file  */

      if (fgets (buffer, buflen - 1, fp) == NULL)
      {
         buffer[0] = 0;
         return feof (fp) ? 1 : -1;
      }
      if (lineno != NULL) ++*lineno;

      /*  Truncate everything after comment token  */

      if (comment != (char) 0)
      {
         i = 0;
         while (i < (int) strlen (buffer) && buffer[i++] != comment) {};
         buffer[--i] = 0;
      }

      /*  Remove trailing blanks  */

      i = strlen (buffer) - 1;
      while (i >= 0 && (buffer[i] == ' ' || buffer[i] == '\n')) --i;
      buffer[++i] = 0;

   }
   while (strlen (buffer) <= 0);

   return 0;
   };
};
/*===========================================================================*/

