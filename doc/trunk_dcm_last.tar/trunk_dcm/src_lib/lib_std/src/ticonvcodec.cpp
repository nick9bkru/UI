/**
   \file ticonvcodec.cpp
   \brief Описание реализации класса TIconvCodec.
   \author Лихобабин Е.
   \version 0.1
   \date 2011-05-23
*/
#include "ticonvcodec.h"

namespace _std
{
   TIconvCodec::TIconvCodec (string toCode, string fromCode)
   {
      convDescr = iconv_open(toCode.c_str(), fromCode.c_str());
      if (convDescr == (iconv_t)-1)
         perror("TIconvCodec");
      cout << "TIconvCodec convDescr = " << convDescr << endl;
   };

   TIconvCodec::~TIconvCodec ()
   {
      if (iconv_close(convDescr) == -1)
         perror("~TIconvCodec");
   };
   
   string TIconvCodec::transcode(string input)
   {
      char* inBuf = 0;
      char* outBuf = 0;
      char* outBufStart = 0;

      inBuf = const_cast<char*>(input.c_str());
      size_t inSize = input.size();
//          cout << "inbuf = " << inBuf << endl;
//          cout << "inSize = " << inSize << endl;

      size_t outSize = 4*inSize;    //Возможно надо что-то похитрее
      outSize++;                    //На терминирующий 0
      outBuf = new char[outSize];
      memset(outBuf, 0, outSize);
      outBufStart = outBuf;

//          cout << "outbuf bef = " << outBuf << endl;
//       cout << "convDescr = " << convDescr << endl;
      if( iconv(convDescr, &inBuf, &inSize, &outBuf, &outSize) == (size_t)-1)
         perror("TIconvCodec::transcode");

//          cout << "outbuf = " << outBufStart << endl;
//          cout << "len = " << (4*strlen(inBuf) - outSize) << endl; 
      return string(outBufStart);
   };
};
