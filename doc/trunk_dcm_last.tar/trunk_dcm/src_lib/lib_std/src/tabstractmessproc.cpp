/**
   *\file tabstractmessproc.cpp
   *\brief Реализация класса TAbstractMessProc - предка обработчиков.
   *\author Зайцев А.А.Лихобабин Е.А.
   *\version 1.01.A
   *\date 2009-09-30
*/

#include "tabstractmessproc.h"
using namespace std;

namespace _std
{
   /*---------------------------------------------------------------------------*/
   namespace messproc
   {
      void* runFunc (void * p)
      {
         TAbstractMessProc *mP = (TAbstractMessProc *) p;
         mP->run();
         return NULL;
      };
   };

   /*---------------------------------------------------------------------------*/
   TAbstractMessProc::TAbstractMessProc()
   {
      isMainLoop = false;
      isExtTimer = false;
      runFuncName = messproc::runFunc;
      timeStep = DEFAULT_MESS_PROC_TIME_STEP;
   };

   /*---------------------------------------------------------------------------*/
   TAbstractMessProc::~TAbstractMessProc()
   {  
   };

   /*---------------------------------------------------------------------------*/
   bool TAbstractMessProc::setQueues (_std::TAbsQueue * fstQue, _std::TAbsQueue * secQue)
   {
      if (fstQue == NULL)
         return false;
      fstQueue = fstQue;

      TAbsMessage* message;
      message = fstQueue->messageFactory();
      fstProtocol = message->getProtocolType();
      delete message;

      if (secQue == NULL)
      {
         message = NULL;
         secQueue = NULL;
         return true;
      }
      secQueue = secQue;
      message = secQueue->messageFactory();
      secProtocol = message->getProtocolType();
      delete message;
      message = NULL;
      return true;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::setTimeStep (int usec)
   {
      timeStep = usec;
   };

   /*---------------------------------------------------------------------------*/

   void TAbstractMessProc::setVerbose(bool v)
   {
      verbose = v;
   };

   /*---------------------------------------------------------------------------*/
   int TAbstractMessProc::getTimeStep()
   {
      return timeStep;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::setIsMainLoop (bool mainLoopVal)
   {
      isMainLoop = mainLoopVal;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::setRunFunc (void* (*funcName) (void*))
   {
      runFuncName = funcName;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::step (int usec)
   {
      TAbsMessage *message;
      TAbsMessage *delmes;
      delmes = NULL;

      if (fstQueue != NULL)
      {
         while ( (delmes = fstQueue->whosTimeIsUp()) != NULL)
         {
            processNotCheckedMessage (delmes);
            delmes = NULL;
         };

         while (fstQueue->readReceived (&message))
         {
            processFstMes (message);
         };

         fstQueue->timeStep (usec);
      };

      if (secQueue != NULL)
      {
         while ( (delmes = secQueue->whosTimeIsUp()) != NULL)
         {
            processNotCheckedMessage (delmes);
            delmes = NULL;
         };
         while (secQueue->readReceived (&message))
         {
            processSecMes (message);
         };
         secQueue->timeStep (usec);
      };

   #ifdef LIB_STD_DEBUG
      sendDebugMess();
   #endif
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::oneQueueStep (TAbsQueue *queue, int usec)
   {
      if (queue == NULL)
         return;

      TAbsMessage  *message;
      TAbsMessage  *delmes;
      delmes = NULL;

      while ( (delmes = queue->whosTimeIsUp()) != NULL)
      {
         processNotCheckedMessage (delmes);
         delmes = NULL;
      };

      while (queue->readReceived (&message))
      {
         processFstMes (message);
      };

      queue->timeStep (usec);
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::clearQueues ()
   {
      TAbsMessage *message;
      TAbsMessage *delmes;
      delmes = NULL;

      if (fstQueue != NULL)
      {
         while (fstQueue->readReceived (&message))
         {
            delete message;
         };
      };

      if (secQueue != NULL)
      {
         while (secQueue->readReceived (&message))
         {
            delete message;
         };
      };
   };
   
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::start()
   {
      runFlag  = true;
      stopFlag = false;
      if (isMainLoop)
      {
         if (isExtTimer)
         {
            initExtTimer();
         }
         else
         {
            run();
         };
      }
      else
      {
         pthread_create (&thread_id, NULL, this->runFuncName, (void*) this);
      }
   };
   
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::restart()
   {
      runFlag = true;
      restartInit();
   };
   
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::stop()
   {
      stopFlag = true;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::pause()
   {
      runFlag = false;
   };
   
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::run()
   {
      usleep ( timeStep );
      while ( !stopFlag )
      {
         usleep ( timeStep );
         if ( runFlag )
            step ( timeStep );
      };
      clearQueues();
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::processNotCheckedMessage (TAbsMessage * message)
   {
      delete message;
      return;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::processFstMes (TAbsMessage * message)
   {
      TAbsMessage * toFst = NULL;
      TAbsMessage * toSec = NULL;
      unsigned int protocolType;

      if (message == NULL)
         return;

      protocolType = message->getProtocolType();

      if (protocolType != fstProtocol)
      {
      }

      decodeFst (message, &toFst, &toSec);
      if (toFst != NULL)
         fstQueue->insert2Send (toFst);
      if (toSec != NULL)
         secQueue->insert2Send (toSec);
      return;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::processSecMes (TAbsMessage * message)
   {
      TAbsMessage * toFst = NULL;
      TAbsMessage * toSec = NULL;
      unsigned int protocolType;
      if (message == NULL)
         return;

      protocolType = message->getProtocolType();

      if (protocolType != secProtocol)
      {
      }

      decodeSec (message, &toFst, &toSec);
      if (toFst != NULL)
      {
         fstQueue->insert2Send (toFst);
      }
      if (toSec != NULL)
         secQueue->insert2Send (toSec);
      return;
   };

#ifdef LIB_STD_DEBUG
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::sendDebugMess()
   {
      return;
   };
#endif

   /*---------------------------------------------------------------------------*/
   TAbsMessage * TAbstractMessProc::sendMess2Fst (char *kdg, int size)
   {
      if (kdg == NULL)
      {
         return NULL;
      }
      TAbsMessage *message = fstQueue->messageFactory();
      message->assign (kdg, size);
      fstQueue->insert2Send (message);
      return message;
   };

   /*---------------------------------------------------------------------------*/
   TAbsMessage * TAbstractMessProc::sendMess2Sec (char *kdg, int size)
   {
      if (kdg == NULL)
      {
         return NULL;
      }
      TAbsMessage *message = secQueue->messageFactory();
      message->assign (kdg, size);
      secQueue->insert2Send (message);
      return message;
   };

   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::initExtTimer()
   {
   };
   
   /*---------------------------------------------------------------------------*/
   bool TAbstractMessProc::isHeartBeatingFst()
   {
      return heartBeatingFst;
   };
   
   /*---------------------------------------------------------------------------*/
   bool TAbstractMessProc::isHeartBeatingSec()
   {
      return heartBeatingSec;
   };
   
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::decodeFst ( _std::TAbsMessage * message, _std::TAbsMessage **toFst, _std::TAbsMessage **toSec )
   {
      if ( ( message != NULL ) && ( toFst != NULL ) && ( toSec != NULL ) )
         return;
      
      cout << "TAbstractMessProc::decodeFst------------------------ " << endl;
      return;
   };
   
   /*---------------------------------------------------------------------------*/
   void TAbstractMessProc::decodeSec ( _std::TAbsMessage * message, _std::TAbsMessage **toFst, _std::TAbsMessage **toSec )
   {
      if ( ( message != NULL ) && ( toFst != NULL ) && ( toSec != NULL ) )
         return;
      
      cout << "TAbstractMessProc::decodeSec------------------------ " << endl;
      return;
   };
};
/*===========================================================================*/
