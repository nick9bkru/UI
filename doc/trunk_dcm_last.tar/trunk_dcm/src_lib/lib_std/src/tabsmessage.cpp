/**
   \file tabsmessage.cpp
   \brief Реализация класса TAbsMessage.
   \author Зайцев А.А., Лихобабин Е.А.
   \version 
   \date 2012-01-10
*/
#include "tabsmessage.h"
using namespace std;

namespace _std
{
   #ifdef IS_BIG_ENDIAN
      enEndian TAbsMessage::host = big_endian;
   #else
      enEndian TAbsMessage::host = little_endian;
   #endif
      
   enEndian TAbsMessage::protocol = unknown_endian;
   
   TIconvCodec* TAbsMessage::toHost = NULL;
   TIconvCodec* TAbsMessage::toProt = NULL;
   bool TAbsMessage::convertEncodings = false;
   // res_count - число перепосылок сообщения, в случае отсутствия квитанций
   // res_period - таймаут ожидания квитанции
   // subQN - номер подочереди в TInOutQue в которую устанавливается создаваемое сообщение
   TAbsMessage::TAbsMessage (int res_count, int res_period, int subQN)
   {
      isGeneric      = false;
      subQueueNumber = subQN;
      resendCounter  = res_count;
      resendPeriod   = res_period;
      period         = resendPeriod;
      should_be_sent = true;
      should_be_read = true;
      counter        = resendCounter;
      time_is_up     = false;
      repeat         = false;
      repeatable     = false;
      protocolType   = pt_ABSTRACT_PROT;
      wfPointer      = NULL;
      size           = 0;
      isHB           = false;
      heartBeating   = false;
   };
   /*---------------------------------------------------------------*/


   // Освобождаем память выделенную под данные
   TAbsMessage::~TAbsMessage()
   {
      if (wfPointer != NULL)
      {
         (*wfPointer) = false;
      };
      
   };
   /*---------------------------------------------------------------*/
   //Явная специализация шаблонной функции при передаче в качестве параметра 1ого байта
   template <>
   void TAbsMessage::fillVar<char>(char &var, char *&pData)
   {
      cout << "T418Message::fillVar<char> You are trying to change byte order for one byte variable. I'll do it, but it isn't necessary!!! " << endl;;
      var = *pData;
      pData++;
      return;
   };
   template <>
   void TAbsMessage::fillVar<unsigned char>(unsigned char &var, char *&pData)
   {
      cout << "T418Message::fillVar<unsigned char> You are trying to change byte order for one byte variable. I'll do it, but it isn't necessary!!! " << endl;;
      var = *pData;
      pData++;
      return ;
   };
   /*---------------------------------------------------------------*/
   //Явная специализация шаблонной функции заполнения переменной из буфера байт
   template <>
   void TAbsMessage::fillVar<string>(string &var, char *&pData)
   {
      if ( pData != NULL )
         var = "";
      
      cout << "T418Message::fillVar<string> You shouldn't use this function for std::strings!!! Please use fillVar( string var, _std::TIconvCodec *codec, char *pData, size_t size) instead. " << endl;;
      return;
   };
   /*---------------------------------------------------------------*/
   bool TAbsMessage::incapsulate (char* data, int N)
   {
      if ( ( data != NULL ) && ( N != 0 ) )
         return false;
      return false;
   };
   /*---------------------------------------------------------------*/
   int TAbsMessage::decapsulate (char * data)
   {
      if ( data != NULL )
         return 0;
      return 0;
   };
         
   /*---------------------------------------------------------------*/

   void TAbsMessage::setGeneric()
   {
      isGeneric = true;
   };

   bool TAbsMessage::isHeartBeat()
   {
      return isHB; //this method should be redefined for heartbeat options
   };

   // Установка состояния сообщений на отправку
   void TAbsMessage::setShouldBeSent (bool send)
   {
      should_be_sent = send;
   };
   /*---------------------------------------------------------------*/

   // Состояние сообщения на отправку
   // если возвращает true - InOutQue отправляет это сообщение и устанавливает should_be_sent=false
   // если false - InOutQue ничего с этим сообщением не делает
   bool TAbsMessage::shouldBeSent (bool * waitFlagPointer)
   {
      if (waitFlagPointer == NULL)
         return false;

   //    cout << "shouldBeSent subQueueNumber = " << subQueueNumber << endl;
      wfPointer = &waitFlagPointer[subQueueNumber];
      if (isOneByOne())
      {
         if (waitFlagPointer[subQueueNumber])            // если true - то очередь уже ждет квитанции на какое-то другое сообщение
         {
            return false;                                // значит отправлять рассматриваемое сообщение нельзя - возвращаем false
         }
         else
         {
            waitFlagPointer[subQueueNumber] = true;      // очередь будет ждать квитанции на это сообщение до отсылки следующего
            return should_be_sent;
         }
      }
      else
      {
         return should_be_sent;
      };
   };
   /*---------------------------------------------------------------*/


   // Состояние сообщения для чтения ???
   bool TAbsMessage::shouldBeRead()
   {
      return should_be_read;
   };
   /*---------------------------------------------------------------*/


   // Установка состояния сообщения для чтения ???
   void TAbsMessage::setShouldBeRead (bool read)
   {
      should_be_read = read;
   };
   /*---------------------------------------------------------------*/

   // Вызывается при каждом опросе сообщения, и уменьшает время до перепосылки сообщения на величину usec
   // usec - период опроса сообщений
   void TAbsMessage::timeStep (int usec)
   {
      period -= usec;
      if (period <= 0)
      {
         counter --;
         period = resendPeriod;
         if (counter <= 0)
            time_is_up = true;
         else
            should_be_sent = true;
      }
   };
   /*---------------------------------------------------------------*/

   // Возвращает true - если сообщение было переотправлено resendCounter раз и квитанции получено не было
   // вызывается методом WhosTimeIsUp в TMessageProcessor'e,
   // который при возвращении timeIsUp() true вызывает обработчик этого события.
   // Обработчик у каждого протокола - свой.
   bool TAbsMessage::timeIsUp()
   {
   ////std::cout << "TAbsMessage::timeIsUp()" << time_is_up << std::endl;
   //    if (time_is_up)
   //       //std::cout << "TAbsMessage::timeIsUp()" <<  display() << " resendPeriod="<< resendPeriod << std::endl;
      return time_is_up;
   };
   /*---------------------------------------------------------------*/
   // Размер сообщения в байтах size для отправки в интерфейсов
   unsigned int TAbsMessage::getSize ()
   {
      return size;
   };
   /*---------------------------------------------------------------*/

   // Возвращает тип протокола, тип протокола должен быть уникален у каждого потомка TAbsMessage???
   unsigned int TAbsMessage::getProtocolType()
   {
      return protocolType;
   };
   /*---------------------------------------------------------------*/

   // Является ли это сообщение повторением одного из ранее принятых сообщений???
   bool TAbsMessage::isRepeat()
   {
      return (repeat);
   };
   /*---------------------------------------------------------------*/

   // ???
   void TAbsMessage::setRepeat (bool rpt)
   {
      repeat = rpt;
   };
   /*---------------------------------------------------------------*/

   // Существует ли теоретическая возможность наличия повторяющихся сообщений в протоколе
   bool TAbsMessage::isRepeatable()
   {
      return (repeatable);
   };
   /*---------------------------------------------------------------*/

   // Установка флага repeatable
   void TAbsMessage::setRepeatable (bool rptb)
   {
      repeatable = rptb;
   };
   
   map<char*, int> TAbsMessage::dataSplitter(char *readBuff, ssize_t rLen)
   {
      map<char*, int> emptyMap;
      if ( ( readBuff != NULL ) && ( rLen != 0 ) )
      {  
         return emptyMap;
      }
      return emptyMap;
   };
   /*---------------------------------------------------------------*/

   // Метод создания квитанции на сообщение
   TAbsMessage * TAbsMessage::createTicket()
   {
      return NULL;
   };
   
   /*---------------------------------------------------------------*/
   void TAbsMessage::setSendingTime()
   {
      return;
   };

   /*---------------------------------------------------------------*/
   void TAbsMessage::getSendingTime(tm* t)
   {
      t = NULL;   ///just for prevent warn
      return;
   };
   /*---------------------------------------------------------------*/
   void TAbsMessage::setCodogramNumber(int * N)
   {
      if ( N != NULL)
         return;
   };
   /*---------------------------------------------------------------*/
   void TAbsMessage::setProtocolEndian(enEndian endian)
   {
      protocol = endian;
   };
   /*---------------------------------------------------------------*/
   void TAbsMessage::initEncodings(string protEncoding, string hostEncoding)
   {
      if ( protEncoding == hostEncoding)
         convertEncodings = false;
      else
         convertEncodings = true;
      
      toHost = new TIconvCodec(hostEncoding, protEncoding); 
//       cout << "toHost = " << toHost->transcode("ААААА") << endl;
      toProt = new TIconvCodec(protEncoding, hostEncoding);
//       cout << "toProt = " << toProt->transcode("ААААА") << endl;
   };
   /*---------------------------------------------------------------*/
   void TAbsMessage::fillStrToHost(string &var, char *&pData, size_t size)
   {
      var = "";
      var.append(pData, size);
      if (convertEncodings)
      {
         var = toHost->transcode(var);
      }
      pData += size;
      return;
   };
   /*---------------------------------------------------------------*/
   void TAbsMessage::getStrToProt(char *&pData, string var)
   {
      if (convertEncodings)
      {
         var = toProt->transcode(var);
      };
      strncpy( pData, var.c_str(), var.size() );
      pData += var.size();
      return;
   };
};




/*===============================================================*/
