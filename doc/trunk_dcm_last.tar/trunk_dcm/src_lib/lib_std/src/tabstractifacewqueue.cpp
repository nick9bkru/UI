/**
   \file tsockwithque.cpp
   \brief Реализация класса TAbstractIfaceWQue.
   \author Зайцев А.А., Лихобабин Е.А.
   \version 2011-04-25
*/
#include "tabstractifacewqueue.h"
#include <stdio.h>
#include <string.h>

using namespace std;

namespace _std
{
   
   TAbstractIfaceWQue::TAbstractIfaceWQue (_std::TIfaceWQueTunes tunes)
   {
      thread_id         = 0;
      verbose           = tunes.verbose;
      ifaceTunes.period = tunes.period;
//       state             = sst_aswq_CLOSE;
      runFuncName       = defaultRun;   
      iface             = NULL;
      queue             = NULL;
   #ifdef SOCK_DEBUG_ABILITY
      debugType = tunes.debug;
      //std::cout << "debugType=" << debugType << std::endl;
   #endif
   };
   
   TAbstractIfaceWQue::~TAbstractIfaceWQue()
   {
      if(thread_id != 0)
         pthread_cancel(thread_id);  
      
      if (iface != NULL) 
         delete iface;   
   };
   
   void TAbstractIfaceWQue::setPeriod (int period)
   {
//       if (state == sst_aswq_STOPED)
      if (true)
      {
         ifaceTunes.period = period;
      };
   };
   
   void TAbstractIfaceWQue::setRunFunc (void* (*funcName) (void*))
   {
      runFuncName = funcName;
   };
   
   void TAbstractIfaceWQue::open ()
   {
      return;
   };
   
   bool TAbstractIfaceWQue::start()
   {
      specificStart();
   
      pthread_create (&thread_id, NULL, runFuncName, (void*) this);
      if (pthread_detach (thread_id) != 0)                        //Отсоединяем поток, чтобы не превратился в зомби и не требовал вызова
         perror ("start:pthread_detach");                          //pthread_join(...)
       
      return true;
   };
   
   void TAbstractIfaceWQue::stop()
   {
//       if (state != sst_aswq_STOPED)
//          prevState = state;
//    
//       state = sst_aswq_STOPED;
   };
   
   void TAbstractIfaceWQue::restart()
   {
//       state = prevState;
   };
   
   /*-----------------------------------------------------------------*/
   void TAbstractIfaceWQue::run()
   {
   #ifdef SOCK_DEBUG_ABILITY
      char temp_str[] = "000123456789";
      
      if (debugType != noDebug)
         state = sst_swq_DEBUG;                                                  //let's debug
      //std::cout << "sockWithQue->debugType=" << sockWithQue->debugType << std::endl;
   #endif
      while (1)
      {
//          switch (state)
//          {
//             case sst_aswq_OPEN:
//                if (verbose)
//                {
//                   std::cout << "sst_swq_OPEN "<< std::endl;
//                };
//                open();
//             break;
//    
//             case sst_aswq_READ_WRITE:
//                if (verbose)
//                {
//                   std::cout << "sst_swq_READ_WRITE "<< std::endl;
//                };
//                send();
//                read();
//             break;
//    
//             case sst_aswq_STOPED:
//                if (verbose)
//                {
//                   std::cout << "sst_swq_PAUSED "<< std::endl;
//                };
//                pause();
//             break;
//    
//    #ifdef SOCK_DEBUG_ABILITY
//             case sst_swq_DEBUG:                                                                  //this case is used only for debug
//                sendDebugMess();
//                break;
//    #endif
//             default:
//                break;
//          }
   
         usleep (ifaceTunes.period);
      }
   };
   
   void * defaultRun (void * p)
   {
      TAbstractIfaceWQue * ifaceWithQue = (TAbstractIfaceWQue *) p;
      ifaceWithQue->run();
      return NULL;
   };
   
   /*-----------------------------------------------------------------*/
   #ifdef SOCK_DEBUG_ABILITY
   void TAbstractIfaceWQue::sendDebugMess()
   {
      switch (debugType)
      {
         case (writeOnly) :
            usleep (100000);
            if ( (wLen = queue->read2Send (write_buff)) != 0)
            {
            }
            break;
         case (readOnly) :
            usleep (5000000);
   
            queue->insertReceived (temp_str, 8);
            temp_str[0] ++;
            temp_str[0] &= 0x3f;
            break;
         default:
            break;
      };
      return;
   };
   #endif
};


