/**
   \file tabsserialifacestates.cpp
   \brief Реализация классов TAbsUsbNA, TAbsUsbPinging.
   \author Лихобабин
   \version 0.1
   \date 2011-12-16
*/
#include "tabsusbifacestates.h"
#include "tabsusbiface.h"


namespace _std
{
   TAbsUsbNA::TAbsUsbNA(int checkTimingUsec):TIfaceState(checkTimingUsec)
   {
      setSayStr("TAbsUsbNA");
   };

   TAbsUsbNA::~TAbsUsbNA()
   {
   };

   bool TAbsUsbNA::step()
   {
      return true;   
   };

   //-------------------------------------------------------------------------------------------------//
   TAbsUsbOpen::TAbsUsbOpen(TUsbIfaceStateTunes tunes):TIfaceState(tunes.ifaceTunes->checkOpenStateUsec)
   {
      this->messproc  = tunes.ifaceTunes->messproc;         
      this->devHandle = tunes.devHandle;
      this->vendorId  = tunes.ifaceTunes->vendorId;
      this->productId = tunes.ifaceTunes->productId;
      this->context   = tunes.context;
      setSayStr("TAbsUsbOpen");
   };

   TAbsUsbOpen::~TAbsUsbOpen()
   {
      libusb_exit(context);
   };
   
   bool TAbsUsbOpen::step()
   {
      libusb_device **devs;
      libusb_get_device_list(context, &devs); 
      *devHandle = libusb_open_device_with_vid_pid(context, vendorId, productId);
      if (!*devHandle)
      {
         libusb_free_device_list(devs,1);
         cout << "can't open device vendorId = " << hex << vendorId << " productId = " << productId << dec << endl;
         return false;
      };
      
      if(libusb_kernel_driver_active(*devHandle, 0) == 1) //find out if kernel driver is attached 
      { 
         cout<<"Kernel Driver Active"<<endl; 
         if(libusb_detach_kernel_driver(*devHandle, 0) == 0) //detach it 
         {
            cout<<"Kernel Driver Detached!"<<endl; 
         };
      };
      
      libusb_claim_interface(*devHandle, 1);
      libusb_free_device_list(devs,1);
      
      messproc->restart();
      return true;
   };

   //-------------------------------------------------------------------------------------------------//
   TAbsUsbWork::TAbsUsbWork(TUsbIfaceStateTunes tunes):TIfaceState(tunes.ifaceTunes->checkWorkStateUsec)
   {
      setSayStr("TAbsUsbWork");
      this->queue       = tunes.queue;                        // Освобождаются в TAbsUsbIface
      this->messproc    = tunes.ifaceTunes->messproc;         // Освобождаются в TAbsUsbIface
      this->devHandle   = tunes.devHandle;
      this->endPointIn  = tunes.ifaceTunes->endPointIn;
      this->endPointOut = tunes.ifaceTunes->endPointOut;
      
      isRequestSended = false;
   };

   TAbsUsbWork::~TAbsUsbWork()
   {
      closeUsb();
   };
   
   void TAbsUsbWork::closeUsb()
   {
      if ( *devHandle != NULL )
      {
         libusb_close(*devHandle);
         *devHandle = NULL;
      }
   };

   bool TAbsUsbWork::step()
   {
      if ( !send() )
      {
         messproc->pause();                  // Останавливаем обработку сообщений
         closeUsb();
         return false;
      };
      
//       if ( !read() )
//       {
//          messproc->pause();                  // Останавливаем обработку сообщений
//          libusb_close(*devHandle);
//          return false;
//       };
      
//       if ( !messproc->isHeartBeatingFst() )
//       {
//          messproc->pause();
//          libusb_close(*devHandle);
//          return false;
//       };
      
      cout << "bool TAbsUsbWork::step() true" << endl;
      return true;
   };

   bool TAbsUsbWork::send ()
   {
//       static bool flag = false;o
      size_t wLen = 0;
      unsigned char writeBuff[MAX_USB_BUFF_SIZE];
      cout << "bool TAbsUsbWork::send () " << endl;
      wLen = queue->read2Send ( reinterpret_cast<char*>( writeBuff ), MAX_USB_BUFF_SIZE );                          //Читаем сообщение из очереди на отправку
      cout << "bool TAbsUsbWork::send () wLen = " << wLen << endl;

//       if(!flag)
//       {
//          wLen = 4;
//          writeBuff[0] = 0x0c;
//          writeBuff[1] = 0x00;
//          writeBuff[2] = 0x00;
//          writeBuff[3] = 0x00;
//          
//          int writeLen = 0;
//          unsigned int timeout = 10000;
//          
//          libusb_bulk_transfer( *devHandle, endPointOut, writeBuff, wLen, &writeLen, timeout);
//          sleep(4);
//          read ();
//          writeBuff[0] = 0x0a;
//          writeBuff[1] = 0x00;
//          writeBuff[2] = 0x00;
//          writeBuff[3] = 0x00;
//          
//          writeLen = 0;
//          
//          libusb_bulk_transfer( *devHandle, endPointOut, writeBuff, wLen, &writeLen, timeout);
//          sleep(4);
//          read ();
//          sleep(4);
//          wLen = 12;
//          writeBuff[0] = 0x10;
//          writeBuff[1] = 0x00;
//          writeBuff[2] = 0x08;
//          writeBuff[3] = 0x00;
//          
//          writeBuff[4] = 0x00;
//          writeBuff[5] = 0x00;
//          writeBuff[6] = 0x00;
//          writeBuff[7] = 0x00;
// //          
//          writeBuff[8] = 0xf4;
//          writeBuff[9] = 0x07;
//          writeBuff[10]= 0x00;
//          writeBuff[11]= 0x00;
// //          writeBuff[8] = 0x90;
// //          writeBuff[9] = 0x02;
// //          writeBuff[10]= 0x00;
// //          writeBuff[11]= 0x00;
//          flag = true;
//       }

      

      if ( wLen > 0 )
      {  
         unsigned char *currPtr = writeBuff;
         cout << hex << "writeBuff = ";

         for (unsigned int i=0; i<wLen; i++)
            cout << (unsigned int)currPtr[i] << ":";
         cout << dec << endl;
         
         int writeLen = 0;

//          int actualLen;
         unsigned int timeout = 10000;
         
         
         int ret = libusb_bulk_transfer( *devHandle, endPointOut, writeBuff, wLen, &writeLen, timeout);
         cout << "*devHandle      = " << *devHandle << endl;
         
         
         cout << "ret      = " << ret << endl;
         cout << "writeLen = " << writeLen << endl;
//          writeLen = write( *portDescr, writeBuff, wLen );
         
         if ( ret < 0)
         {
            cout << "Error TAbsUsbWork::write " << strerror( errno ) << endl;
            closeUsb();
            return false;
         };
         
         if ( static_cast<size_t>( writeLen ) == wLen)
         {
            cout << "TAbsUsbWork::send write ok..." << endl;
         }
         else if ( writeLen == 0)
         {
            ///????Может быть потребуется какая-то обработка. 0 - это конец файла
            cout << "TAbsUsbWork::send nothing to write..." << endl;
         };
         read();
         
      };
      return true;
   };
   
   bool TAbsUsbWork::read ()
   {
      int rLen = 0;
//       int actualLen;
      unsigned int timeout = 10000;

      char readBuff[MAX_USB_BUFF_SIZE];
      cout << "bool TAbsUsbWork::read () " << endl;
      char *currPtr = readBuff;

      int ret = libusb_bulk_transfer( *devHandle, endPointIn, reinterpret_cast<unsigned char*>(readBuff), MAX_USB_BUFF_SIZE, &rLen, timeout);
      cout << "*devHandle      = " << *devHandle << endl;
      cout << "ret      = " << ret << endl;
      cout << "bool TAbsUsbWork::read () rLen = " << rLen << endl;
      
      if ( ret == LIBUSB_ERROR_TIMEOUT )
      {
         cout << "LIBUSB_ERROR_TIMEOUT" << endl;
//          closeUsb();
         return true;
      }
      
      if ( ret < 0 )
      {
         cout << "Error TAbsUsbWork::read " << strerror( errno ) << endl;
         closeUsb();
         return false;
      };
      
      cout << hex << "readBuff = ";

      for (int i=0; i<rLen; i++)
         cout << (unsigned int)currPtr[i] << "|";
      cout << dec << endl;
      currPtr += rLen;

      
      if ( rLen > 0 )
      {
// cout << "insertReceived queue = " << queue << endl;
         return queue->insertReceived (readBuff, rLen);                       //Постановка принятого сообщения в очередь
// cout << "insertReceived queue 2 = " << queue << endl;
      }
      else if ( rLen == 0)
      {
         ///????Может быть потребуется какая-то обработка. 0 - это конец файла
         cout << "TAbsUsbWork::read nothing to read..." << endl;
      }
      else if ( rLen < 0)
      {
         if ( ( errno == EAGAIN ) || ( errno == EWOULDBLOCK) )
         {
            return true;
         }
         cout << "Error TAbsUsbWork::read " << strerror(errno) << endl;
         return false;
      };
      return true;
   };   
};
//-------------------------------------------------------------------------------------------------//

