/**
   \file tpam.cpp
   \brief Реализация класса TPam.
   \author
   \version
   \date 19.05.2011
*/
#include "tpam.h"

/*-------------------------------------------------- tpam.cpp ------+
|     TOR              -=*  TPam Class  *=-                         |
+-------------------------------------------------------------------+
|     Started  19 May 2011                                          |
|     Last revision:                                                |
|              19 May 2011                                          |
+-------------------------------------------------------------------+
|     Purpose:   class for users identification                     |
|                                                                   |
|     Company:   NIIA Rayzan                                        |
|     Athours:   Zaytsev A.A, Likhobabin E.A.                       |
|     Usage:     by calling appropriate functions                   |
|                                                                   |
+------------------------------------------------------------------*/

namespace _std
{
   static string user;
   /* used to pass the password to the conversation function */
   static string PAM_password;
   
   pam_handle_t *pamh;
   /*-
   * PAM conversation function
   * Here we assume (for now, at least) that echo on means login name, and
   * echo off means password.
   */
   /*************************************************************/
   static int PAM_conv(int num_msg, const  struct pam_message **msg, struct pam_response **resp, void *appdata_ptr)
   {
      int replies = 0;
      struct pam_response *reply = NULL;
      if (appdata_ptr == NULL)
         appdata_ptr = NULL;
      
      reply = (struct pam_response *) malloc(sizeof (struct pam_response) *num_msg);
   
      if (!reply)
         return PAM_CONV_ERR;
      
      char userStr[user.length()];
      strcpy(userStr, user.c_str());

      char PAM_passStr[user.length()];
      strcpy(PAM_passStr, PAM_password.c_str());

      for (replies = 0; replies < num_msg; replies++) 
      {
         switch (msg[replies]->msg_style) 
         {
            case PAM_PROMPT_ECHO_ON:
               reply[replies].resp_retcode = PAM_SUCCESS;
               reply[replies].resp = COPY_STRING(userStr);
               /* PAM frees resp */
            break;
            case PAM_PROMPT_ECHO_OFF:
               reply[replies].resp_retcode = PAM_SUCCESS;
               reply[replies].resp = COPY_STRING(PAM_passStr);
               /* PAM frees resp */
            break;
            case PAM_TEXT_INFO:
               /* ignore it... */
               reply[replies].resp_retcode = PAM_SUCCESS;
               reply[replies].resp = NULL;
            break;
            case PAM_ERROR_MSG:
               /* ignore it... */
               reply[replies].resp_retcode = PAM_SUCCESS;
               reply[replies].resp = NULL;
            break;
            default:
               /* Must be an error of some sort... */
               (void) free((void *) reply);
            return PAM_CONV_ERR;
         }
      }
      *resp = reply;
      return PAM_SUCCESS;
   }
   /*************************************************************/
   static struct pam_conv PAM_conversation =
   {
      &PAM_conv,
      NULL
   };   
   /*************************************************************/
   
   TPam::TPam(string serviceName, string group)
   {
      this->serviceName = serviceName;
      this->group = group;
   };   
   /*************************************************************/
   
   TPam::~TPam()
   {
   };
   /*************************************************************/
   
   bool TPam::checkPassword(string userInserted, string passInserted)
   {
      struct passwd * cur_usr;
      struct group * usr_grp;

      
      int status;
      user = userInserted;
      PAM_password = passInserted;
      
     
      
      
   cout << "user=["<< user<<"] pwd=["<< PAM_password<<"]"<< endl;      
   
      if ((pam_start(serviceName.c_str(), user.c_str(), &PAM_conversation, &pamh)) != PAM_SUCCESS)
      {  
         cout << endl << " fail pam_start " << endl;
         return false;
      }
   
      status = pam_authenticate(pamh, 0);
   
   cout << "   status = pam_authenticate(pamh, 0)" << endl;   
      if (status == PAM_SUCCESS)
      {   
         cur_usr = getpwnam(user.c_str());
         usr_grp = getgrnam(group.c_str());
         if (usr_grp == NULL)
         {
    cout << "GROUP ==NULL"<< endl;        
            return false;
         };
   cout << " PAM_SUCCESS  cur_usr="<< cur_usr->pw_name << "group = "<< group<< endl;

         if (cur_usr->pw_gid == usr_grp->gr_gid)
         {
    cout << "USER & GROUP OK"<< endl;
            cout << "USERS of this groupt:"<<*(usr_grp->gr_mem)<< endl;
            return true;
         }
         else
         {
    cout << "USER.GROUP != GROUP "<< endl;        
            return false;
         }
      }
      cerr << "error: " << pam_strerror(pamh,status) << endl;
      return false;
   }
   /*************************************************************/

   bool TPam::addUser(string name, string passwd)
   {
      string command = "/usr/sbin/useradd --password ";
      command += crypt(passwd.c_str(), "Zs"); //второй параметр - сделать случайным
                                                    // см man 3 crypt
      command += " --gid " + group + " -d /dev/null " + name;
      if (system(command.c_str()) == 0)
      {
         return true;
      };
      return false;
   };
   /*************************************************************/

   bool TPam::delUser(string name)
   {
      string command  = "/usr/sbin/userdel";
      command += " " + name;
      if (system(command.c_str()) == 0)
      {
         return true;
      };
      return false;
   };
   
   
   bool TPam::isYoursServiceAndGroup(string serv, string grp)
   {
      return ((serviceName == serv) && (group == grp));
   };
   
   string TPam::getGroupName()
   {
      return group;
   };
   
   string TPam::getServiceName()
   {
      return serviceName;
   };
   
   string TPam::getUserListString()
   {
      struct group * usr_grp;
      string localUserList;
      char * localUserCharList;
      
      usr_grp = getgrnam(group.c_str());
      
      if (usr_grp == NULL)
      {      
         localUserList = string("empty");
      } else
      {
         localUserCharList = *(usr_grp->gr_mem);
      
         if (localUserCharList == NULL)
         {
            localUserList = string("empty");
         } else
         {
            localUserList = string(localUserCharList);
         };
      };
      return localUserList;
      
   };
   
   
};
