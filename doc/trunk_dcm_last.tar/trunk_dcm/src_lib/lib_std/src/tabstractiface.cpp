/**
   \file tabstractiface.cpp
   \brief Реализация классов TIfaceState, TAbstractIface, TAbsIfaceObserver.
   \author Евгений Лихобабин
   \version 0.1
   \date 2011-06-07
*/
#include "tabstractiface.h"

using namespace std;
#define USLEEP_ENABLED 1

namespace _std
{
   TIfaceState::TIfaceState(int checkTimingUsec)
   {
   this->checkTimingUsec = checkTimingUsec;
   sayStr = "TIfaceState";
   };

   TIfaceState::~TIfaceState()
   {
   };

   void TIfaceState::pause()
   {
      #ifdef USLEEP_ENABLED
   usleep(checkTimingUsec);
      //         cout << "!!!!!!!!!!!!!!!!!!!!!!!!!" << try2ConnUsec<< endl;
      #endif //USLEEP_ENABLED
   };

   TIfaceState* TIfaceState::getNextState()
   {
   return nextState;
   };
   TIfaceState* TIfaceState::getPrevState()
   {
   return prevState;
   };
   void TIfaceState::setNextState(TIfaceState* state)
   {
   nextState = state;
   };
   void TIfaceState::setPrevState(TIfaceState* state)
   {
   prevState = state;
   };
   string TIfaceState::getSayStr()
   {
      return sayStr;
   };
   void TIfaceState::setSayStr(string sayStr)
   {
      this->sayStr = sayStr;
   };

   //------------------------------------------------------------------------------------------------------//
   //------------------------------------------------------------------------------------------------------//
   //------------------------------------------------------------------------------------------------------//
   unsigned int TAbsIfaceObserver::num = 0;

   TAbsIfaceObserver::TAbsIfaceObserver(TAbstractIface* iface)
   {
   num++;
   iface = NULL;
		if (iface == NULL) {}
   };

   TAbsIfaceObserver::~TAbsIfaceObserver()
   {
   num--;
   };

   unsigned int TAbsIfaceObserver::getNum()
   {
   return num;
   };
   //------------------------------------------------------------------------------------------------------//
   //------------------------------------------------------------------------------------------------------//
   //------------------------------------------------------------------------------------------------------//
   TAbstractIface::TAbstractIface()
   {
   threadId = 0;   
   pthread_mutex_init(&listMutex, NULL);   
      //    num++;
      //    iface = NULL;
   };

   TAbstractIface::~TAbstractIface()
   {
      //    num--;
   };

   void TAbstractIface::clearList()
   {
   list<TIfaceState*>::iterator state = stateList.begin();
   for(; state != stateList.end(); state++)
   {
      delete *state;  
   }   
   };

   void * TAbstractIface::runFunc (void * p)
   {   
   TAbstractIface * iface = (TAbstractIface *) p;   
   iface->run();
   return NULL;
   };

   bool TAbstractIface::start()
   {   
   runFlag = true;
   currState = *stateList.begin();

   pthread_create (&threadId, NULL, &runFunc, (void*) this);
   
   if (pthread_detach (threadId) != 0) //Отсоединяем поток, чтобы не превратился в зомби и не требовал вызова
      perror("ping:pthread_detach");//pthread_join(...)
      
   return true;
   };

   TIfaceState* TAbstractIface::getState()
   {
   return currState;
   };

   void TAbstractIface::setState(TIfaceState* state)
   {
   currState = state;
      //   notify();
   };

   void TAbstractIface::run()
   {   
   TIfaceState* testNextState = currState;
   do
   {
      //       bool result = testNextState->checkState();// Для отладки - чтобы смотреть, что пришло из функции.
            cout << "before testNextState->checkState() " << testNextState->getSayStr() << endl;
            if ( testNextState->step() )
      {
         //currState = tmpIter;
               cout << "true" << endl;
         setState(testNextState);
          
               cout << "testNextState++" << endl;
         testNextState = testNextState->getNextState();
      }
      else if ( testNextState != *stateList.begin())
      {
               cout << "false" << endl;
               cout << "testNextState--" << endl;
         testNextState = testNextState->getPrevState();
         setState(testNextState);
      //          currState = tmpIter;
      };      
            cout << "currState       " << currState->getSayStr() << endl;
            cout << "testNextState   " << testNextState->getSayStr() << endl;
            cout << endl;
            cout << endl;
      currState->pause();
            cout << "after pause" << endl;
   }
   while (runFlag);
   };

   void TAbstractIface::addState(TIfaceState* state)
   {
   pthread_mutex_lock(&listMutex);
   stateList.push_back(state);  
      //    cout << stateList.size() << "added state => " << state->sayStr << endl;
   pthread_mutex_unlock(&listMutex);
   };
   
   void TAbstractIface::delState(TIfaceState* state)
   {
      pthread_mutex_lock(&listMutex);
//       string tmp = state->getSayStr();
      stateList.remove(state);
   //    cout << stateList.size() << "remove state => " << state->getSayStr() << endl;
      pthread_mutex_unlock(&listMutex);
   };

   // void TAbstractIface::notify()
   // {
   //    list<TAbsIfaceObserver*>::iterator tmpIter;
   //    for(tmpIter = observers.begin(); tmpIter != observers.end(); tmpIter++)
   //    {
   //       (*tmpIter)->update();
   //    };
   // };

   // void TAbstractIface::attach(TAbsIfaceObserver* observer)
   // {
   //    observers.push_back(observer);
   // };
   // 
   // void TAbstractIface::detach(TAbsIfaceObserver* observer)
   // {
   //    list<TAbsIfaceObserver*>::iterator tmpIter;
   //    for(tmpIter = observers.begin(); tmpIter != observers.end(); tmpIter++)
   //    {
   //       if((*tmpIter)->getNum() == observer->getNum())
   //       {
   //          observers.erase(tmpIter);
   //          break;
   //       };
   //    };
   // };
};


