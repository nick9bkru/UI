/**
   \file tabsipifacestates.cpp
   \brief Реализация классов TAbsIpNA, TAbsIpPinging.
   \author Лихобабин Евгений
   \version 0.1
   \date 2010-09-23
*/
#include "tabsipifacestates.h"

namespace _std
{

   TAbsIpNA::TAbsIpNA(int checkTimingUsec):TIfaceState(checkTimingUsec)
   {
      setSayStr("TAbsIpNAState");
   };

   TAbsIpNA::~TAbsIpNA()
   {
   };

   bool TAbsIpNA::step()
   {
   return true;   
   };

   //-------------------------------------------------------------------------------------------------//
   TAbsIpPinging::TAbsIpPinging(string ip, int checkTimingUsec):TIfaceState(checkTimingUsec)
   {
   this->ip = ip;
      setSayStr("TAbsIpPingingState");
   };

   TAbsIpPinging::~TAbsIpPinging()
   {
   };

   bool TAbsIpPinging::step()
   {
   std::string pingStr = "/bin/ping -q -c 1 -w 1 ";
   pingStr += ip;
   pingStr += " > /dev/null";
   int res = system (pingStr.c_str());
   if (res == 0)
      return true;
   else
      return false; 
   };
   //-------------------------------------------------------------------------------------------------//
};

