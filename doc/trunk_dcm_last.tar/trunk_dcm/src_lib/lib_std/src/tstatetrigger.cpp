
#include <string.h>
#include "tstatetrigger.h"

namespace _std
{

   TStateTrigger::TStateTrigger(string name = "noName")
   {
   triggerName = name;
   verbose= false;
   };
   
   TStateTrigger::~TStateTrigger()
   {
   verbose = false;
   holded = true;
   };
   
   void TStateTrigger::setupTrigger(unsigned int onPeriod,unsigned int offPeriod)
   {
   ON_PERIOD = onPeriod;
   OFF_PERIOD = offPeriod;
   pthread_mutex_init(&Mutex, NULL);
   };
   
   void TStateTrigger::setOn()
   {
   int lock_result;
   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {
      holded = false;
      ON_OFF = true;
      isChanged = true;
      pthread_mutex_unlock (&Mutex);
   } else //Error
   {
      if (verbose)
         cout << "TStateTrigger::setOn = " << strerror( lock_result ) << endl;
   };      
   };

   void TStateTrigger::setOff()
   {
   int lock_result;
   
   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {
      holded = false;
      ON_OFF = false;
      isChanged = true;
      pthread_mutex_unlock (&Mutex);
   } else //Error
   {
      if (verbose)
         cout << "TStateTrigger::setOff = " << strerror( lock_result ) << endl;
   };      
   };
   
   void TStateTrigger::hold()
   {
   int lock_result;
   
   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {
      holded = true;
      counterOff = 0;
      counterOn = 0;
      isChanged = true;
      pthread_mutex_unlock (&Mutex);
   } else //Error
   {
      if (verbose)
         cout << "TStateTrigger::hold() = " << strerror( lock_result ) << endl;
   };      
   }

   void TStateTrigger::change(bool newState)
   {
   int lock_result;
   if(verbose)
      cout<< "TStateTrigger::change(bool newState)"<< endl;
   
   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {      
      if(verbose)
         cout<< triggerName<<" change("<< newState<<") onoff= "<< ON_OFF<<" CounterOFF = "<< counterOff<< "counterOn = " << counterOn << endl;

      if (newState)
        counterOff = 0;
      else
        counterOn = 0; 
      
      if (holded)
      {
         if (!newState)
         {
           counterOn = 0; 
           if (counterOff++ >= OFF_PERIOD)
            {
               ON_OFF = false;
               counterOn = 0;
               isChanged = true;
               holded = false;
               if(verbose)
                 cout<< triggerName<< " 1 TStateTrigger::change(onoff= "<< ON_OFF<< endl;
            };            
         }
         else 
            if (newState)
            {
              counterOff = 0; 
              if (counterOn++ >= ON_PERIOD)
               {
                  ON_OFF = true;
                  counterOff = 0;
                  isChanged = true;
                  holded = false;
                  if(verbose)
                    cout<< triggerName<< " 2 TStateTrigger::change(onoff= "<< ON_OFF<< endl;
               };            
            };         
      } 
      else 
      {
         if (ON_OFF)
         {
            if (!newState)
            {
              counterOn = 0; 
              if (counterOff++ >= OFF_PERIOD)
               {
                  ON_OFF = false;
                  isChanged = true;
                  if(verbose)
                    cout<< triggerName<< " 3 TStateTrigger::change(onoff= "<< ON_OFF<< endl;
               };            
            };
         } 
         else
         {
            if (newState)
            {
              counterOff = 0; 
              if (counterOn++ >= ON_PERIOD)
               {
                  ON_OFF = true;
                  counterOff = 0;
                  isChanged = true;
                  if(verbose)
                    cout<< triggerName<< " 4 TStateTrigger::change( onoff = "<< ON_OFF<<" )" << endl;
               };            
            };         
         }
         
      };
      pthread_mutex_unlock (&Mutex);
      return;
   } else //Error
   {
      if (verbose)
         cout << "TStateTrigger::change = " << strerror( lock_result ) << endl;
   };
   
   };
   

   bool TStateTrigger::getSimpleState()
   {
   int lock_result;
   bool result;

   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {
      if (ON_OFF)
         result = true;
      else 
         result = false;
      pthread_mutex_unlock (&Mutex);
   }
   else //Error
   {
      cout << "TStateTrigger - " << strerror( lock_result ) << endl;
      result = false;
   };
   
   if(verbose)
      cout << triggerName<<"getSimpleState = " << result<< endl;
   
   return result;

   };

   int TStateTrigger::getState()
   {
   int lock_result;
   int result;

   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {
      if (holded)
         result = ents_HOLDED;
      else if ((isChanged) && (ON_OFF))
         result = ents_ON;
      else if
         ((isChanged) && (!ON_OFF))
         result = ents_OFF;
      else
         result = ents_NOT_CHANGED;
      
      isChanged = false;   
      pthread_mutex_unlock (&Mutex);
   }
   else //Error
   {
      cout << "TStateTrigger - " << strerror( lock_result ) << endl;
      result = ents_NOT_CHANGED;
   };
   
   if(verbose)
      cout << triggerName<<"getState = " << result<< endl;
   
   return result;
   };
   
   bool TStateTrigger::getChanged()
   {
   int lock_result;
   bool result;

   if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
   {
      result = isChanged;
      pthread_mutex_unlock (&Mutex);
   }   
   else //Error
   {
      cout << "TStateTrigger - " << strerror( lock_result ) << endl;
      result = false;
   };
   return result;
   };
   
   void TStateTrigger::setVerbose(bool verb)
   {
   verbose = verb;
   };


   void TStateTrigger::show()
   {
   bool tempIsChanged;
   tempIsChanged = isChanged;
   cout << "+++ Trigger [ "<< triggerName<< " ] state +++" << endl;
   cout << "+ holded == [ " << holded << " ]" << endl;
   cout << "+ changed = [ " << isChanged << " ]" << endl;
   cout << "+ ONOFF === [ " << ON_OFF << " ]" << endl;
   cout << "+ getState =[ " << getState() << " ]" << endl;
      isChanged = tempIsChanged;  
   };
};

