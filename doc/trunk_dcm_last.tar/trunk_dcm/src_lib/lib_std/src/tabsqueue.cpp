/**
   \file tabsqueue.cpp
   \brief Реализация класса TAbsQueue.
   \author Зайцев А.А., Лихобабин Е.А.
   \version 2012-01-10
*/

#include "tabsqueue.h"

using namespace std;

namespace _std
{
   /*---------------------------------------------------------------------------*/
   TAbsQueue::TAbsQueue (string new_name, int count_number, int verb)
   {
      verbose = verb;

      name = new_name;

      subQueNumber   = count_number;
      isHeartBeat    = false;
      genericMessage = NULL;

      codogram_number  = (int*) calloc (count_number, sizeof (int));
      waitFlagPointer  = (bool*) calloc (count_number, sizeof (bool));
      heartBeatCounter = (int*) calloc (count_number, sizeof (int));
      hbLine           = (TAbsMessage **) calloc (count_number, sizeof (void*));

      messageFactory = NULL;
      pthread_mutex_init (&Mutex, NULL);
      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "*** create queue [ " << name << " ] with " << count_number << " subqueue ***" << std::endl;
      }
   };

   /*---------------------------------------------------------------------------*/
   void TAbsQueue::setFactory (TAbsMessage* (*mf) ())
   {
      if (mf == NULL)
         return;

      messageFactory = mf;

      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "*** queue [ " << name << " ] apply new message factory ***" << std::endl;
      }

      setGenericMessage (messageFactory());
   //       std::cout << "*** queue [ " << name << " ] apply new message factory ***" << std::endl;

   };


   /*---------------------------------------------------------------------------*/
   TAbsQueue::~TAbsQueue()
   {
      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "*** queue [ " << name << " ] will be destroyed soon ***" << std::endl;
      }

      if (!sendingList.empty())
         sendingList.clear();
      if (!receivingList.empty())
         receivingList.clear();
      if (genericMessage != NULL)
         delete genericMessage;
      free(codogram_number);
      free(waitFlagPointer);
      free(heartBeatCounter);
      free(hbLine);
   };

   /*---------------------------------------------------------------------------*/
   bool TAbsQueue::insertReceived (char * data, int len)
   {
      if (data == NULL)
         return false;
      
      TAbsMessage * message;
      if (messageFactory != NULL)
      {
         message = messageFactory(); 
      }
      else
      {
         cout << "Error TAbsQueue::insertReceived messageFactory pointer is NULL!!!" << endl;
         exit(0);
      }
      map<char*, int> messages;
      map<char*, int>::iterator iter;
      
      messages = message->dataSplitter( data, len );
      if ( messages.empty() )
      {
         if ( !message->assign ( data, len ) )
            return false;

         if ( !insertReceived (message) )
            return false;
      }
      else
      {
         delete message;

         for( iter = messages.begin(); iter != messages.end(); iter++ )
         { 
            message = messageFactory();

            if ( !message->assign ( iter->first, iter->second ) )
               return false;

            if ( !insertReceived (message) )
               return false;
         };
      };
      
      return true;
   };


   /*---------------------------------------------------------------------------*/
   bool TAbsQueue::insertReceived (TAbsMessage * message)
   {
      if (message == NULL)
         return false;

      int lock_result;
      list<TAbsMessage*>::iterator cdgrm;

      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {

            for (cdgrm = receivingList.begin(); cdgrm != receivingList.end(); ++cdgrm)
            {
               if ( (*cdgrm)->compare (message))
               {

                  if (verbose >= qvl_VERBOSE_EVENT)
                  {
                     std::cout << "+++>>> in queue [ " << name << " ] repeat new received message  <<<+++" << std::endl;
                     std::cout << "+++>>> " << message->display() << " <<<+++" << std::endl << std::endl;
                  };
                     delete message;
                     (*cdgrm)->setRepeat (true);
                     pthread_mutex_unlock (&Mutex);
                     return true;
               };
            };

            receivingList.push_back (message);

            if (verbose >= qvl_VERBOSE_EVENT)
            {
               std::cout << "+++>>> in queue [ " << name << " ] insert new received message  <<<+++ [" << std::endl;
               std::cout << "+++>>> " << message->display() << " <<<+++" << std::endl << std::endl;
            };
            pthread_mutex_unlock (&Mutex);
            return true;
      }
      else //Error
      {
         cout << "TAbsQueue::insertReceived = " << strerror( lock_result ) << endl;
      };

      return false;
   };

   /*---------------------------------------------------------------------------*/
   bool TAbsQueue::insert2Send (TAbsMessage * message)
   {
      int lock_result;
      if (message == NULL)
      {
         cout << "message NULL" << endl;
         return false;
      };

      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {
            sendingList.push_back (message);
            message->setCodogramNumber (codogram_number);
            message->setSendingTime();
            if (verbose >= qvl_VERBOSE_EVENT)
            {
               std::cout << "+++<<< in queue [ " << name << " ] insert new message for sending >>>+++" << std::endl;
               std::cout << "+++<<<" << message->display() << " >>>+++" << std::endl << std::endl;
            };

            pthread_mutex_unlock (&Mutex);
            return true;
      }
      else //Error
      {
         cout << "TAbsQueue::insert2Send = " << strerror( lock_result ) << endl;
      };

      return false;

   };


   /*---------------------------------------------------------------------------*/
   bool TAbsQueue::readReceived (TAbsMessage ** message)
   {
      int lock_result;
      list<TAbsMessage*>::iterator cdgrm;

      if (message == NULL)
         return false;

      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {
            if (receivingList.empty())
            {
               pthread_mutex_unlock (&Mutex);
               return false;
            };

            for (cdgrm = receivingList.begin(); cdgrm != receivingList.end(); ++cdgrm)
            {
               //we catch top message and delete it from queue
               if ( (*cdgrm)->shouldBeRead())
               {
                  if (! (*cdgrm)->isRepeatable())
                  {
                     *message = (*cdgrm);

                     if (verbose >= qvl_VERBOSE_EVENT)
                     {
                        std::cout << "--->>> from queue [ " << name << " ] read received message <<<---" << std::endl;
                        std::cout << "--->>> " << (*message)->display() << " <<<---" << std::endl << std::endl;
                     };

                     receivingList.erase (cdgrm);

                     pthread_mutex_unlock (&Mutex);
                     return true;
                  }
                  else
                  {
                     (*cdgrm)->setShouldBeRead (false);
                     *message = (*cdgrm);

                     if (verbose >= qvl_VERBOSE_EVENT)
                     {
                        std::cout << "***>>> from queue [ " << name << " ] read received message without erasing <<<***" << std::endl;
                        std::cout << "***>>> " << (*message)->display() << " <<<***" << std::endl << std::endl;
                     };

                     pthread_mutex_unlock (&Mutex);
                     return true;
               };
            };
         };

         (*message) = NULL;

         pthread_mutex_unlock (&Mutex);
         return false;
      }
      else //Error
      {
         cout << "TAbsQueue::readReceived = " << strerror( lock_result ) << endl;
      };

      return false;
   }


   /*---------------------------------------------------------------------------*/
   TAbsMessage* TAbsQueue::readCdgrm2Send ()
   {
      list<TAbsMessage*>::iterator cdgrm;
      TAbsMessage * tempCdg = NULL;
      
      if (sendingList.empty())
      {
         return NULL;  //Было return false!!!
      };

      for (cdgrm = sendingList.begin(); cdgrm != sendingList.end(); ++cdgrm)
      {
         if ( (*cdgrm)->shouldBeSent (waitFlagPointer))
         {
            //cout << "LIST TO SEND NOT EMPTY!!!" << endl;
            tempCdg = *cdgrm;
            break;
         };
      };
      
      return tempCdg;
   };
   /*---------------------------------------------------------------------------*/
   int TAbsQueue::read2Send ( char * data, unsigned int maxLen )
   {
      int lock_result;
      int len;
      TAbsMessage * tempCdg = NULL;

      if (data == NULL)
         return -1;

      
      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {
         tempCdg = readCdgrm2Send();
         
         if (tempCdg == NULL)
         {
            pthread_mutex_unlock (&Mutex);
            return 0;
         };

         if (verbose >= qvl_VERBOSE_EVENT)
         {
            std::cout << "---<<< from queue [ " << name << " ] read2send message >>>---" << std::endl;
            std::cout << "---<<< " << tempCdg->display() << " >>>---" << std::endl << std::endl;
         };
         
         len = tempCdg->getData2Send (data, maxLen);  //we catch top message and copy data from it
   //	cout << "!!!--- len = " << len << endl;

         pthread_mutex_unlock (&Mutex);
         return len;
      }
      else //Error
      {
         cout << "TAbsQueue::read2Send = " << strerror( lock_result ) << endl;
      };

      return 0; //Было return false!!!
   };



   /*---------------------------------------------------------------------------*/
   void TAbsQueue::timeStep (int usec)
   {
      int lock_result;
      list<TAbsMessage*>::iterator cdgrm;

      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "*** in queue [ " << name << " ] timeStep for [ " << usec << " ] ***" << std::endl;
      };

      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {
         if (!sendingList.empty())
         {
            for (cdgrm = sendingList.begin(); cdgrm != sendingList.end(); ++cdgrm)
            {
               (*cdgrm)->timeStep (usec);
            };
         };

         if (!receivingList.empty())
         {
            for (cdgrm = receivingList.begin(); cdgrm != receivingList.end(); ++cdgrm)
            {
               (*cdgrm)->timeStep (usec);
            };
         };

         if (isHeartBeat)
         {
            for (int idx = 0; idx < subQueNumber; idx++)
            {
               heartBeatCounter[idx] += usec;
               hbLine[idx] = genericMessage->heartBeatMessage (&heartBeatCounter[idx]);
            };
         };

         pthread_mutex_unlock (&Mutex);

         if (isHeartBeat)
         {
            for (int idx = 0; idx < subQueNumber; idx++)
            {
               if (hbLine[idx] != NULL)
               {
                  insert2Send (hbLine[idx]);
                  hbLine[idx] = NULL;
               };
            };
         };
         
         return;
      }
      else //Error
      {
         cout << "TAbsQueue::timeStep = " << strerror( lock_result ) << endl;
      };
   };

   /*---------------------------------------------------------------------------*/
   TAbsMessage * TAbsQueue::whosTimeIsUp()
   {
      int lock_result;
      TAbsMessage * tempCdg = NULL;
      list<TAbsMessage*>::iterator cdgrm;

      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "*** in queue [ " << name << " ] whosTimeIsUp  ***" << std::endl;
      }

      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {
         if (!sendingList.empty())
         {
            for (cdgrm = sendingList.begin(); cdgrm != sendingList.end(); ++cdgrm)
            {
               if ( (*cdgrm) == NULL)
                  break;

               if ( (*cdgrm)->timeIsUp())
               {
                  if (verbose >= qvl_VERBOSE_EVENT)
                  {
                     std::cout << "---<<< in queue [ " << name << " ] timeIsUp for sended message >>>---" << std::endl;
                     std::cout << "---<<< " << (*cdgrm)->display() << " >>>---" << std::endl << std::endl;
                  }
                  tempCdg = *cdgrm;
                  sendingList.erase (cdgrm);
                  break;
               };
            };
         };


         if ( (tempCdg == NULL) && (!receivingList.empty()))
         {
            for (cdgrm = receivingList.begin(); cdgrm != receivingList.end(); ++cdgrm)
            {
               if ( (*cdgrm) == NULL)
                  break;

               if ( (*cdgrm)->timeIsUp())
               {
                  if (verbose >= qvl_VERBOSE_EVENT)
                  {
                     std::cout << "--->>> in queue [ " << name << " ] timeIsUp for received message <<<---" << std::endl;
                     std::cout << "--->>> " << (*cdgrm)->display() << " <<<---" << std::endl << std::endl;
                  };
                  tempCdg = *cdgrm;
                  sendingList.erase (cdgrm);
                  break;
               };
            };
         };

         if (tempCdg == NULL)
         {
            pthread_mutex_unlock (&Mutex);
            return NULL;
         };

         pthread_mutex_unlock (&Mutex);
         return tempCdg;
      }
      else //Error
      {
         cout << "TAbsQueue::whosTimeIsUp = " << strerror( lock_result ) << endl;
      };
      
      return false;
   };

   /*---------------------------------------------------------------------------*/
   void TAbsQueue::lookForMessage (TAbsMessage * pattern)
   {
      int lock_result;
      bool interupt = false;
      TAbsMessage * tempCdg = NULL;
      list<TAbsMessage*>::iterator cdgrm;

      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "*** in queue [ " << name << " ] lookForMessage for message  ***" << std::endl;
         std::cout << "*** " << pattern->display() << " ***" << std::endl << std::endl;
      }

      if ( (lock_result = pthread_mutex_lock (&Mutex)) == 0) // if success then use it
      {
            if (receivingList.empty())
            {
               pthread_mutex_unlock (&Mutex);
               return;
         };

            for (cdgrm = receivingList.begin(); cdgrm != receivingList.end(); ++cdgrm)
         {
               if ( (*cdgrm)->compare (pattern))
               {
                  tempCdg = *cdgrm;
                  interupt = true;
                  break;
            };
         };

            if (interupt)
            {
               pattern->setRepeat (true);
               (*cdgrm)->setShouldBeRead (true); //готовность к функции readRecieved()
            }
            else
            {
               pattern->setRepeat (false);
               receivingList.push_back (pattern);
               pattern->setShouldBeRead (true);//готовность к функции readRecieved()
            }
            pthread_mutex_unlock (&Mutex);
         }
      else //Error
         {
         cout << "TAbsQueue::lookForMessage = " << strerror( lock_result ) << endl;
      };
   };
   //--------------------------------------------------------------------------
   TAbsMessage * TAbsQueue::getSentMessage(TAbsMessage * ticket)
   {
      int lock_result;
      TAbsMessage * tempCdg = NULL;
      list<TAbsMessage*>::iterator cdgrm;
      if (verbose >= qvl_VERBOSE_ALL)
      {
            std::cout << "*** in queue [ " << name << " ] getSentMessage for message  ***" << std::endl;
            std::cout << "*** " << ticket->display() << " ***" << std::endl << std::endl;
      }

      if ( (lock_result = pthread_mutex_lock(&Mutex)) == 0)
      {
         if (sendingList.empty())
         {
            if (verbose >= qvl_VERBOSE_ALL)
            {
               std::cout << "*** in queue [ " << name << " ] sendinglist is empty  ***" << std::endl;
            }
            pthread_mutex_unlock (&Mutex);
            return NULL;
         }

         for (cdgrm = sendingList.begin(); cdgrm != sendingList.end(); ++cdgrm)
         {
            if ( (*cdgrm)->compare (ticket))
            {
               if (verbose >= qvl_VERBOSE_EVENT)
               {
                  std::cout << "---<<< in queue [ " << name << " ] getSentMessage  >>>---" << std::endl;
                  std::cout << "---<<< " << (*cdgrm)->display() << " >>>---" << std::endl << std::endl;
               }
               tempCdg = *cdgrm;
               sendingList.erase (cdgrm); ///?????????????????
               break;
            };
         };
         
         pthread_mutex_unlock (&Mutex);
         return tempCdg;
      }
      else //Error
      {
         cout << "TAbsQueue::getSentMessage = " << strerror( lock_result ) << endl;
      };
      return NULL;
   };
   /*---------------------------------------------------------------------------*/
   void TAbsQueue::delMessageFor (TAbsMessage * pattern)
   {
      TAbsMessage *tempCdg = getSentMessage(pattern);

      if (tempCdg != NULL)  //&& (cdgrm != sendingList.end())
      {
//          cout << "Message deleted!!!!!!!!!!!!!!!!!   " << tempCdg->display() << endl;
         delete (tempCdg);
      };
   };
   /*---------------------------------------------------------------------------*/

   /* ln = 'r' for receiving list and 's' for sending list */
   void TAbsQueue::show (char ln)
   {
      list<TAbsMessage*>::iterator cdgrm;

      if (ln == 's')
      {
         std::cout << std::endl << "== show queue [ " << name << " ] - sending list | wfp = " << waitFlagPointer[0] << "== " << std::endl;
         for (cdgrm = sendingList.begin(); cdgrm != sendingList.end(); ++cdgrm)
         {
            std::cout << (*cdgrm)->display() << std::endl;
         }
      }
      else
      {
         std::cout << std::endl << "========== show queue [ " << name << " ] - receiving list ============" << std::endl;
         for (cdgrm = receivingList.begin(); cdgrm != receivingList.end(); ++cdgrm)
         {
            std::cout << (*cdgrm)->display() << std::endl;
         }
      }
      std::cout << "=========================================================================" << std::endl << std::endl;
   }


   void TAbsQueue::setHeartBeat (bool ishb)
   {
      if (genericMessage == NULL)
         isHeartBeat = false;
      else
         isHeartBeat = (ishb && genericMessage->isHeartBeat());
   };

   void TAbsQueue::setGenericMessage (TAbsMessage * gm)
   {
      if (genericMessage != NULL)
         delete genericMessage;

      genericMessage = gm;

      isHeartBeat = genericMessage->isHeartBeat();
      genericMessage->setGeneric();

      if (verbose >= qvl_VERBOSE_ALL)
      {
         std::cout << "New generic message was added [" << gm->display() << "]" << std::endl;
      };
   };
   
   void TAbsQueue::resetHeartBeatTimer( int subQueueNumber )
   {
      heartBeatCounter[subQueueNumber] = 0;
   };
};
//714
/*===========================================================================*/

