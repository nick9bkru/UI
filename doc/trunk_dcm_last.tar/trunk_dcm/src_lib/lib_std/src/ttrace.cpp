/**
   *\file ttrace.cpp
   *\brief Файл с реализацией класса TTrace.
   *\author Зайцев А.А. Гусинская Е.И. Воронков Д.В. Устинова Е.А. Воронкова Т.В. Якунин С.А. Лихобабин Е.А.
   *\version 2010-06-18
*/

#include "ttrace.h"

namespace _std
{
   TTrace::TTrace()
   {
   };

   TTrace::TTrace (TDbgType curDbgName)
   {
   curDebugger = curDbgName;
   };

   TDbgType TTrace::curDebugger = smc_NOT_DEFINED;
};

