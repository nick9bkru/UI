/**
   \file tpathfinder.cpp
   \brief Реализация класса TPathFinder
   \author ЛихобабаниЕ.А., Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

/*-------------------------------------------- tpathfinder.cpp -----+
|     TOR        -=*  PathFinder Class  *=-                         |
+-------------------------------------------------------------------+
|     Started  9 Jun 2009                                           |
|     Last revision:                                                |
|              11 Jun 2009                                           |
+-------------------------------------------------------------------+
|     Purpose:   realization of TPathFinder methods of this class   |
|                perform finding paths                              |
|                                                                   |
|     Company:   NIIA Rayzan                                        |
|     Athours:   Likhobabin E.A.                                    |
|     Usage:     only one instance of this class should be created  |
|                                                                   |
+------------------------------------------------------------------*/

#include "tpathfinder.h"

namespace _std
{

   char TPathFinder::target_path[MAX_PATH_LENGTH];    ///< путь до цели

   TPathFinder::TPathFinder()
   {
   };

   TPathFinder::~TPathFinder()
   {
   };

   char* TPathFinder::getAbsPath (int numCutDir)
   {
   //    char link_path[MAX_PATH_LENGTH];
   //    char exe_path[MAX_PATH_LENGTH];
   char link_path[MAX_PATH_LENGTH];
   char exe_path[MAX_PATH_LENGTH];
   int len;
   int i, j;
   sprintf (link_path, "/proc/self/exe");
   len = readlink (link_path, exe_path, sizeof (target_path));  //Получаем абсолютный путь до каталога из которого запущена программа
   //и записывае его в строку exe_path
   if (len == -1)
   {
      perror ("TPathFinder::getAbsPath:");
      exit (-1);
   };

   if (numCutDir == 0)
   {
      strncpy (target_path, exe_path, len);
      target_path[len] = 0x0;                                          //Добавление нуля к концу строки, содержащей путь - readlink() сама не добавляет его
      return target_path;
   }
   
   j = 0;
   for (i = len; i > 0; i--)            //Цикл поиска и отбрасывания элементов пути
   {
      if (exe_path[i] == '/')
      {
         j++;
      }
      if (j == numCutDir)
         break;


   }
   if (i == 0)                  //Число отбрасываемых элементов пути больше чем число элементов в пути
   {
      strncpy (target_path, "error", 5);
      return target_path;
   }
   strncpy (target_path, exe_path, i);
   target_path[i] = 0x0;                                          //Добавление нуля к концу строки, содержащей путь - readlink() сама не добавляет его
   return target_path;
   };

   const char * TPathFinder::getSpecificPath (TSpecificPathType specific)
   {


   switch (specific)
   {
      case gsp_BIN:
         getAbsPath (2);
         newPath = target_path;
         newPath += "/bin/";
         break;
      case gsp_BUILD:
         getAbsPath (1);            //Сделано для АРМ ОТУ там бинарники лежали в /build/uims
         newPath = target_path;
         newPath += "/";
         break;
      case gsp_LOG:
         getAbsPath (2);
         newPath = target_path;
         newPath += "/log/";
         break;
      case gsp_JOURNAL:
         getAbsPath (2);
         newPath = target_path;
         newPath += "/journal/";
         break;
      case gsp_BIN_EXE_WITHOUT_EXT:
         getAbsPath (0);
         newPath = target_path;
         size_t found;
         found=newPath.find_last_of("/\\");
         newPath = newPath.substr(found+1);
         found=newPath.find_last_of(".");
         newPath = newPath.substr(0,found);
         break;

   }
   return newPath.c_str();
   };

   bool TPathFinder::isFileExist(string path)
   {
   if (access (path.c_str(), F_OK) == 0)
      return true;
   else
   {
      cout << path << ": нет такого файла или каталога." << endl;
      return false;
   }
   }
};
