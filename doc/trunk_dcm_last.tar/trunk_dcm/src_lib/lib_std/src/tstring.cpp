/**
   *\file tstring.cpp
   *\brief Реализация функций работы с std::string строками
   *\author Зайцев А.А. Гусинская Е.И. Во Файл с описанием класса функцийронков Д.В. Устинова Е.А. Воронкова Т.В. Якунин С.А. Лихобабин Е.А.
   *\version 2011-02-28
*/
#include "tstring.hpp"

namespace _std
{
   //------------------------------------------------------------------------------
   //Удаление ведущих нулей в IP-адресе для его дальнейшего использования ОС
   string eraseLeadingNulls(string _currentIp)
   {
      string findSubstr = string(".0");
      string calcIp ="."+ _currentIp;
      size_t res = 0;
      while (res != string::npos)
      {
         res = calcIp.find(".0");
         if (res != string::npos)
         {
            if (calcIp.length() != res+2)
               calcIp.erase(res+1,1);
            else
               break;
         }
      }
      res = 0;
      while (res != string::npos)
      {
         res = calcIp.find("..");
         if (res != string::npos)
            calcIp.replace(res+1,1,"0.");
      }         
      calcIp.erase(0,1);
      return calcIp;
   }
};
