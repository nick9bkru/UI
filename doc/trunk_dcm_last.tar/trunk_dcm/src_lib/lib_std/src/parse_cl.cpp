/**
   \file parse_cl.cpp
   \brief Реализация функций для рабора файла параметров приложения
   \author Зайцев А.А.
   \version
   \date 20.11.2008
*/

#include "parse_cl.h"
#include <string.h>
//#include "lib_std.h"
#include <unistd.h>

namespace _std
{
   /*--------------------------------------------------------------------------*/
   int usage (const char *s)
   {
   ENV_ITEM * el = env_table->items;
   int i = 0;
   char string[512];

   //    printf("\nUsage: %s ", env_table->programm);
   //    printf("%s\n", env_table->usage);

   if (el == NULL)
   {
      return 1;
   }

   for (;el->key; el++)
   {
      if (el->key > 64)       /* if key is letter -------------- */
      {
         i = sprintf (string, " -%c\t%s", el->key, el->usage);
         if (*s == 'v')
         {
            if (i > 0)
            {
               printf ("%s\n", string);
               i = 0;
            }
            if (el->value)
            {
               if (ph_tstenvkeydf (el->key))
               {
                  i += sprintf (string + i,
                                "\t____Set value <%s> by default____\n",
                                el->value
                               );
               }
               else
               {
                  i += sprintf (string + i,
                                "\t____Set value <%s>____\n", el->value
                               );
               }
            }
            if (i) printf ("%s\n", string);
         }
      }
      else if (el->key > 48)
      {
         if (ph_tstenvkey (el->key))
         {
            printf ("File[%c] - Set value <%s>\n\n", el->key, el->value);
         }
      }
   }
   if (*s != 'v') return 1;
   for (el = env_table->items; el->key; el++)
   {
      if (el->key < 32)
      {
         if ( (i = sprintf (string, "<%s>=%s", el->name, el->value)) >= 16)
         {
            printf ("%s\n", string);
            sprintf (string, "\t\t%s", el->usage);
         }
         else if (i < 8)
         {
            sprintf (string + i, "\t\t%s", el->usage);
         }
         else
         {
            sprintf (string + i, "\t%s", el->usage);
         }
         printf ("%s\n", string);
      }
   }
   return 1;
   }
   /*--------------------------------------------------------------------------*/

   int parseCall (ENV_ITEM * _env_items, int argc, char ** argv)
   {
   ENV_ITEM * env_line;
   int i;
   /*--- set initial parameters and addressess for com.line parsing ---*/
   env_table->items    =       _env_items; /* set address of items list    */
   env_line = _env_items;/*env_table -> items;                             */
   env_table->programm = argv[0];    /* set programm name as it was called */
   if (env_line == NULL) return 1;            /* no requests env. parses   */
   if (argc < 2)         return 0;            /* no command line was spec. */

   /*----------------------- processing command line ------------------ */
   for (i = 1; argv[i] != NULL;)
   {
      if (*argv[i] == '-')
      {
         if (* (argv[i] + 1) == '-')
         {
            return ++i;
         }
         if (ph_setkey (env_line, &argv[i])) 
         {  
            i++;
         };
         i++;
      }
      else if (ph_setpar (env_line, &argv[i]))
      {
         i++;
      }
      else break;
   }
   return i;

   }
   /*--------------------------------------------------------------------------*/

   int ph_setpar (ENV_ITEM * el, char ** argv)
   {
   char * p = *argv;
   ENV_ITEM * s;

   /* set file names and other parameters here     */
   /* file name correspondents to key  '1','2',...,'9','0'  */
   /* files specified out of env_table live in command line  */
   for (s = el; s->key; s++)
   {
      if (isdigit (s->key)
            && ! (s->flag&ENV_FILE_SET)
            && ! (s->flag&ENV_PARAM_SET)
         )
      {
         s->flag |= ENV_PARAM_SET;
         s->value = p;
         return 1;
      }
   }
   return 0;
   }
   /*--------------------------------------------------------------------------*/
   int ph_setkey (ENV_ITEM * el, char ** argv)
   {
   ENV_ITEM * s;
   char * p = *argv;
   char * v;

   p++;
   do
   {
      for (s = el; s->key; s++)
      {
         if (s->key == *p)
         {
            s->flag |= ENV_PARAM_SET;
            if (s->flag & ENV_PARAM_VAL_REQ)
            {
               if ( (v = _get_param_addr (p)) == NULL)
               {
                  if (argv[1] == NULL)
                  {
                     if (s->value == NULL)
                     {
                        s->flag &= ~ENV_PARAM_SET;
                     }
                     else
                     {
                        s->flag |= ENV_PARAM_DFL;
                     }
                     return 0;
                  }
                  else
                  {
                     if (*argv[1] != '-')
                     {
                        s->value = argv[1];
                        return 1;
                     }
                     else
                     {
                        s->flag |= ENV_PARAM_DFL;
                     }
                  }
               }
               else
               {
                  s->value = v;
                  return 0;
               }
            }
         }
      }
   }
   while (* (++p));
   return 0;
   }
   /*--------------------------------------------------------------------------*/
   char * _get_param_addr (char * s)
   {
   s++;
   if (*s) return s;
   else return NULL;
   }
   /*--------------------------------------------------------------------------*/
   int ph_setenvkey (char key)
   {
   ENV_ITEM  * par = _findenvkey (key);

   if (par)
   {
      par->key |= ENV_PARAM_SET;
      return SUCCESS;
   }
   return ERROR;
   }
   /*--------------------------------------------------------------------------*/

   int ph_clrenvkey (char key)
   {
   ENV_ITEM  * par = _findenvkey (key);

   if (par)
   {
      par->key &= ~ENV_PARAM_SET;
      return SUCCESS;
   }
   return ERROR;
   }
   /*--------------------------------------------------------------------------*/
   int ph_tstenvkey (char key)
   {
   ENV_ITEM  * par = _findenvkey (key);

   if (par) return par->flag&ENV_PARAM_SET;
   return 0;
   }
   /*--------------------------------------------------------------------------*/
   int ph_tstenvkeydf (char key)
   {
   ENV_ITEM  * par = _findenvkey (key);

   if (par) return par->flag&ENV_PARAM_DFL;
   return 0;
   }
   /*--------------------------------------------------------------------------*/
   const void * ph_getkeyval (char key)
   {
   ENV_ITEM  * par = _findenvkey (key);

   return ( (par) ? &(par->value[0]) : NULL);
   }
   /*--------------------------------------------------------------------------*/
   ENV_ITEM  * _findenvkey (char key)
   {
   ENV_ITEM * el = env_table->items;
   for (; el->key; el++)
   {
      if (key == el->key) return el;
   }
   return NULL;
   }
   /*--------------------------------------------------------------------------*/
   ENV_ITEM  * _findenvname (char * name)
   {
   ENV_ITEM * el = env_table->items;
   for (; el->key; el++)
   {
      if (!strcmp (el->name, name)) return el;
   }
   return NULL;
   }
};
/*===========================================================================*/

