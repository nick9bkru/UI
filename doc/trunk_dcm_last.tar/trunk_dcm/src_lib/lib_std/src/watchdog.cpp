/**
   \file watchdog.cpp
   \brief Реализация классов TSheep, TWatchDog
   \author Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 20.11.2008
*/

#include "watchdog.h"

namespace _std
{
      
   TDogInfo dogInfo;
   int sheep_counter;
   int dog_counter;
   //void TWatchDog::sig_handler(int signo, siginfo_t *info, void *f);


   /*-------------------------------------------------------------------------------*/
   TSheep::TSheep (char * dogName, char * sheepName, int watchTime)
   {
   dogInfo.timersDeep = 10;
   dogInfo.msTiming = watchTime;
   strcpy (dogInfo.dogName, dogName);
   strcpy (dogInfo.sheepName, sheepName);
   dogInfo.showLog = false;
   isStarted = false;
   //printf("createdog\n");

   };

   /*-------------------------------------------------------------------------------*/

   void TSheep::runDog()
   {
   //printf("TSheep::runDog(%s)\n",dogInfo.dogName);

   pid_t a;

   if ( (a = fork()) ==  0)
   {
      execl (dogInfo.dogName, dogInfo.dogName, NULL);
      exit (0);
      return;
   }
   else
   {

      dogInfo.dogPid = a;
      return;
   }

   return;
   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::setTimersDeep (int td)
   {
   dogInfo.timersDeep = td;
   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::setTiming (int msT)
   {
   dogInfo.msTiming = msT;
   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::setShowLog (bool sl)
   {
   dogInfo.showLog = sl;
   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::startWatching()
   {

   sheep_counter = 0;

   struct sigaction act1;
   struct sigaction act2;

   act1.sa_handler = SIG_IGN;
   sigemptyset (&act1.sa_mask);

   sigaction (SIGUSR2, &act1, NULL); //sigusr2 �������� ����, � ������ ��� ������������

   act2.sa_flags |= SA_SIGINFO;
   act2.sa_sigaction = sig_handler;
   sigemptyset (&act2.sa_mask);

   sigaction (SIGUSR1, &act2, NULL); // sigusr1 �������� ������ � �� �� ��� ������ �����������
   isStarted = true;


   runDog();

   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::stopWatching()
   {
   //   printf("������������ ������\n");
   isStarted = false;
   kill (dogInfo.dogPid, SIGKILL);
   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::timerslot()
   {
   if (!isStarted)
      return;

   sheep_counter++;

   //   if (dogInfo.showLog)
   //      printf("sheep counter == %d\n",sheep_counter);

   kill (dogInfo.dogPid, SIGUSR2);  // �������� ���� ��-�-�-�

   if (sheep_counter > dogInfo.timersDeep)
   {
   //      if (dogInfo.showLog)
   //         printf("������� ����� ������\n");

      stopWatching();         // ���� ������ ����� �� ��������
      startWatching();        // ������� �����
   }
   };
   /*-------------------------------------------------------------------------------*/

   void TSheep::sig_handler (int signo, siginfo_t *info, void *f)
   {

   if (info != NULL)
      dogInfo.dogPid = info->si_pid;
   sheep_counter = 0;
   if (signo == 0) return; // для отсутствия предупреждений
   if (f == NULL) return;// для отсутствия предупреждений
   };

   /*===========================================================================================*/


   /*-------------------------------------------------------------------------------*/

   TWatchDog::TWatchDog (char * dogName, char * sheepName, int watchTime)
   {
   dogInfo.waiting4First = true;
   dogInfo.dogPid = getpid();
   dogInfo.timersDeep = 10;//WATCH_DOG_TIMER_DEEP;
   dogInfo.msTiming = watchTime;
   dogInfo.msTiming = 1000000;//watchTime;
   strcpy (dogInfo.dogName, dogName);
   strcpy (dogInfo.sheepName, sheepName);
   dogInfo.showLog = true;
   isStarted = false;
   };

   /*-------------------------------------------------------------------------------*/


   void TWatchDog::startWatching()
   {


   struct sigaction act1;
   struct sigaction act2;

   act1.sa_handler = SIG_IGN;
   sigemptyset (&act1.sa_mask);

   sigaction (SIGUSR1, &act1, NULL);

   act2.sa_sigaction = sig_handler;
   act2.sa_flags |= SA_SIGINFO;
   sigemptyset (&act2.sa_mask);

   sigaction (SIGUSR2, &act2, NULL);

   isStarted = true;

   while (isStarted)
   {
      usleep (dogInfo.msTiming);
      if (dogInfo.waiting4First)
         continue;
      timerslot();

      kill (dogInfo.sheepPid, SIGUSR1);
   }
   };


   void TWatchDog::stopWatching()
   {
   //   printf("���-�� ���� ���������\n");
   isStarted = false;
   };
   /*-------------------------------------------------------------------------------*/

   void TWatchDog::sig_handler (int signo, siginfo_t *info, void *f)
   {

   if (dogInfo.waiting4First)
   {

      if (info == NULL)
      {
         return;
      };
      dogInfo.sheepPid = info->si_pid;
      dogInfo.waiting4First = false;
   }
   dog_counter = 0;
   if (signo == 0) return; // для отсутствия предупреждений
   if (f == NULL) return;// для отсутствия предупреждений
   };

   /*-------------------------------------------------------------------------------*/


   void TWatchDog::timerslot()
   {
   dog_counter++;

   //   if (dogInfo.showLog)
   //      printf("dog counter == %d\n",dog_counter);

   if (dog_counter > dogInfo.timersDeep)
   {
      restartWatching();
   }
   };

   /*-------------------------------------------------------------------------------*/

   void TWatchDog::restartWatching()
   {
   kill (dogInfo.sheepPid, SIGKILL);
   dog_counter = 0;
   if (fork() ==  0)
   {
   //      printf("������� ����� ����: %s\n",dogInfo.sheepName);
      execl (dogInfo.sheepName, dogInfo.sheepName, "-srestart", NULL);
      return;
   }
   else
   {
      exit (0);
      return;
   }

   };

   //#ifndef DOG

   //#endif
};
