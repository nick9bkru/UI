/**
   \file tabsusbiface.cpp
   \brief Описание класса TAbsSerialIface.
   \author Лихобабин
   \version 
   \date 2011-12-16
*/
#include "tabsserialiface.h"
#include "tabsserialifacestates.h"


namespace _std
{

   TAbsSerialIface::TAbsSerialIface (TSerialIfaceTunes tunes)
   {  
      stateTunes.ifaceTunes = &tunes;
      stateTunes.queue      = new TAbsQueue( "abs_serial_queue", 1, qvl_VERBOSE_EVENT );
      stateTunes.portDescr  = new int;
//       stateTunes.handle     = new libusb_device_handle*;
      
      TIfaceState* stateNA = new TAbsSerialNA(tunes.checkNAStateUsec);
   
      addState(stateNA);
      stateNA->setPrevState(stateNA);

      
      TAbsSerialOpen *stateOpen = new TAbsSerialOpen(stateTunes);

      addState(stateOpen);
      stateNA->setNextState(stateOpen);      
      stateOpen->setPrevState(stateNA);
      
      stateWork = new TAbsSerialWork(stateTunes);

      addState(stateWork);   
      stateOpen->setNextState(stateWork);
      stateWork->setPrevState(stateNA);
      stateWork->setNextState(stateWork);
      
   //    start();
   };

   void TAbsSerialIface::test()
   {
      return;
   };

   TAbsSerialIface::~TAbsSerialIface()
   {
      runFlag = false;
      delete stateTunes.queue;
      delete stateTunes.portDescr;
      pthread_cancel (threadId);
      clearList();
   };

   TIfaceState* TAbsSerialIface::getAbsWork()
   {
      return stateWork;
   };
   
};

