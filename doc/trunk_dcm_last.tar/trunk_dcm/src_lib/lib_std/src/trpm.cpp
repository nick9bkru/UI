/**
   \file trpm.cpp
   \brief Реализация класса TRpm
   \author ЛихобабаниЕ.А., Зайцев А.А., Гусинская Е.И., Воронков Д.В., Якунин С.А.
   \version
   \date 18.05.2011
*/

#include "trpm.h"
namespace _std
{
   TRpm::TRpm(string rpmName)
   {
      this->rpmName = rpmName;
   };
   //---------------------------------------------------------------//
   
   TRpm::~TRpm()
   {
   };
   //---------------------------------------------------------------//
   
   bool TRpm::verify()
   {
      int result = 0;
   
      string command = "/bin/rpm -V " + rpmName + " > /tmp/integraty_" + rpmName;
      result = system(command.c_str());
   
      command = "/bin/cat /tmp/integraty_" + rpmName + " | sed /.\\.conf$/d | sed /nodetab/d | egrep '.*'";
      command += " &> /dev/null";         //подавляем вывод
      result = system(command.c_str());
   
      command = "/bin/rm -f /tmp/integraty_" + rpmName;
      system(command.c_str());

      if (result != 0)
      {
         return true;         //это если egrep ничего не нашел в файле
      }
      else
      {
         return false;        //а если - нашел, значит у какого-то файла из пакета проблемы
      }
   };
   //--------------------------------------------------------------//
   
   bool TRpm::verifyStrict()
   {
      int result = 0;
   
      string command = "/bin/rpm -V " + rpmName;
      command += " &> /dev/null";         //подаляем вывод на консоль
      result = system(command.c_str());
   
      if (result != 0)
      {
         return false;
      }
      else
      {
         return true;
      }
   };
};
