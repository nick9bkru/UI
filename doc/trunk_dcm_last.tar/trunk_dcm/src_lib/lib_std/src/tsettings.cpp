/**
   \file tsettings.cpp
   \brief Реализация класса TSettings.
   \author Зайцев А.А.
   \version 2011-06-20
*/

#include "tsettings.h"
#include "tsettings.h"
#include <string.h>
#include <stdlib.h>
//#include "lib_std.h"
#include <unistd.h>

namespace _std
{

ENV_TABLE *env_table;

/*---------------------------------------------------------------------------*/
TSettings::TSettings()
{
   path = new TPathFinder();                       // создаем мастера поиска пути
   parser = new TConfFileParser ();                // создаем парсер и отдаем ему управляющую структуру
   setDefaultFileName();                           // устанавливаем имя файла по умолчанию
   verbosed = true;                                // отключаем по умолчанию вывод сообщений
   parser->setVerbosed(verbosed);
};

/*---------------------------------------------------------------------------*/

TSettings::TSettings(TSet * defSet, ENV_ITEM * env_item,int argc, char ** argv, string fn, bool verb)
{
   path = new TPathFinder();                       // создаем мастера поиска пути
   parser = new TConfFileParser ();                // создаем парсер и отдаем ему управляющую структуру
   verbosed = verb;
   parser->setVerbosed(verbosed);
   setCurSettingsFileName(fn);
   setArgumentsList(env_item);
   setSettingsList(defSet);
   parseComandString(argc, argv);
   loadSettings();
};

/*---------------------------------------------------------------------------*/

TSettings::TSettings(TSet * defSet, ENV_ITEM * env_item, string fn, bool verb)
{
   path = new TPathFinder();                       // создаем мастера поиска пути
   parser = new TConfFileParser ();                // создаем парсер и отдаем ему управляющую структуру
   verbosed = verb;
   parser->setVerbosed(verbosed);
   setCurSettingsFileName(fn);
   setArgumentsList(env_item);
   setSettingsList(defSet);
   loadSettings();
};

/*---------------------------------------------------------------------------*/

void TSettings::setSettingsList(TSet * defSet)
{
   curSettings = defSet;                           // устанавливаем предопределенный список параметров
   parser->setSettingsList(curSettings);
};

/*---------------------------------------------------------------------------*/

void TSettings::setArgumentsList(ENV_ITEM * envItem)
{
   env_default = envItem;

};

/*---------------------------------------------------------------------------*/

bool TSettings::setCurSettingsFileName (const string fn)
{
   if (fn == "")
   {
      logOut ("SettingsFileName is Empty. Default settings file name will be applyed !!!");
      setDefaultFileName();
      return false;
   };

   if (access (fn.data(), R_OK + F_OK) == -1) // проверяем файл на существование и право доступа на чтение
   {
      logOut ("Settings file name can't be read. Default settings file name will be applyed !!!");
      setDefaultFileName();
      return false;
   }

   curSettingsFileName = fn;
   return true;
};

/*---------------------------------------------------------------------------*/

bool TSettings::setDefaultFileName()
{
   string defFileName;


   defFileName = path->getSpecificPath (gsp_BIN);
   defFileName += path->getSpecificPath (gsp_BIN_EXE_WITHOUT_EXT);
   defFileName += ".conf";

   if (access (defFileName.data(), R_OK + F_OK) != -1)
   {
      curSettingsFileName = defFileName;
      return true;
   };

   defFileName = "/etc/";
   defFileName += path->getSpecificPath(gsp_BIN_EXE_WITHOUT_EXT);
   defFileName += ".conf";

   if (access (defFileName.data(), R_OK + F_OK) != -1)
   {
      curSettingsFileName = defFileName;
      return true;
   };

   logOut ("Default Settings file can't be read. Default settings will be applyed !!!");
   return false;
};

/*---------------------------------------------------------------------------*/

void TSettings::setDefaultSettings() //уже не нужно
{
   parser->setDefault();
   logOut ("Default settings have been applied !!!");
};

/*---------------------------------------------------------------------------*/

bool TSettings::loadSettings (const char * fn)
{
   if (fn != NULL)
      setCurSettingsFileName(fn);

   if (curSettingsFileName == "")
   {
      logOut ("Settings file have not been established. Default Settings will be applied");
      setDefaultSettings();
      return true;
   };

   if (parser->parse (curSettingsFileName.data(), false) != 0)
   {
      logOut ("Settings file can't be parsed. Default Settings will be applied");
      setDefaultSettings();
   }
   return true;
};

/*---------------------------------------------------------------------------*/

char * TSettings::getChar (const char * settingName)
{
   return parser->getCharValue (settingName);
};

/*---------------------------------------------------------------------------*/

int TSettings::getInt (const char * settingName)
{
   if (strcmp (parser->getType (settingName), "int") != 0)
      return 0;
   else
      return *parser->getIntValue (settingName);
};

/*---------------------------------------------------------------------------*/

bool TSettings::getBool (const char * settingName)
{
   if (strcmp (parser->getType (settingName), "bool") != 0)
      return false;
   else
      return parser->getBoolValue (settingName);
};

/*---------------------------------------------------------------------------*/

bool TSettings::str2bool (char * str)
{
   if (str == NULL)
      return false;
   if (strcasecmp (str, "yes"))
      return true;

   return true;
};

/*---------------------------------------------------------------------------*/

void TSettings::parseComandString (int argc, char ** argv)
{
   env_table = (ENV_TABLE*) malloc (sizeof (ENV_TABLE));

   if (argc < 0) return;

   if (parseCall ( (ENV_ITEM*) env_default, argc, argv) == ERROR)
   {
   }//   exit( usage("v") );

   if (ph_tstenvkey ('h'))
   {
      usage ( (char*) "v");
      exit (0);
   }
};

/*---------------------------------------------------------------------------*/

bool TSettings::testKey(char keyname)
{
   return (ph_tstenvkey (keyname) != 0);
};

/*---------------------------------------------------------------------------*/

char * TSettings::getKey(char keyname)
{
   char * ptr;

   if (ph_tstenvkey (keyname) != 0)
   {
      ptr = (char *) ph_getkeyval (keyname);
      return ptr;
   };
   return NULL;
};

/*---------------------------------------------------------------------------*/

bool TSettings::isIP (char * ip)
{
   bool result;
//   int a;
   int ind, q;
   char tmpstr[17];

   result = true;
   strncpy (tmpstr, ip, 15);
   tmpstr[15] = '.';
   tmpstr[16] = 0x0;

   ind = 0;
   q = 0;
   for (int i = 0;i < 16; i ++)
   {
      if (tmpstr[i] == '.')
      {
         tmpstr[i] = 0x0;
         result &= (atoi (&tmpstr[ind]) < 255) && (atoi (&tmpstr[ind]) >= 0);
         ind = i + 1;
         q++;
      };
   };
   result &= (q == 4);

   return result;
};

/*---------------------------------------------------------------------------*/

void TSettings::setVerbosed (bool verb)
{
   verbosed = verb;
};

/*---------------------------------------------------------------------------*/

void TSettings::logOut (const char * logstring)
{
   if (verbosed)
   {
      cout << "--------------settings message---------------" << endl;
      cout << logstring << endl;
      cout << "---------------------------------------------" << endl;
   };
};

/*===========================================================================*/

   
//    ENV_TABLE *env_table;
// 
//    /*---------------------------------------------------------------------------*/
//    TSettings::TSettings()
//    {
//       path = new TPathFinder();                       // создаем мастера поиска пути
//       parser = new TConfFileParser ();                // создаем парсер и отдаем ему управляющую структуру
//       setDefaultFileName();                           // устанавливаем имя файла по умолчанию
//       verbosed = true;                                // отключаем по умолчанию вывод сообщений
//       parser->setVerbosed(verbosed);
// 
//       isSet = false;
//    };
//    /*---------------------------------------------------------------------------*/
//    TSettings::TSettings(TSettings& _settings)
//    {
//       path = new TPathFinder();                       // создаем мастера поиска пути
//       parser = new TConfFileParser ();                // создаем парсер и отдаем ему управляющую структуру
//       setDefaultFileName();                           // устанавливаем имя файла по умолчанию
//       verbosed = _settings.verbosed;                                // отключаем по умолчанию вывод сообщений
//       parser->setVerbosed(verbosed);
//       isSet = false;   
//    };
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::setSettings(TSet * defSet, ENV_ITEM * env_item,int argc, char ** argv, string fn, bool verb)
//    {
//       verbosed = verb;
//       parser->setVerbosed(verbosed);
//       setCurSettingsFileName(fn);
//       setArgumentsList(env_item);
//       setSettingsList(defSet);
//       parseComandString(argc, argv);
//       loadSettings();
//       isSet = true;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::setSettingsList(TSet * defSet)
//    {
//       curSettings = defSet;                           // устанавливаем предопределенный список параметров 
//       parser->setSettingsList(curSettings);
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::setArgumentsList(ENV_ITEM * envItem)
//    {
//       env_default = envItem;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::setCurSettingsFileName (const string fn)
//    {
//    if (fn == "")
//    {
//       logOut ("SettingsFileName is Empty. Default settings file name will be applyed !!!");
//       setDefaultFileName();
//       return false;
//    };
//    
//    if (access (fn.c_str(), R_OK + F_OK) == -1) // проверяем файл на существование и право доступа на чтение
//    {
//       logOut ("Settings file name can't be read. Default settings file name will be applyed !!!");
//       setDefaultFileName();
//       return false;
//    }
// 
//    curSettingsFileName = fn;
//    return true;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::setDefaultFileName()
//    {
//       string defFileName;
//       
//       
//       defFileName = path->getSpecificPath (gsp_BIN);
//       defFileName += path->getSpecificPath (gsp_BIN_EXE_WITHOUT_EXT);
//       defFileName += ".conf";
//       
//       if (access (defFileName.data(), R_OK + F_OK) != -1)
//       {
//          curSettingsFileName = defFileName;
//          return true;
//       };
//       
//       defFileName = "/etc/";
//       defFileName += path->getSpecificPath(gsp_BIN_EXE_WITHOUT_EXT);
//       defFileName += ".conf";
//       
//       if (access (defFileName.data(), R_OK + F_OK) != -1)
//       {
//          curSettingsFileName = defFileName;
//          return true;
//       };
//       
//       logOut ("Default Settings file can't be read. Default settings will be applyed !!!");
//       return false;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::setDefaultSettings() //уже не нужно
//    {
//    parser->setDefault();
//    logOut ("Default settings have been applied !!!");
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::loadSettings (const char * fn)
//    {
//    if (fn != NULL)
//       setCurSettingsFileName(fn);
//    
//    if (curSettingsFileName == "")
//    {
//       logOut ("Settings file have not been established. Default Settings will be applied");
//       setDefaultSettings();
//       return true;
//    };
//    
//    if (parser->parse (curSettingsFileName.data(), false) != 0)
//    {
//       logOut ("Settings file can't be parsed. Default Settings will be applied");
//       setDefaultSettings();
//    }
//    return true;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    char * TSettings::getChar (const char * settingName)
//    {
//    return parser->getCharValue (settingName);
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    int TSettings::getInt (const char * settingName)
//    {
//    if (strcmp (parser->getType (settingName), "int") != 0)
//       return 0;
//    else
//       return *parser->getIntValue (settingName);
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::getBool (const char * settingName)
//    {
//    if (strcmp (parser->getType (settingName), "bool") != 0)
//       return false;
//    else
//       return parser->getBoolValue (settingName);
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::str2bool (char * str)
//    {
//    if (str == NULL)
//       return false;
//    if (strcasecmp (str, "yes"))
//       return true;
// 
//    return true;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::parseComandString (int argc, char ** argv)
//    {
//    env_table = (ENV_TABLE*) malloc (sizeof (ENV_TABLE));
// 
//    if (argc < 0) return;
//    
//    if (parseCall ( (ENV_ITEM*) env_default, argc, argv) == ERROR)
//    {
//    }//   exit( usage("v") );
// 
//    if (ph_tstenvkey ('h'))
//    {
//       usage ( (char*) "v");
//       exit (0);
//    }
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::testKey(char keyname)
//    {
//    return (ph_tstenvkey (keyname) != 0);
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    char * TSettings::getKey(char keyname)
//    {
//    char * ptr;
// 
//    if (ph_tstenvkey (keyname) != 0)
//    {
//       ptr = (char *) ph_getkeyval (keyname);
//       return ptr;
//    };
//    return NULL;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    bool TSettings::isIP (char * ip)
//    {
//    bool result;
//    //   int a;
//    int ind, q;
//    char tmpstr[17];
// 
//    result = true;
//    strncpy (tmpstr, ip, 15);
//    tmpstr[15] = '.';
//    tmpstr[16] = 0x0;
// 
//    ind = 0;
//    q = 0;
//    for (int i = 0;i < 16; i ++)
//    {
//       if (tmpstr[i] == '.')
//       {
//          tmpstr[i] = 0x0;
//          result &= (atoi (&tmpstr[ind]) < 255) && (atoi (&tmpstr[ind]) >= 0);
//          ind = i + 1;
//          q++;
//       };
//    };
//    result &= (q == 4);
// 
//    return result;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::setVerbosed (bool verb)
//    {
//    verbosed = verb;
//    };
// 
//    /*---------------------------------------------------------------------------*/
// 
//    void TSettings::logOut (const char * logstring)
//    {
//    if (verbosed)
//    {
//       cout << "--------------settings message---------------" << endl;
//       cout << logstring << endl;
//       cout << "---------------------------------------------" << endl;
//    };
//    };
};
/*===========================================================================*/

