/**
   \file tabsipiface.cpp
   \brief Описание класса TAbsIpIface.
   \author Дмитрий Воронков
   \version 
   \date 2011-01-01
*/
#include "tabsipiface.h"
#include "tabsipifacestates.h"

namespace _std
{

   TAbsIpIface::TAbsIpIface (string ip, int pingTimingUsec)
   {   
   TIfaceState* stateNA = new TAbsIpNA(pingTimingUsec);
  
   addState(stateNA);
   stateNA->setPrevState(stateNA);

   
   statePinging = new TAbsIpPinging(ip, pingTimingUsec);

   addState(statePinging);
   stateNA->setNextState(statePinging);
   statePinging->setPrevState(stateNA);
   statePinging->setNextState(statePinging);
   
   //    start();
   };

   void TAbsIpIface::test()
   {
   return;
   };

   TAbsIpIface::~TAbsIpIface()
   {
   runFlag = false;
   pthread_cancel (threadId);
   clearList();
   };

   TIfaceState* TAbsIpIface::getAbsIpPinging()
   {
   return statePinging;
   };
};

