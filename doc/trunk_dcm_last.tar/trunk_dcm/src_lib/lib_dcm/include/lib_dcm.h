/**
*\file lib_dcm.h
*\brief Файл с заголовочными файлами библиотеки.
*\author Лихобабин Е.А.
*\version 1.001.001
*\date 2012.06.19
*/
#ifndef LIB_DCM_H
#define LIB_DCM_H 1

#include "tdrycontactmodule.h"

#endif
